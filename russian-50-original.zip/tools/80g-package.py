from pathlib import Path
import json,shutil,zipfile,hashlib,csv
O=Path('output/b80g');B=O/'snapshot';W=Path('work/b80g')
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
if not B.exists():shutil.copytree('output/review-80ef/snapshot',B)
# Предыдущие актуальные записи и инструменты сохраняются перед заменой.
for p in Path('output/review-80ef').glob('*.json'):
 d=B/'history/80f-final'/p.name;d.parent.mkdir(parents=True,exist_ok=True)
 if not d.exists():shutil.copyfile(p,d)
for p in (B/'bank/variants').glob('*.json'):
 d=B/'history/80f-final/variants'/p.name;d.parent.mkdir(exist_ok=True)
 if not d.exists() and not p.name.startswith('ru-2027-G-'):shutil.copyfile(p,d)
 p.unlink()
a=load(O/'tasks.json');texts=load(O/'texts.json');vs=load(O/'variants.json')
for n in range(1,28):dump(B/f'bank/tasks/line-{n:02}.json',[t for t in a if t['line']==n])
for t in texts:dump(B/f'bank/texts/{t["id"]}.json',t)
for v in vs:dump(B/f'bank/variants/{v["id"]}.json',v)
dump(B/'bank/variants/index.json',[{'id':v['id'],'title':v['title'],'file':v['id']+'.json','status':'draft','text_pair_origin':'80F, повторно использован'} for v in vs])
for name in ['tasks','texts','variants','new-tasks','sources','batch-summary','coverage','patch-history','review-decisions','source-history','checks','duplicate-checks','core-checks','render-checks']:
 if (O/(name+'.json')).exists():shutil.copyfile(O/(name+'.json'),B/(name+'.json'))
with (B/'coverage.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['line','inventory','active','target','remaining']);w.writeheader();w.writerows(load(O/'coverage.json'))
for p in (W/'authors').glob('*'):
 if p.is_file():d=B/'history/author-80g'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
# Официальные PDF проекта2027 сохраняются; большие словари доступны по ссылкам и локаторам источников.
for p in (W/'authors/lex-work/fipi').glob('*.pdf'):
 d=B/'sources/fipi-2027'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for p in (W/'reviews').glob('*'):
 if p.is_file():d=B/'reviews/80g'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for name in ['build.py','make_html.py','validate.py','package.py','test_core.cjs','test_render.cjs']:
 if (W/name).exists():shutil.copyfile(W/name,B/'tools'/('80g-'+name))
portable=(W/'validate.py').read_text().replace("P=Path('output/b80g')","P=Path(__file__).resolve().parent.parent")
(B/'tools/validate_snapshot.py').write_text(portable)
shutil.copyfile(W/'CONTRACT.md',B/'CONTRACT-80G.md')
shutil.copyfile(W/'FORMAT-2027.md',B/'FORMAT-2027.md')
for name in ['approved-edits.json','approved-source-edits.json']:
 d=B/'history/80g-input'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/name,d)
(B/'tools/README.md').write_text('Текущий контроль: python3 tools/validate_snapshot.py из распакованного архива. Скрипты80g-* сохраняют процесс текущей сборки,80f-* — предыдущей. Канонический банк: tasks.json иbank/tasks; все прошлые материалы остаются вhistory.\n')
readme='''# Русский язык · партия80G · единый снимок

12.11.2026. Откройте russian-bank-80g.html: в одном файле все задания, ключи, объяснения, заметки и скачиваемый полный архив. Интернет для работы не нужен. Это контентная сборка, не работающий сервер приложения.

## Состав

1067 прежних ID +80 новых =1147 записей. Из них1146 активных черновиков, одно старое спорное №6 on_hold: оно исключено из вариантов и автоматической оценки. Правки не считаются новыми заданиями.

80G: по7 заданий №5/6, по6 №8/13–22. Все80 распределены по8 обновлённым полным вариантам1–27. В первых6 вариантах по13 новых заданий80G, в седьмом2 новых, восьмой вариант сохранён в редакции80F. В них те же8 пар авторских текстов80F; НОВЫХ ТЕКСТОВЫХ ПАР В80G НЕТ. Это8 обновлённых комбинаций, не ещё8 независимых текстовых комплектов к цели50. Всего9 пар текстов в полном снимке.

Каждый вариант:28 баллов часть1 +22 сочинение=50. Сочинения здесь автоматически не оцениваются. Совпадение с авторским ключом не является методической приёмкой.

## Требования методиста

Материал строится под конкретную норму, дистракторы требуют разбора; сложность не создаётся двусмысленностью. Условия, ключ и объяснение перечитываются вместе. Отдельные агенты повторно решают задания с закрытым ключом и ищут альтернативу; отчёты и авторские проверки сохранены. Агентные проверки не заменяют человеческую методическую приёмку.

В№6 замена неверно употреблённого слова с сохранением смысла по формулировке проекта2027; открытые группы ответов имеют manual_review — неизвестный ответ не получает автоматический ноль. №8 не объявляет ошибкой любые кавычки послеЧТО и не требует механически одинаковых времён. №20 содержит сочинение разных основ и подчинение. №21 группирует один грамматический тип знака. В№22 выделяются диагностические фрагменты, а не весь случайный пример.

80 переработанных№9–12 из прежнего снимка сохранены с контекстами и синхронизированными паспортами/blueprint/инвентарём. Ещё511 старых№9–12 остаются needs_rework_after_teacher_comments. Новая партия не означает, что эти511 уже исправлены. Нормативные источники и источники формата разделены. Все новые записиdraft,needs_source=true,allowed_2027=null,norm_basis.confirmed=false до внешней приёмки.

## Продолжение

Актуальные tasks.json иbank/tasks; new-tasks.json — только80G; bank/variants/index.json —8 обновлённых вариантов. Источники, прошлые PDF, авторские исходники, все прежние партии и история редакций сохранены. Официальные PDF проекта2027 включены; большие нормативные словари доступны по точным URL и локаторам вsources.json, их рабочие кэши не включались. Вhistory/80f-final — предыдущий полный снимок. Демо-партия80D по-прежнему не выдумывается: её исходного файла не было. Исходные версии747 восстановленных записей остаются неизвестными(null), а не заменяются единицей.

Дефицит активного материала до50 на каждой линии —595 позиций. Избыток№9–12 не заменяет недостающие текстовые и иные задания. Кроме заполнения дефицита остаётся переработка511 старых и человеческая методическая приёмка.

Проверки структуры, эталонов, точных повторов и текущего подсчёта — checks.json/core-checks.json/render-checks.json. Проверка рендера в моделиDOM не является визуальной проверкой браузером; такую проверку здесь не заявляем. Полный архив проверяется поCRC иSHA256SUMS.json.
'''
(B/'README.md').write_text(readme)
p=B/'РЕШЕНИЯ.md';txt=p.read_text();marker='# Дополнение 12.11.2026 · 80G'
if marker not in txt:p.write_text(txt+'\n\n'+marker+'\n\nПродолжаем80 новыми заданиями на13линиях поCONTRACT-80G.md. Восемь вариантов обновлены, тексты80F повторно использованы, число независимых текстовых пар не выросло. Агентные проверки не снимаютdraft;511старых9–12 всё ещё требуют переработки.\n')
sha={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(B.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};dump(B/'SHA256SUMS.json',sha)
with zipfile.ZipFile(O/'russian-bank-80g.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(B))
print('Snapshot files',len(sha),'ZIP bytes',(O/'russian-bank-80g.zip').stat().st_size)
