import copy,itertools,collections,random,json,hashlib,re

def word(x):return next(z for z in re.findall(r'[^\s,;()]+',x['template']) if '..' in z).replace('..',x['letter'])
def lemma(x,line):
 v=x.get('infinitive',x.get('lemma',word(x)))
 return re.sub('(ся|сь)$','',v) if line==12 else v

def assemble_remaining(base_tasks,first_tasks,passports,canonical,seed=20261112):
 rng=random.Random(seed);done={p['task_id'] for p in passports};firstids={t['id'] for t in first_tasks}
 targets=[t for t in base_tasks if t.get('method_work_state')=='needs_rework_after_teacher_comments' and t['id'] not in firstids]
 pools=collections.defaultdict(list)
 for (ln,g,w,c),x in canonical.items():
  x=copy.deepcopy(x);x.pop('usage_count',None);x['word']=word(x);pools[(ln,g)].append(x)
 candidates={};group_used=collections.Counter()
 seenrows=set();seenfamilies=set();globalfreq=collections.Counter()
 for p in passports:
  allwords=[]
  for r in p['rows']:
   ws=tuple(sorted(word(x) for x in r['items']));seenrows.add((p['line'],ws));allwords+=list(ws);group_used[(p['line'],r['group'])]+=1
   for w in ws:globalfreq[(p['line'],w)]+=1
  seenfamilies.add((p['line'],tuple(sorted(allwords))))
 for (ln,g),items in pools.items():
  for truth in [False,True]:
   cand=[];k=3 if ln in [9,10] else 2
   for combo in itertools.combinations(items,k):
    letters=[x['letter'] for x in combo];same=len(set(letters))==1
    if same!=truth:continue
    if not same and k==3 and sorted(collections.Counter(letters).values())!=[1,2]:continue
    if len({lemma(x,ln) for x in combo})!=k:continue
    if len({word(x) for x in combo})!=k:continue
    cand.append((combo,tuple(sorted(word(x) for x in combo)),{lemma(x,ln) for x in combo}))
   candidates[(ln,g,truth)]=cand
 generated=[];newpass=[];cohorts=[];checks=[]
 byline=collections.defaultdict(list)
 for t in targets:byline[t['line']].append(t)
 for ln in sorted(byline):
  groups=sorted(g for n,g in pools if n==ln)
  for offset in range(0,len(byline[ln]),20):
   cohort_targets=byline[ln][offset:offset+20];freq=collections.Counter();cohort_ids=[]
   for idx,old in enumerate(cohort_targets):
    selected_count=[2,3,1,4][(offset+idx+ln)%4]
    success=None
    for attempt in range(600):
     truepositions=set(rng.sample(range(5),selected_count));rows=[];usedlemmas=set();usedwords=set();usedgroups=set();rowkeys=[]
     for ri in range(5):
      truth=ri in truepositions;options=[]
      shuffled=list(groups);rng.shuffle(shuffled);shuffled.sort(key=lambda g:(g in usedgroups,group_used[(ln,g)]))
      for g in shuffled:
       valid=[]
       for combo,ws,ls in candidates[(ln,g,truth)]:
        if (ln,ws) in seenrows or ws in rowkeys:continue
        if any(freq[w]>=4 or w in usedwords for w in ws):continue
        if ls&usedlemmas:continue
        score=sum(freq[w]*100+globalfreq[(ln,w)] for w in ws)
        valid.append((score,combo,ws,ls))
       if valid:
        valid.sort(key=lambda z:z[0]);bestscore=valid[0][0];top=[z for z in valid if z[0]<=bestscore+2];choice=rng.choice(top[:60]);options.append((group_used[(ln,g)]+(100000 if g in usedgroups else 0),choice[0],g,choice))
      if not options:break
      options.sort(key=lambda z:(z[0],z[1]));best=options[0][0];opts=[v for v in options if v[0]<=best+3];_,_,g,(_,combo,ws,ls)=rng.choice(opts[:3])
      its=copy.deepcopy(list(combo));rng.shuffle(its);contrast=sorted({x['letter'] for x in pools[(ln,g)]})
      rows.append({'group':g,'topic':its[0]['topic'],'contrast':contrast,'items':its,'purpose':('Верный ряд: общий выбор по проверяемому правилу.' if truth else 'Правдоподобный неверный ряд: различение букв внутри одной группы правил.')})
      usedgroups.add(g);usedwords.update(ws);usedlemmas.update(ls);rowkeys.append(ws)
     if len(rows)!=5:continue
     fsig=(ln,tuple(sorted(usedwords)))
     if fsig in seenfamilies:continue
     success=(rows,usedwords,rowkeys,fsig);break
    if success is None:raise RuntimeError(f'Cannot assemble {old["id"]} after600 attempts, cohort {offset}, frequencies {freq.most_common(5)}')
    rows,usedwords,rowkeys,fsig=success
    for r in rows:
     group_used[(ln,r['group'])]+=1
     for x in r['items']:freq[word(x)]+=1;globalfreq[(ln,word(x))]+=1
    for rk in rowkeys:seenrows.add((ln,rk))
    seenfamilies.add(fsig);cohort_ids.append(old['id'])
    model=next(t for t in first_tasks if t['line']==ln);t={k:copy.deepcopy(v) for k,v in model.items() if k not in ['opts','key','exp','drill','words','family','version','replaces_family','recovery']};t['id']=old['id'];t['source']='assembled:audited-rule-inventory';t['assembly_origin']={'method':'rule_based_combinations','seed':seed,'cohort':f'{ln}-{offset//20+1}','individually_blind_solved':False,'inventory_audited':True}
    p={'id':'r80-02:'+old['id'],'task_id':old['id'],'line':ln,'rows':rows,'review_status':'rule_assembled_pending_human_methodologist'}
    generated.append(t);newpass.append(p);checks.append({'id':t['id'],'cohort':f'{ln}-{offset//20+1}','true_rows':selected_count,'attempts':attempt+1,'word_count':len(usedwords),'unique_row_sets':5,'individually_blind_solved':False})
   cohorts.append({'line':ln,'id':f'{ln}-{offset//20+1}','tasks':cohort_ids,'count':len(cohort_ids),'max_word_repetitions':max(freq.values()),'word_counts':dict(sorted(freq.items()))})
 return generated,newpass,{'seed':seed,'generated_tasks':len(generated),'cohorts':cohorts,'task_checks':checks,'all_rows_distinct':True,'max_word_repetitions_per_line_cohort':4,'individually_blind_solved':False,'review_scope':'Audited inventory and rule contrasts; generated combinations checked mechanically; human methodologist acceptance pending.'}
