from pathlib import Path
import json,copy,hashlib,re,collections
W=Path('work/review-80ef'); O=Path('output/review-80ef');O.mkdir(parents=True,exist_ok=True)
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
base=load(W/'baseline-bank.json'); tasks=copy.deepcopy(base);texts=load(W/'baseline-texts.json'); sources=load(W/'baseline-sources.json'); new=[]
for fn in ['texts_1','texts_2','line7']:
 a=load(f'work/agents/new80f/{fn}.json');new+=a['tasks'];texts+=a.get('texts',[])
 for s in a['sources']:
  sid=s['id'];clean={k:v for k,v in s.items() if k!='id'}
  if sid in sources and sources[sid]!=clean:raise ValueError(('source ID collision',sid))
  sources[sid]=clean
for sid, info in load('work/recovered-r80/source/sources.json').items():sources.setdefault(sid,info)
tasks+=copy.deepcopy(new); original={t['id']:copy.deepcopy(t) for t in tasks};byid={t['id']:t for t in tasks};textby={t['id']:t for t in texts};originaltexts=copy.deepcopy(textby);log=[];changedtexts=set()
def applytext(tid,e):
 t=textby[tid];i=e['sentence']-1;old=t['sentences'][i];before=e.get('old',e.get('before'))
 if before is not None:assert before==old,(tid,old,before)
 value=e.get('new',e.get('after',e.get('replacement')));assert isinstance(value,str)
 t['sentences'][i]=value;changedtexts.add(tid);log.append({'target':tid,'sentence':i+1,'before':old,'after':value,'decision':'accepted editorial correction; linked questions rechecked'})
def patch(t,e,origin):
 before=copy.deepcopy(t)
 for field in ['stem','key','opts','exp','left','right','left_markup','evidence','method_work_state']:
  if field in e:t[field]=copy.deepcopy(e[field])
 for i,val in e.get('opts_replace',{}).items():t['opts'][int(i)-1]=val
 for i,val in e.get('exp_replace',{}).items():
  rows=t['exp'].split('\n');idx=int(i)-1
  assert len(rows)>=idx+1,(t['id'],'exp row',idx)
  if not re.match(r'^\d+[.:]',val):val=str(i)+'. '+val
  rows[idx]=val;t['exp']='\n'.join(rows)
 if 'exp_append' in e:t['exp']+='\n'+e['exp_append']
 if 'rule_source_replace' in e:
  s=e['rule_source_replace'];sources[s['id']]={k:v for k,v in s.items() if k!='id'};t['norm_basis']['rule_source']=[s['id']];t['source_refs']=list(dict.fromkeys(t.get('source_refs',[])+[s['id']]))
 if t!=before:log.append({'target':t['id'],'origin':origin,'decision':'accepted','fields':[k for k in t if t.get(k)!=before.get(k)]})
for name in ['lex_grammar-findings','orthography-findings','orthography-legacy-findings','punctuation-findings','new-short-findings','new-main1-findings','new-main2-findings','new-line7-findings']:
 for f in load(f'work/agents/reviews/{name}.json'):
  e=f.get('proposed_edit',{});tid=f.get('task_id',f['id'])
  if tid in byid:patch(byid[tid],e,name)
  if 'proposed_text_edit' in e:applytext(e['text_id'],e['proposed_text_edit'])
  if 'proposed_text_edit' in f:applytext(f['text_id'],f['proposed_text_edit'])
  for url in f.get('source_urls',[]):
   sid='REVIEW-'+hashlib.sha256(url.encode()).hexdigest()[:12];sources.setdefault(sid,{'url':url,'title':'Нормативное основание из журнала проверки','role':'См. конкретное замечание; не общий допуск задания.'})
   if tid in byid:byid[tid]['source_refs']=list(dict.fromkeys(byid[tid].get('source_refs',[])+[sid]))
# Итоговая редакторская вычитка: уже расставленные фигуры остаются на доске.
applytext('ru-2027-F-B003',{'sentence':16,'old':'Миша увидел меня через дверное стекло и сразу открыл, однако к доске подошёл медленно, не доставая из мешочка остальные фигуры.','new':'Миша увидел меня через дверное стекло и сразу открыл, однако к доске с расставленными фигурами подошёл медленно.'})
byid['rus-2027-b80f-26-0004']['exp']+=' В предложении 21 указательное «того» относится к автору, но «другая вещь» называет другое произведение, а не переименовывает издание из предложения 20; требуемая пара средств связи с предыдущим предложением не образуется.'
# Одобренная полная замена №6; вторую предложенную замену сохраняем только кандидатом.
repl=load('work/agents/reviews/lexical-replacements.json')[0]; t=byid[repl['replace_id']]
for field in ['stem','key','exp','linguistic_fact']:t[field]=copy.deepcopy(repl[field])
t['key_policy']={'kind':'open','on_unmatched':'manual_review','note':'Перечень нормативных замен не объявляется исчерпывающим.'}
t['alternative_search']=repl['alternative_search'];t['norm_basis']['claim']='Сочетание «занять первенство» прямо отвергнуто Грамотой №297281; контекстная близость значений требует методического допуска.'
t['norm_basis']['rule_source']=[]
for s in repl['sources']:
 sid='REVIEW-'+hashlib.sha256(s['url'].encode()).hexdigest()[:12];sources[sid]=s;t['source_refs'].append(sid);t['norm_basis']['rule_source'].append(sid)
f=load('work/agents/reviews/lexical-replacement-findings.json')[-1];patch(t,f['proposed_edit'],'lexical replacement independent review')
hold=byid['rus-2027-b80e-06-0003'];hold['status']='on_hold';hold['method_work_state']='on_hold';hold['on_hold_reason']='Нормативность исходного употребления не исключена. Предложенная замена с контаминацией также не получила допуска по требованию близости значений модели №6. Не включать в варианты и автоматическую оценку.';hold['key_policy']={'kind':'open','on_unmatched':'manual_review'}
# Восстановленный запасной №6: инструкция и полнота ключей.
t=byid['rus-2027-b80a-06-0007'];t['key']=['расширить','раздвинуть'];t['key_policy']={'kind':'open','on_unmatched':'manual_review'};t['stem']=t['stem'].replace('заменив неверно употреблённое слово.','заменив неверно употреблённое слово близким по значению.');t['exp']+=' Допустимо «раздвинуть»: нормативный толковый словарь прямо фиксирует «раздвинуть кругозор». В данном контексте исходное слово предполагает увеличение знаний, и замена сохраняет этот смысл; пригодность по современной модели требует подтверждения методистом.'
url='https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast2_O-Ja.pdf';sid='REVIEW-'+hashlib.sha256(url.encode()).hexdigest()[:12];sources[sid]={'url':url,'title':'Нормативный толковый словарь. «Раздвинуть», значение3','role':'Словарное сочетание «раздвинуть кругозор».'};t['source_refs'].append(sid)
t=byid['rus-2027-b80a-06-0005'];t['stem']=t['stem'].replace('заменив неверно употреблённое слово.','заменив неверно употреблённое слово близким по значению.')
# Дополнительное устранение общего обстоятельства в ССП, не меняющее ключ.
t=byid['rus-2027-b80e-16-0006'];t['opts'][0]='Последний огонёк погас и путешественники услышали плеск вёсел.';t['evidence']['punctuated_options'][0]='Последний огонёк погас, и путешественники услышали плеск вёсел.';rows=t['exp'].split('\n');rows[0]='1. Запятых: 1. Последний огонёк погас, и путешественники услышали плеск вёсел. Самостоятельные основы «огонёк погас» и «путешественники услышали»; общего члена нет.';t['exp']='\n'.join(rows)
t=byid['rus-2027-b80e-20-0005'];t['stem']=t['stem'].replace('Мы ждали у входа','Гости молчали');t['exp']=t['exp'].replace('Мы ждали у входа','Гости молчали').replace('«мы ждали»','«гости молчали»');t['evidence']['punctuated_text']=t['evidence']['punctuated_text'].replace('Мы ждали у входа','Гости молчали')
# Редакции генераторных материалов R80 поступают отдельным проверенным блоком.
r80path=W/'r80-fixed/tasks.json'
if r80path.exists():
 for fixed in load(r80path):
  assert fixed['id'] in byid
  byid[fixed['id']].update(fixed)
else:raise RuntimeError('R80 agent output not ready')
for t in tasks:t['source_refs']=list(dict.fromkeys(t.get('source_refs',[])))
# История правок и версии: неизвестные исходные version не выдумываются.
content=['stem','opts','left','right','left_markup','drill','text']
changes=[]
for t in tasks:
 old=original[t['id']]
 if t.get('text') in changedtexts:
  t['text_version']=(originaltexts[t['text']].get('version') or 0)+1
  t['agent_review']={'state':'post_text_change_recheck_required','human_methodologist_accepted':False}
 elif t.get('text') and textby[t['text']].get('version') is not None:t['text_version']=textby[t['text']]['version']
 if t['id'].startswith('rus-2027-b80f'):t['method_work_state']='agent_reviewed_draft_pending_human_methodologist'
 meaningful=any(t.get(k)!=old.get(k) for k in set(t)|set(old) if k not in ['agent_review','method_work_state','text_version']) or t.get('text') in changedtexts
 if meaningful:
  t['version']=old['version']+1 if isinstance(old.get('version'),int) else None
  if t['version'] is None:t['recovery_revision']=old.get('recovery_revision',0)+1
  if any(t.get(k)!=old.get(k) for k in content):
   t['replaces_family']=old['family'];body={k:t.get(k) for k in content};t['family']='review-'+hashlib.sha256(json.dumps(body,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:20]
  changes.append({'id':t['id'],'before':old,'after':copy.deepcopy(t),'reason':'review integration 80E/80F; see findings and decisions'})
for tid in changedtexts:
 textby[tid]['version']=(originaltexts[tid].get('version') or 0)+1
 textby[tid]['agent_review']={'state':'post_change_recheck_required','human_methodologist_accepted':False}
# Фиксируем завершённые повторные проверки. Они не являются приёмкой человеком.
reviewed_ids=set()
for fn in ['new-shorts-postfix','new-main1-postfix','new-main2-postfix','new-line7-ledger']:
 report=Path('work/agents/reviews')/(fn+'.json')
 if not report.exists():continue
 for r in load(report):
  tid=r['id'];t=byid[tid]
  if 'literal_key' in r:assert r['literal_key']==t['key'],(tid,r['literal_key'],t['key'])
  assert not r.get('blocking_findings'),tid
  reviewed_ids.add(tid)
  t['agent_review']={'state':'completed_draft','report':'reviews/'+fn+'.json','human_methodologist_accepted':False}
  if t.get('text'):textby[t['text']]['agent_review']={'state':'completed_draft','human_methodologist_accepted':False}
assert len(reviewed_ids)==80,('Missing agent reports',80-len(reviewed_ids))
# Восемь полных вариантов: 72 новых текстовых/№7 + 144 уже существующих задания.
pools={}
pools[4]=sorted([t['id'] for t in tasks if t['line']==4])[:8]
for line in [5,6,8,*range(13,23)]:pools[line]=sorted(t['id'] for t in tasks if t['line']==line and t['id'].startswith('rus-2027-b80e') and t['status']!='on_hold')
pools[5]+=['rus-2027-b80c-05-0001'];pools[6]+=['rus-2027-b80b-06-0004','rus-2027-b80a-06-0007'];pools[8]+=['rus-2027-b80c-08-0003','rus-2027-b80c-08-0005'];pools[22]+=['rus-2027-b80b-22-0001','rus-2027-b80b-22-0004']
for line in range(13,22):pools[line]+=[f'rus-2027-b80c-{line:02}-0001',f'rus-2027-b80c-{line:02}-0002']
for line in [9,10,11,12]:pools[line]=sorted(t['id'] for t in tasks if t['line']==line and t.get('source')=='authored:rule-blueprints-r80-01')[:8]
variants=[]
for i in range(1,9):
 v={'id':f'ru-2027-F-v{i:03}','title':f'80F · вариант {i:03} · новые тексты','status':'draft','text_pair':[f'ru-2027-F-A{i:03}',f'ru-2027-F-B{i:03}'],'human_methodologist_accepted':False,'tasks':[]}
 for n in range(1,28):
  tid=f'rus-2027-b80f-{n:02}-{i:04}' if n in [1,2,3,7,23,24,25,26,27] else pools[n][i-1]
  t=copy.deepcopy(byid[tid]);assert t['line']==n and t['status']!='on_hold';t['no']=n;v['tasks'].append(t)
 variants.append(v)
assert len(tasks)==1067 and len(new)==80 and len(texts)==18
assert len(set(t['id'] for t in tasks))==len(tasks)
assert len(set(t['family'] for t in tasks))==len(tasks)
assert len(set(t['id'] for v in variants for t in v['tasks']))==216
for v in variants:assert len(v['tasks'])==27 and sum(t['max_score'] for t in v['tasks'])==50 and sum(t['max_score'] for t in v['tasks'] if t['no']<27)==28
for c in changes:c['after']=copy.deepcopy(byid[c['id']])
counts=collections.Counter(t['line'] for t in tasks);active=collections.Counter(t['line'] for t in tasks if t['status']!='on_hold')
summary={'date':'2026-11-11','batch':'80F','baseline':987,'new':80,'inventory':1067,'active_drafts':1066,'on_hold':1,'new_full_variants':8,'text_pairs_new':8,'text_pairs_total':9,'human_methodologist_accepted':0,'inventory_deficit_to_50_each_line':sum(max(50-counts[n],0) for n in range(1,28)),'active_deficit_to_50_each_line':sum(max(50-active[n],0) for n in range(1,28)),'changed_existing_records':sum(not c['id'].startswith('rus-2027-b80f') for c in changes),'changed_new_records':sum(c['id'].startswith('rus-2027-b80f') for c in changes),'old_9_12_needing_rework':sum(t.get('method_work_state')=='needs_rework_after_teacher_comments' for t in tasks)}
for name,a in [('tasks',tasks),('texts',texts),('variants',variants),('sources',sources),('new-tasks',[byid[t['id']] for t in new]),('batch-summary',summary),('patch-history',changes),('review-decisions',log),('text-history',{'before':[originaltexts[k] for k in sorted(changedtexts)],'changed_ids':sorted(changedtexts)})]:dump(O/(name+'.json'),a)
dump(O/'coverage.json',[{'line':n,'inventory':counts[n],'active':active[n],'target':50,'remaining':max(0,50-active[n])} for n in range(1,28)])
print(json.dumps(summary,ensure_ascii=False))
