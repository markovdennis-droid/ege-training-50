from pathlib import Path
import json,copy
W=Path('work/original50');R=W/'reviews'
def read(p):return json.loads(Path(p).read_text())
def dump(p,a):Path(p).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
N={};old={};TE={};S={};applied=[]
packets=['texts24-metadata-edits','texts24-findings','texts38-findings','texts10-style-edits','texts10-findings','texts24-style-edits','punct-approved-edits','punct-variety-edits','orth-baseline-findings','punct-baseline-findings','lex-matching-findings','old6-approved-edits','old5-approved-edits','root-baseline-text-edits','root-old8-edits','final22-findings','final-matching-overrides','old6-final-edits','root-final-edits']
for name in packets:
 p=R/(name+'.json')
 if not p.exists():continue
 a=read(p)
 if isinstance(a,dict):a=a.get('findings',a.get('edits',a.get('tasks',[])))
 for row in a:
  for src in row.get('sources',[]):
   if isinstance(src,dict):S[src['id']]=src
  tid=row.get('id',row.get('task_id'));reason=row.get('reason',row.get('finding',''))
  sentences=row.get('proposed_sentences')
  fields=copy.deepcopy(row.get('edit',row.get('proposed_fields',row.get('proposed_edit',{}))))
  if not tid:continue
  if tid.startswith('ru-2027-'):
   if sentences:
    dst=TE.setdefault(tid,{'id':tid,'sentences':{},'reason':[]});dst['sentences'].update(sentences);dst['reason'].append(reason)
   continue
  if not fields:continue
  dst=(N if tid.startswith('rus-2027-orig-') else old).setdefault(tid,{'id':tid,'edit':{},'reason':[]})
  refs=list(dict.fromkeys(dst['edit'].get('source_refs',[])+fields.get('source_refs',[])+row.get('source_refs',[])))
  dst['edit'].update(fields)
  if refs:dst['edit']['source_refs']=refs
  dst['reason'].append(reason);applied.append({'id':tid,'packet':name})
for name in ['texts24-sources','punct-review-extra-sources','lex-matching-sources','old6-approved-sources','old5-approved-sources','old6-final-sources']:
 p=R/(name+'.json')
 if p.exists():
  a=read(p);a=a.get('sources',[]) if isinstance(a,dict) else a
  for src in a:
   if isinstance(src,dict):S[src['id']]=src
# Additional source refs are additive, never destroy the source trail.
base=read(W/'baseline-tasks.json');new=[]
for p in (W/'authors').glob('*.json'):
 a=read(p)
 if isinstance(a,dict) and p.stem in ['texts10-23','texts24-37','texts38-50','lex','orth','punct']:new+=a['tasks']
by={t['id']:t for t in base+new}
for edits in [N,old]:
 for tid,ed in edits.items():
  if 'source_refs' in ed['edit']:ed['edit']['source_refs']=list(dict.fromkeys(by[tid]['source_refs']+ed['edit']['source_refs']))
  ed['reason']='; '.join(ed['reason'])
dump(W/'approved-edits.json',list(N.values()));dump(W/'approved-baseline-edits.json',list(old.values()));dump(W/'approved-text-edits.json',list(TE.values()));dump(W/'approved-sources.json',list(S.values()));dump(W/'integration-index.json',applied)
print(json.dumps({'new_task_edits':len(N),'baseline_edits':len(old),'texts_edited':len(TE),'new_sources':len(S)},ensure_ascii=False))
