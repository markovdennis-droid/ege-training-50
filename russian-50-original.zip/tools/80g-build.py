from pathlib import Path
import json,copy,hashlib,collections
W=Path('work/b80g');O=Path('output/b80g');O.mkdir(exist_ok=True,parents=True)
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
old=load('output/review-80ef/tasks.json');tasks=copy.deepcopy(old);sources=load('output/review-80ef/sources.json');texts=load('output/review-80ef/texts.json');new=[]
for name in ['lex','orth','punct']:
 a=load(W/f'authors/{name}.json');new+=copy.deepcopy(a['tasks'])
 for s in a['sources']:
  sid=s['id'];info={k:v for k,v in s.items() if k!='id'}
  if sid in sources and sources[sid]!=info:
   # Глобальные общеизвестные источники сохраняют общий ID; обе версии описания остаются в авторском файле.
   assert sources[sid].get('url')==info.get('url'),('source ID collision',sid)
  else:sources[sid]=info
source_history=[]
if (W/'approved-source-edits.json').exists():
 for entry in load(W/'approved-source-edits.json'):
  sid=entry['id'];old_info=copy.deepcopy(sources[sid]);sources[sid]={k:v for k,v in entry.items() if k!='id'};source_history.append({'id':sid,'before':old_info,'after':sources[sid]})
for info in sources.values():
 if isinstance(info,dict) and info.get('local_file','').startswith('lex-work/'):
  info['author_cache_path']=info.pop('local_file');info['archive_local_copy_included']=False
new.sort(key=lambda t:(t['line'],t['id']));authored=copy.deepcopy(new);bynew={t['id']:t for t in new};history=[];decisions=[]
hold=next(t for t in tasks if t['id']=='rus-2027-b80e-06-0003')
before_hold=copy.deepcopy(hold)
hold['on_hold_reason']='Не доказана обязательность исправления исходного словоупотребления. Предложенный иной фразеологический пример сохранён отдельным кандидатом и требует методического допуска. В проекте ФИПИ2027 №6 требуется сохранение смысла, а не прежняя дословная формула о близости значения. До разрешения нормативного вопроса задание исключено из вариантов и автоматической оценки.'
if hold!=before_hold:
 hold['version']=before_hold['version']+1
 history.append({'id':hold['id'],'before':before_hold,'after':copy.deepcopy(hold),'reason':'Уточнена причина отложения с учётом действующей формулировки проекта2027; нормативный вопрос не решён, статус on_hold сохранён.'})
patchfile=W/'approved-edits.json'
if patchfile.exists():
 for p in load(patchfile):
  t=bynew[p['id']];before=copy.deepcopy(t)
  for k,v in p['edit'].items():t[k]=copy.deepcopy(v)
  if t!=before:
   t['version']=before['version']+1
   if any(t.get(k)!=before.get(k) for k in ['stem','opts','left','left_markup','right']):
    t['replaces_family']=before['family'];t['family']='g-review-'+hashlib.sha256(json.dumps({k:t.get(k) for k in ['stem','opts','left','right']},ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:20]
   history.append({'id':t['id'],'before':before,'after':copy.deepcopy(t),'reason':p.get('reason')})
  decisions.append(p)
# Завершённые агентные решения — только рабочий статус, не человеческий допуск.
for name in ['lex','orth','punct']:
 report=W/f'reviews/{name}-ledger.json'
 if not report.exists():raise RuntimeError('Missing independent ledger: '+str(report))
 ledger=load(report);ledger=ledger.get('tasks',ledger.get('ledger',[])) if isinstance(ledger,dict) else ledger
 for r in ledger:
  tid=r.get('id',r.get('task_id'));assert tid in bynew,tid
  bynew[tid]['agent_review']={'state':'completed_draft','report':'reviews/80g/'+name+'-ledger.json','human_methodologist_accepted':False}
assert all('agent_review' in t for t in new)
for name in ['orth','punct','lex']:
 post=W/f'reviews/{name}-postfix.json'
 if post.exists():
  for t in new:
   if t['id'] in [x['id'] for x in decisions] and t['line'] in ({'orth':[13,14,15],'punct':[16,17,18,19,20,21],'lex':[5,6,8,22]}[name]):t['agent_review']['postfix_report']='reviews/80g/'+name+'-postfix.json'
for t in new:
 t['method_work_state']='agent_reviewed_draft_pending_human_methodologist';t.setdefault('reviewer_id',None);t.setdefault('reviewed_at',None)
 assert t['id'].startswith('rus-2027-b80g-') and t['status']=='draft' and t['allowed_2027'] is None
 assert not t['norm_basis']['confirmed']
 t['source_refs']=list(dict.fromkeys(t['source_refs']))
tasks+=new;by={t['id']:t for t in tasks}
assert len(tasks)==1147 and len(set(by))==1147 and len(new)==80
assert len({t['family'] for t in tasks})==1147
# Обновляем8 прежних текстовых комплектов80F. Новых пар текстов здесь нет.
variants=copy.deepcopy(load('output/review-80ef/variants.json'))
for i,v in enumerate(variants,1):
 v['previous_variant_id']=v['id'];v['id']=f'ru-2027-G-v{i:03}';v['title']=f'80G · вариант {i:03} · тексты80F';v['text_pair_origin']='80F; повторно использованные пары, не новые тексты'
 for j,t in enumerate(v['tasks']):
  n=t['no'];tid=f'rus-2027-b80g-{n:02}-{i:04}'
  if tid in bynew:v['tasks'][j]={**copy.deepcopy(bynew[tid]),'no':n}
 assert sum(t['max_score'] for t in v['tasks'])==50 and len(v['tasks'])==27
assert {t['id'] for v in variants for t in v['tasks'] if t['id'].startswith('rus-2027-b80g')}==set(bynew)
assert len({t['id'] for v in variants for t in v['tasks']})==216
count=collections.Counter(t['line'] for t in tasks);active=collections.Counter(t['line'] for t in tasks if t['status']!='on_hold')
for h in history:h['after']=copy.deepcopy(by[h['id']])
summary={'date':'2026-11-12','batch':'80G','baseline':1067,'new':80,'inventory':1147,'active_drafts':1146,'on_hold':1,'updated_full_variants':8,'new_text_pairs':0,'text_pairs_total':9,'human_methodologist_accepted':0,'active_deficit_to_50_each_line':sum(max(50-active[n],0) for n in range(1,28)),'old_9_12_needing_rework':511}
coverage=[{'line':n,'inventory':count[n],'active':active[n],'target':50,'remaining':max(0,50-active[n])} for n in range(1,28)]
for name,a in [('tasks',tasks),('new-tasks',new),('sources',sources),('texts',texts),('variants',variants),('batch-summary',summary),('coverage',coverage),('patch-history',history),('review-decisions',decisions),('source-history',source_history)]:dump(O/(name+'.json'),a)
print(json.dumps(summary,ensure_ascii=False))
