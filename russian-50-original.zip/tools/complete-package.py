from pathlib import Path
import json,shutil,zipfile,hashlib,re
O=Path('output/r80-02');B=O/'snapshot';W=Path('work/r80-02')
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
if not B.exists():shutil.copytree('output/b80g/snapshot',B)
for p in Path('output/b80g').glob('*.json'):
 d=B/'history/80g-final'/p.name;d.parent.mkdir(parents=True,exist_ok=True)
 if not d.exists():shutil.copyfile(p,d)
for p in (B/'bank/variants').glob('*.json'):
 d=B/'history/80g-final/variants'/p.name;d.parent.mkdir(exist_ok=True)
 if not d.exists() and not p.name.startswith('ru-2027-MIX-'):shutil.copyfile(p,d)
 p.unlink()
a=load(O/'tasks.json');texts=load(O/'texts.json');vs=load(O/'variants.json');P=load(O/'passports.json');ids={p['task_id'] for p in P}
for n in range(1,28):dump(B/f'bank/tasks/line-{n:02}.json',[t for t in a if t['line']==n])
for t in texts:dump(B/f'bank/texts/{t["id"]}.json',t)
for v in vs:dump(B/f'bank/variants/{v["id"]}.json',v)
dump(B/'bank/variants/index.json',[{'id':v['id'],'title':v['title'],'file':v['id']+'.json','status':'draft','parts_repeat_between_variants':True} for v in vs])
mat=B/'bank/material/r80-current';history=B/'history/pre-complete-rework-material'
if mat.exists() and not history.exists():shutil.copytree(mat,history)
mat.mkdir(parents=True,exist_ok=True)
for p in mat.glob('*'):
 if p.is_file():p.unlink()
for filename in ['passports','inventory','assembly-inventory','blueprints','checks']:
 shutil.copyfile(O/(filename+'.json'),mat/(filename+'.json'))
dump(mat/'tasks.json',[t for t in a if t['id'] in ids])
for name in ['tasks','new-tasks','texts','variants','variants-report','revised-tasks','first80-tasks','sources','batch-summary','passports','inventory','assembly-inventory','patch-history','blueprints','bulk-report','checks','core-checks','render-checks']:
 if (O/(name+'.json')).exists():shutil.copyfile(O/(name+'.json'),B/(name+'.json'))
for sub,dest in [('authors','history/author-rework'),('scripts','history/author-rework/scripts'),('reviews','reviews/rework-9-12'),('input','history/rework-input')]:
 for p in (W/sub).glob('*'):
  if p.is_file():d=B/dest/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for name in ['CONTRACT.md','approved-item-edits.json']:
 shutil.copyfile(W/name,B/name)
for name in ['build.py','bulk_rework.py','assemble50.py','validate.py','package.py','make_html.py','test_core.cjs','test_render.cjs']:
 if (W/name).exists():shutil.copyfile(W/name,B/'tools'/('complete-'+name))
portable=(W/'validate.py').read_text().replace("O=Path('output/r80-02')","O=Path(__file__).resolve().parent.parent").replace("Path('output/b80g/tasks.json')","(O/'history/80g-final/tasks.json')")
(B/'tools/validate_snapshot.py').write_text(portable)
(B/'tools/README.md').write_text('Актуальная проверка: python3 tools/validate_snapshot.py. Сборщик50: python3 tools/complete-assemble50.py --tasks tasks.json --texts texts.json --output other-variants.json --seed 20271112 --count 50. Выходные комбинации не считаются новыми авторскими заданиями. Полный процесс и его исходные рабочие пути сохранены вcomplete-build.py/complete-bulk_rework.py.\n')
readme='''# Русский язык: завершение переработки9–12 и50смешанных билетов

12.11.2026. Один файл russian-rework-9-12.html содержит банк, ключи, разборы, тренировку букв, заметки и полный скачиваемый архив. Работает без сети.

## Результат

511 записей из очереди9–12 переработаны;80 ранее переработанных записей также уточнены по новому аудиту. Теперь у всех591 задания9–12 есть актуальные паспорта:2955рядов,7310пропусков. В полном банке1147ID; новыхID эта работа не добавляла. Старые записи, PDF и предыдущие снимки сохранены вhistory/sources.

80 редакций отдельно решены независимыми агентами. Ещё431 комбинация построена из аудированного инвентаря и проверена алгоритмически, включая независимые реализации проверки. Это не заявляется ручным решением431 задания. Аудит инвентаря раскрывает свои источники, степень подтверждения и ограничения. Все заданияdraft,needs_source=true,allowed_2027=null,norm_basis.confirmed=false до внешней методической приёмки. Экзаменационная сложность на учениках не измерялась.

## Требования методиста

Каждый ряд собирается внутри общей группы правил/контраста. В неверных тройках9/10 две одинаковые буквы и одна другая; классы пропуска однородны. Впервые выявленные альтернативы (касаться/кусаться, картина/куртина, столик/столок, пробовать/пробивать, инъекция/инфекция, барьер/бартер и др.) устранены контекстом в самом условии. Группаsign не трактуется как невидимый запрет вставить согласную. В11 точнее разобраны суффиксы/беглые гласные, в12 — спряжение и формы; не используются подсказки одной глагольной основы в пределах задания. Источник формата отделён от нормативного источника.

Ключи вычислены из букв. opts/exp/drill/words/passports/blueprints согласованы.2955рядов не повторяются набором слов. В каждой линии внутри отдельной группы до20задач форма встречается не более4раз; по всему большому банку повтор отдельных слов допустим и не выдаётся за новое языковое явление.

## 50билетов: что означает миксование

Собраны50уникальных полных комбинаций1–27, включая сочинение. Девять коротких текстов сохраняют свои вопросы1–3; девять основных — вопросы23–27. Выбраны50разных пар короткого/основного текста, каждый текст встречается5–6раз.4–22 выбираются по одной позиции своей линии. Колода исчерпывается до повторного выбора; на9–12 для50билетов взяты50разныхID каждой линии.

В50билетах1350позиций, но755разныхID и595повторных включений. Это50комбинаций, а не50полностью неповторяющихся авторских комплектов. Для полностью нового наполнения50 вариантов всё ещё нужен дальнейший набор текстов и заданий. Программаassemble50.py воспроизводит комбинации поseed и честно отказывает при нехватке подходящих блоков или линий. Тестовыеfixture, в которых менялись статусы, в этот снимок не входят.

Каждый билет28баллов часть1 +22сочинение. Автоматической проверки сочинения здесь нет. Открытые ключи маршрутизируют неизвестный ответ на ручную проверку. Одно старое спорное№6 on_hold исключено из вариантов.

## Данные и продолжение

Актуальныеtasks.json иbank/tasks; revised-tasks.json —511редакций из очереди; first80-tasks.json — отдельно решённая первая80; passports/blueprints — все591. assembly-inventory.json — пул для алгоритмической сборки431, inventory.json — все фактически использованные паспортные элементы. Авторские исходники, отчёты проверок, координатные исправления и до/после сохранены.

Неведомые исходные версииPDF остаютсяnull, изменения отмеченыrecovery_revision; известные версии повышены. При замене материала сохраняетсяreplaces_family. Вhistory/80g-final — полный прежний снимок1147ID. Подменять этим архивом работающий сервер приложения не следует: это контентная сборка для проверки и переноса.

## Проверки

Проверены структура, нормативные аннотации и их согласованность, все ключи, отсутствие полных повторов рядов/семейств, лимиты использования слов и целостность текстовых блоков. Варианты и повторы подробно вvariants-report.json. Реальный score() извлекается из итоговогоHTML и проверяется вNodeVM, отдельно выполняется функциональный проход рендера с модельюDOM. Это не визуальная проверка браузером. Результаты вchecks/core-checks/render-checks, полный архив проверяетсяCRC иSHA256SUMS.json. Методическая приёмка человеком остаётся отдельной стадией.
'''
readme=re.sub(r'(?<=\d)(?=[А-Яа-яЁё])|(?<=[А-Яа-яЁё])(?=\d)',' ',readme)
(B/'README.md').write_text(readme)
marker='# Дополнение12.11.2026: переработка9–12 и50смешанных билетов';p=B/'РЕШЕНИЯ.md';txt=p.read_text()
if marker not in txt:p.write_text(txt+'\n\n'+marker+'\n\nЗакрыта очередь511редакций, уточнены прежние80. Первые80 решены агентами,431собраны по аудированному инвентарю и проверены программно.50смешанных комбинаций не считаются50неповторяющимися авторскими комплектами. Всеdraft до внешней приёмки.\n')
sha={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(B.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};dump(B/'SHA256SUMS.json',sha)
with zipfile.ZipFile(O/'russian-rework-9-12.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(B))
print('Snapshot files',len(sha),'ZIP bytes',(O/'russian-rework-9-12.zip').stat().st_size)
