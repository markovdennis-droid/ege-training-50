from pathlib import Path
import json,hashlib,shutil,zipfile
W=Path('work/original50');O=Path('output/original50');B=O/'snapshot'
def read(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
if not B.exists():shutil.copytree('output/r80-02/snapshot',B)
# Preserve the previous combinations, which are not the current original variants.
h=B/'history/pre-original50';h.mkdir(parents=True,exist_ok=True)
for name in ['README.md','СТАТУС.md','tasks.json','new-tasks.json','texts.json','variants.json','variants-report.json','revised-tasks.json','first80-tasks.json','batch-summary.json','checks.json','core-checks.json','render-checks.json','sources.json','SHA256SUMS.json']:
 p=B/name
 if p.exists() and not (h/name).exists():shutil.copyfile(p,h/name)
for p in (B/'bank/variants').glob('*.json'):p.unlink()
A=read(O/'tasks.json');T=read(O/'texts.json');V=read(O/'variants.json')
for n in range(1,28):dump(B/f'bank/tasks/line-{n:02}.json',[t for t in A if t['line']==n])
for t in T:dump(B/f'bank/texts/{t["id"]}.json',t)
for v in V:dump(B/f'bank/variants/{v["id"]}.json',v)
dump(B/'bank/variants/index.json',[{'id':v['id'],'title':v['title'],'file':v['id']+'.json','status':'draft','task_ids_repeat_between_variants':False,'human_methodologist_accepted':False} for v in V])
for p in O.glob('*.json'):shutil.copyfile(p,B/p.name)
# Remove superseded top-level combination claims, retaining them under history.
for name in ['variants-report.json','revised-tasks.json','first80-tasks.json']:
 p=B/name
 if p.exists():p.unlink()
for sub,dest in [('authors','history/original50-authors'),('reviews','reviews/original50'),('stress','history/stress-refresh')]:
 for p in (W/sub).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:
   d=B/dest/p.relative_to(W/sub);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for name in ['CONTRACT.md','TARGET.json','approved-edits.json','approved-text-edits.json','approved-baseline-edits.json','approved-sources.json']:
 p=W/name
 if p.exists():shutil.copyfile(p,B/('original50-'+name))
for name in ['build.py','validate.py','package.py','make_html.py','test_core.cjs','test_render.cjs','integrate.py','review_gate.py']:
 p=W/name
 if p.exists():shutil.copyfile(p,B/'tools'/('original50-'+name))
portable=(W/'validate.py').read_text().replace("O=Path('output/original50')","O=Path(__file__).resolve().parent.parent")
(B/'tools/validate_snapshot.py').write_text(portable)
(B/'tools/README.md').write_text('Актуальный снимок: python3 tools/validate_snapshot.py. Исходники сборки original50-* сохранены с рабочими путями. Прежний complete-assemble50.py создаёт смешанные комбинации и не является сборщиком текущих50 оригинальных билетов.\n')
readme='''# Русский язык: 50 оригинальных полных вариантов

13.11.2026. В этой контентной сборке 50 полных вариантов по27 заданий, включая сочинение. Между вариантами не повторяются ID, семейства и сами тексты.1350 выбранных заданий,50 коротких и50 основных текстов. Весь банк1742 записи:1741 активная и1 отложенная;391 активная запись линий9–12 остаётся в резерве.

## Что добавлено

595 новых заданий и41 новая пара авторских текстов. Предыдущие9 пар сохранены; номера10–50 дополняют их до50. Перемешивание старых заданий не включается в число новых. Прежние50 смешанных комбинаций перенесены вhistory/pre-original50.

Задания9–12 сохраняют завершённую переработку всех591 записей и2955 рядов с7310 пропусками по замечаниям методиста. В неверных тройках9/10 две одинаковые буквы и одна другая, материал сопоставляет правила; контексты разграничивают разные нормативные восстановления. Паспорта, аудированный инвентарь, исходныеPDF и история сохранены.50 заданий4 заново сверены с орфоэпическим перечнем ФИПИ2026. Допуск по окончательной редакции2027 не утверждён.

## Проверка и статусы

Все задания остаютсяdraft/needs_source до приёмки человеком. Авторские, независимые агентные и программные проверки различены в отчётах. Они не заменяют методическую приёмку и измерение трудности на учениках. Число разныхID не доказывает семантическую непохожесть само по себе: дополнительно проверяются содержание, сюжеты, полные упражнения и совпадения текстовых фрагментов; повтор отдельных экзаменационных правил неизбежен и не считается новым правилом.

Каждый вариант:28 баллов за задания1–26 и22 за сочинение. Сочинение оценивается вручную. Открытые лексические ключи отправляют неизвестный ответ на ручную проверку без автоматического нуля. Отложенное задание не включено в варианты.

## ОдинHTML

russian-50-original.html работает без сети:50 билетов, весь банк, ключи и объяснения с закрытым по умолчанию просмотром, исходные тексты, ориентиры для сочинений, ответы и заметки преподавателя. Кнопка скачивает полныйZIP с актуальнымиJSON, исходнымиPDF, историей и программами проверки. Это контентная сборка для рецензирования и переноса в приложение, не сервер приложения.

Актуальные данные:tasks.json,texts.json,variants.json,sources.json. Новая партия: new-tasks.json. Контроль состава:coverage.json,originality-report.json,checks.json. Изменения:patch-history.json,baseline-patch-history.json,stress-refresh-history.json,text-history.json. Отчёты проверяющих:reviews/original50. Проверка целостности:SHA256SUMS.json.
'''
import re
readme=re.sub(r'(?<=\d)(?=[А-Яа-яЁё])|(?<=[А-Яа-яЁё])(?=\d)',' ',readme)
(B/'README.md').write_text(readme);(B/'СТАТУС.md').write_text(readme)
p=B/'РЕШЕНИЯ.md';mark='# 12.11.2026: цель50 оригинальных билетов'
if mark not in p.read_text():p.write_text(p.read_text()+'\n\n'+mark+'\n\n50полных комплектов1350разныхID/family,100разныхтекстов. Перестановки и повторные включения не увеличивают этот счёт. Добавлены595новыхзаданий и41пара текстов. Всеdraft до внешней методической приёмки.\n')
sha={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(B.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};dump(B/'SHA256SUMS.json',sha)
with zipfile.ZipFile(O/'russian-50-original.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(B))
with zipfile.ZipFile(O/'russian-50-original.zip') as z:
 assert z.testzip() is None
 for name,digest in sha.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
print(json.dumps({'files':len(sha),'zip_bytes':(O/'russian-50-original.zip').stat().st_size,'crc_and_sha256':'pass'}))
