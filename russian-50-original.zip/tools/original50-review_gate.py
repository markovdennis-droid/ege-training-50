from pathlib import Path
import json,hashlib
W=Path('work/original50');O=Path('output/original50')
A=json.loads((O/'new-tasks.json').read_text());ids={t['id'] for t in A};covered=set();reports=[]
for p in (W/'reviews').glob('*-ledger.json'):
 a=json.loads(p.read_text());rows=a if isinstance(a,list) else a.get('tasks',a.get('ledger',[]));found={r.get('id',r.get('task_id')) for r in rows};covered|=found;reports.append({'file':p.name,'rows':len(rows),'new_task_ids':len(ids&found),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
missing=sorted(ids-covered)
r={'new_task_ids':len(ids),'new_task_ids_with_review_records':len(ids&covered),'missing':missing,'reports':reports,'human_methodologist_accepted':False,'interpretation':'Наличие отдельного протокола проверки не равно человеческой приёмке. Первоначальные замечания сохранены; редакции находятся в patch-history/text-history.'}
(O/'review-coverage.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
assert not missing,('Independent review records still missing',len(missing),missing[:5])
print('Review records:',len(ids),'of',len(ids),'; human acceptance: false')
