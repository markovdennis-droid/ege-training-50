from pathlib import Path
import json,re,collections,html,hashlib
P=Path('output/review-80ef')
def load(n):return json.loads((P/n).read_text())
a=load('tasks.json');new=load('new-tasks.json');texts=load('texts.json');vs=load('variants.json');ss=load('sources.json');by={t['id']:t for t in a};tb={t['id']:t for t in texts}
assert len(a)==1067 and len(by)==1067 and len(new)==80 and len(texts)==18 and len(vs)==8
assert len({t['family'] for t in a})==1067
for t in a:
 assert type(t['line']) is int and 1<=t['line']<=27,t['id'];assert t['stem'] and t['status'] in ['draft','on_hold'];assert all(s in ss for s in t['source_refs']),(t['id'],t['source_refs'])
 assert t['max_score']==(22 if t['line']==27 else 2 if t['line'] in [8,22] else 1)
 assert t['answer_type']==('essay' if t['line']==27 else 'seq' if t['line'] in [8,22] else 'word' if t['line'] in [1,5,6,7,25] else 'digits'),t['id']
 if t['line']!=27:assert t['key'] and all(isinstance(k,str) and k for k in t['key'])
 if t.get('text'):assert t['text'] in tb
 if t['answer_type']=='seq':
  assert len(t['left'])==5 and len(t['right'])==9 and all(len(k)==5 and set(k)<=set('123456789') and len(set(k))==5 for k in t['key']),t['id']
  if t.get('left_markup'):assert [html.unescape(re.sub('</?b>','',s)) for s in t['left_markup']]==t['left'],t['id']
for t in new:
 assert t['status']=='draft' and t['needs_source'] and t['allowed_2027'] is None and not t['norm_basis']['confirmed']
 assert type(t['version']) is int and t['version']>=1 and t['source_refs'] and t['norm_basis']['rule_source']
 if t['line'] in [1,2,3,23,24,25,26,27]:assert t['text_version']==tb[t['text']]['version'],t['id']
 if t.get('opts'):assert len(t['opts'])==5
 if t['line']==7:assert all(len(re.findall(r'\b[А-ЯЁ]{2,}\b',s))==1 for s in t['opts']),t['id']
 if t['line']==27:
  assert t['author_position'] and t['problem'] and len(t['essay_guide']['pairs'])>=2
  for pair in t['essay_guide']['pairs']:
   for lo,hi in pair['examples']:assert 1<=lo<=hi<=len(tb[t['text']]['sentences'])
 for m in re.finditer(r'предложени[яй]\s+(\d+)\s*[–—-]\s*(\d+)',t['stem'],re.I):assert 1<=int(m[1])<=int(m[2])<=len(tb[t['text']]['sentences']),t['id']
# Технический контроль 80E после редакций.
for t in a:
 if not t['id'].startswith('rus-2027-b80e'):continue
 n=t['line'];k=t['key'][0];e=t.get('evidence',{})
 if n==8:assert e['left_types']==[e['error_types_by_right'][int(c)-1] for c in k]
 if n in [13,14]:assert k==''.join(str(j) for j,b in enumerate(e['joined_by_option'],1) if b)
 if n==15:assert k==''.join(str(j) for j,s in enumerate(e['letters_by_slot'],1) if s=='нн')
 if n==16:assert k==''.join(str(j) for j,s in enumerate(e['punctuated_options'],1) if s.count(',')==1),t['id']
 if 17<=n<=20:assert k==''.join(str(j) for j,b in enumerate(e['comma_by_slot'],1) if b),t['id']
 if n==21:assert k==''.join(str(j) for j,r in enumerate(e['rule_by_option'],1) if r==e['shared_rule'])
 if n==22:assert [t['right'][int(c)-1] for c in k]==e['term_by_left'],t['id']
used=[]
for v in vs:
 assert len(v['tasks'])==27 and [t['no'] for t in v['tasks']]==list(range(1,28))
 assert sum(t['max_score'] for t in v['tasks'] if t['no']<27)==28 and v['tasks'][-1]['max_score']==22
 assert len({t['family'] for t in v['tasks']})==27
 for t in v['tasks']:
  assert t['status']!='on_hold';assert {k:val for k,val in t.items() if k!='no'}==by[t['id']],t['id'];used.append(t['id'])
assert len(set(used))==216
for key in ['stem','opts','left']:
 bins=collections.defaultdict(list)
 for t in a:
  if key not in t:continue
  # Общие условия модели не являются повтором; проверяем цельный материал.
  body=(t.get('stem',''),t.get('opts'),t.get('left'),t.get('text'))
  if key!='stem':body=t[key]
  h=json.dumps(body,ensure_ascii=False,sort_keys=True);bins[h].append(t['id'])
 duplicates=[ids for ids in bins.values() if len(ids)>1 and any('b80f' in i for i in ids)]
 assert not duplicates,(key,duplicates)
r={'inventory':1067,'new':80,'on_hold':sum(t['status']=='on_hold' for t in a),'unique_ids':1067,'unique_families':1067,'new_full_variants':8,'new_unique_text_pairs':8,'new_task_ids_used_in_variants':sum('b80f' in i for i in used),'remaining_new7_in_bank':8,'variant_total_each':50,'part1_each':28,'essay_each':22,'source_registry_complete':True,'answer_evidence_80e_recomputed':True,'original_version_unknown':sum(t.get('version') is None for t in a),'human_methodologist_acceptance':False,'browser_visual_check':'not performed; prior Chromium launch blocked by environment socket restriction'}
(P/'duplicate-checks.json').write_text(json.dumps({'new80f_exact_full_task_duplicates':0,'new80f_option_set_duplicates':0,'new80f_matching_left_duplicates':0,'all_bank_unique_ids':1067,'all_bank_unique_families':1067,'scope':'Exact content checks against all1067; semantic language-fact duplicates not exhaustively classified.'},ensure_ascii=False,indent=2)+'\n')
(P/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
