from pathlib import Path
import json,copy,collections,hashlib,re
W=Path('work/original50');O=Path('output/original50');O.mkdir(exist_ok=True,parents=True)
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
A=load(W/'baseline-tasks.json');T=load(W/'baseline-texts.json');S=load(W/'baseline-sources.json');N=[];NT=[]
files=['texts10-23','texts24-37','texts38-50','lex','orth','punct']
for name in files:
 p=W/f'authors/{name}.json'
 if not p.exists():raise RuntimeError('Author packet incomplete: '+str(p))
 a=load(p);N+=copy.deepcopy(a['tasks']);NT+=copy.deepcopy(a.get('texts',[]))
 for entry in a['sources']:
  sid=entry['id'];info={k:v for k,v in entry.items() if k!='id'};info.setdefault('title','Источник '+sid)
  if sid in S and S[sid]!=info:assert S[sid].get('url')==info.get('url'),('source collision',sid)
  else:S[sid]=info
assert len(N)==595 and len(NT)==82,(len(N),len(NT))
bynew={t['id']:t for t in N};assert len(bynew)==595
if (W/'approved-sources.json').exists():
 for entry in load(W/'approved-sources.json'):
  S[entry['id']]={k:v for k,v in entry.items() if k!='id'};S[entry['id']].setdefault('title','Источник '+entry['id'])
history=[]
stress_history=[]
if (W/'stress/tasks.json').exists():
 refresh={t['id']:t for t in load(W/'stress/tasks.json')};A=[copy.deepcopy(refresh.get(t['id'],t)) for t in A];stress_history=load(W/'stress/history.json');entry=load(W/'stress/source.json');S[entry['id']]={k:v for k,v in entry.items() if k!='id'}
baseline_history=[]
if (W/'approved-baseline-edits.json').exists():
 oldby={t['id']:t for t in A}
 for e in load(W/'approved-baseline-edits.json'):
  t=oldby[e['id']];before=copy.deepcopy(t);t.update(copy.deepcopy(e['edit']))
  if t!=before:
   if type(before.get('version')) is int:t['version']=before['version']+1
   else:t['recovery_revision']=int(before.get('recovery_revision',0))+1
   if any(t.get(k)!=before.get(k) for k in ['stem','opts','left','right','text','left_markup']):
    t['replaces_family']=before['family'];t['family']='original50-baseline-review-'+hashlib.sha256(json.dumps([t.get(k) for k in ['stem','opts','left','right','text']],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:20]
   baseline_history.append({'id':t['id'],'before':before,'after':copy.deepcopy(t),'reason':e.get('reason')})
if (W/'approved-edits.json').exists():
 for e in load(W/'approved-edits.json'):
  t=bynew[e['id']];before=copy.deepcopy(t);t.update(copy.deepcopy(e['edit']))
  if t!=before:
   t['version']=before['version']+1
   if any(t.get(k)!=before.get(k) for k in ['stem','opts','left','right','text','left_markup']):
    t['replaces_family']=before['family'];t['family']='original50-review-'+hashlib.sha256(json.dumps([t.get(k) for k in ['stem','opts','left','right','text']],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:20]
   history.append({'id':t['id'],'before':before,'after':copy.deepcopy(t),'reason':e.get('reason')})
textby={t['id']:t for t in NT};text_history=[]
if (W/'approved-text-edits.json').exists():
 for e in load(W/'approved-text-edits.json'):
  t=textby[e['id']];before=copy.deepcopy(t)
  for num,val in e['sentences'].items():t['sentences'][int(num)-1]=val
  t['version']=before['version']+1;text_history.append({'id':t['id'],'before':before,'after':copy.deepcopy(t)})
if (W/'reviews/texts24-sources.json').exists():
 for binding in load(W/'reviews/texts24-sources.json').get('text_bindings',[]):
  t=textby[binding['text_id']];t['source_refs']=list(dict.fromkeys(t.get('source_refs',[])+binding.get('source_refs_add',[])));t['science_fact_verification']=binding.get('science_fact_verification');t['science_verification_limits']=binding.get('limitations')
A+=N;T+=NT;by={t['id']:t for t in A};tb={t['id']:t for t in T};assert len(A)==1742 and len(by)==1742 and len(T)==100 and len(tb)==100
for t in N:
 assert t['status']=='draft' and t['allowed_2027'] is None and not t['norm_basis']['confirmed']
 assert t['id'].startswith('rus-2027-orig-')
 if t.get('text'):t['text_version']=tb[t['text']]['version']
 t.setdefault('reviewer_id',None);t.setdefault('reviewed_at',None);t['source_refs']=list(dict.fromkeys(t['source_refs']))
 t['method_work_state']='original_author_draft_pending_independent_review'
# Agent reports are attached without granting human approval.
for report in (W/'reviews').glob('*-ledger.json'):
 a=load(report);rows=a.get('tasks',a.get('ledger',[])) if isinstance(a,dict) else a
 for r in rows:
  tid=r.get('id',r.get('task_id'))
  if tid in bynew:bynew[tid]['agent_review']={'state':'completed_draft','report':'reviews/original50/'+report.name,'human_methodologist_accepted':False};bynew[tid]['method_work_state']='agent_reviewed_original_draft_pending_human_methodologist'
# Pair A/B by their stable original text identifiers.
def pair_rank(tid):
 if tid.startswith('ru-2027-O-A'):return int(tid[-3:])
 if tid.startswith('ru-2027-F-A'):return int(tid[-3:])+1
 if tid=='ru-2027-A001':return 1
 raise ValueError(('unrecognised short text',tid))
blocks={}
for t in A:
 if t.get('text') and t['line'] in [1,2,3,23,24,25,26,27]:
  blocks.setdefault(t['text'],{})
  assert t['line'] not in blocks[t['text']],('duplicate line in text block',t['text'],t['line'])
  blocks[t['text']][t['line']]=t
pairs=[]
for aid,b in blocks.items():
 if set(b)=={1,2,3}:
  bid=aid.replace('-A','-B');assert bid in blocks and set(blocks[bid])=={23,24,25,26,27}
  pairs.append((pair_rank(aid),aid,bid))
pairs.sort();assert [p[0] for p in pairs]==list(range(1,51))
# Exactly one use of every selected task/family across50 variants.
pools={}
for n in range(4,23):
 p=[t for t in A if t['line']==n and t['status']!='on_hold' and t.get('method_work_state')!='needs_rework_after_teacher_comments']
 assert len(p)>=50,('insufficient line',n,len(p))
 if n in [9,10,11,12]:
  # Spread choices across the full, reworked line rather than taking one consecutive block.
  p=sorted(p,key=lambda t:t['id']);p=[p[(i*len(p))//50] for i in range(50)]
 else:p=sorted(p,key=lambda t:t['id'])[:50]
 assert len({t['id'] for t in p})==50
 pools[n]=p
V=[];used=set();families=set();usedtexts=set()
for i,aid,bid in pairs:
 v={'id':f'ru-2027-ORIGINAL-v{i:03}','title':f'Оригинальный вариант {i:03}','status':'draft','original_pair_index':i,'text_pair':[aid,bid],'task_ids_repeat_between_variants':False,'human_methodologist_accepted':False,'tasks':[]}
 for n in range(1,28):
  t=blocks[aid][n] if n<4 else blocks[bid][n] if n>22 else pools[n][i-1]
  assert t['id'] not in used and t['family'] not in families,(i,n,t['id'])
  used.add(t['id']);families.add(t['family']);v['tasks'].append({**copy.deepcopy(t),'no':n})
 assert aid not in usedtexts and bid not in usedtexts;usedtexts.update([aid,bid]);V.append(v)
assert len(used)==1350 and len(usedtexts)==100 and len(V)==50
for h in history:h['after']=copy.deepcopy(by[h['id']])
summary={'date':'2026-11-13','goal':'50original_full_variants','baseline_records':1147,'new_records':595,'inventory':1742,'active_records':1741,'on_hold':1,'original_variants':50,'selected_unique_task_ids':1350,'selected_unique_families':1350,'selected_unique_texts':100,'existing_stress_tasks_refreshed':len(stress_history),'new_text_pairs':41,'total_text_pairs':50,'repeated_task_ids_between_variants':0,'repeated_texts_between_variants':0,'human_methodologist_accepted':0,'new_ids':sorted(bynew)}
C=collections.Counter(t['line'] for t in A if t['status']!='on_hold');coverage=[{'line':n,'active':C[n],'selected':50,'target':50,'deficit':max(0,50-C[n])} for n in range(1,28)]
for name,a in [('tasks',A),('new-tasks',N),('texts',T),('sources',S),('variants',V),('batch-summary',summary),('patch-history',history),('baseline-patch-history',baseline_history),('stress-refresh-history',stress_history),('text-history',text_history),('coverage',coverage)]:dump(O/(name+'.json'),a)
dump(O/'originality-report.json',{'variants':50,'selected_task_ids':len(used),'selected_families':len(families),'selected_texts':len(usedtexts),'repeated_ids':0,'repeated_families':0,'repeated_texts':0,'unused_active_records':1741-1350,'on_hold':1,'human_methodologist_acceptance':False})
print(json.dumps({k:v for k,v in summary.items() if k!='new_ids'},ensure_ascii=False))
