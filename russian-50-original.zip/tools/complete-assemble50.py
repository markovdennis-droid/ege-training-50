#!/usr/bin/env python3
"""Build 50 reproducible mixed draft variants; never creates new authored tasks.

Example:
  python work/r80-02/assemble50.py --tasks output/r80-02/tasks.json \
    --texts output/r80-02/texts.json --output output/r80-02/variants.json \
    --seed 20271112 --count 50

The sibling <output-stem>-report.json records actual reuse. All source and
in-memory output checks run before creating any output file or directory.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from collections import Counter, defaultdict
from pathlib import Path
import random
import sys
import tempfile

SHORT_LINES = (1, 2, 3)
MAIN_LINES = (23, 24, 25, 26, 27)
INDEPENDENT_LINES = tuple(range(4, 23))
REWORK = "needs_rework_after_teacher_comments"


class AssemblyError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise AssemblyError(message)


def read_bank(path):
    raw = path.read_bytes()
    data = json.loads(raw)
    require(isinstance(data, list), f"{path}: expected a JSON array")
    require(all(isinstance(item, dict) for item in data), f"{path}: expected objects")
    return data, hashlib.sha256(raw).hexdigest()


def eligibility(task):
    if task.get("status") != "draft":
        return "status_not_draft"
    if task.get("on_hold") or task.get("method_work_state") == "on_hold":
        return "on_hold"
    if task.get("method_work_state") == REWORK:
        return REWORK
    return None


def score_for_line(line):
    return 22 if line == 27 else 2 if line in (8, 22) else 1


def source_blocks(tasks, texts):
    text_by_id = {}
    for text in texts:
        text_id = text.get("id")
        require(isinstance(text_id, str) and text_id, "Text has no nonempty string id")
        require(text_id not in text_by_id, f"Duplicate text id: {text_id}")
        require(text.get("kind") in ("short", "main"), f"Unknown text kind: {text_id}")
        require(text.get("status") == "draft", f"Text is not draft: {text_id}")
        require(isinstance(text.get("sentences"), list) and text["sentences"]
                and all(isinstance(s, str) and s.strip() for s in text["sentences"]),
                f"Empty or malformed text: {text_id}")
        text_by_id[text_id] = text
    by_text_line = defaultdict(list)
    by_line = defaultdict(list)
    exclusions = Counter()
    ids = set()
    for task in tasks:
        task_id = task.get("id")
        require(isinstance(task_id, str) and task_id, "Task has no nonempty string id")
        require(task_id not in ids, f"Duplicate task id: {task_id}")
        ids.add(task_id)
        line = task.get("line")
        require(type(line) is int and 1 <= line <= 27, f"Invalid task line: {task_id}")
        reason = eligibility(task)
        if reason:
            exclusions[reason] += 1
            continue
        require(isinstance(task.get("family"), str) and task["family"],
                f"Missing family: {task_id}")
        require(type(task.get("max_score")) is int
                and task["max_score"] == score_for_line(line),
                f"Unexpected max_score on line {line}: {task_id}")
        if line in SHORT_LINES + MAIN_LINES:
            text_id = task.get("text")
            require(text_id in text_by_id, f"Unknown text reference: {task_id}: {text_id}")
            expected_kind = "short" if line in SHORT_LINES else "main"
            require(text_by_id[text_id]["kind"] == expected_kind,
                    f"Task/text kind mismatch: {task_id}")
            by_text_line[text_id, line].append(task)
        else:
            require(not task.get("text"),
                    f"Independent line has a text dependency: {task_id}")
            by_line[line].append(task)
    blocks = {}
    for kind, lines in (("short", SHORT_LINES), ("main", MAIN_LINES)):
        kind_ids = sorted(t["id"] for t in texts if t["kind"] == kind)
        require(len(kind_ids) == 9, f"Need exactly 9 {kind} texts; found {len(kind_ids)}")
        blocks[kind] = []
        for text_id in kind_ids:
            block = []
            for line in lines:
                options = by_text_line[text_id, line]
                require(len(options) == 1,
                        f"Need exactly one eligible line {line} task for {text_id}; found {len(options)}")
                block.append(options[0])
            require(len({t["family"] for t in block}) == len(block),
                    f"Repeated family within text block: {text_id}")
            blocks[kind].append((text_id, block))
    for line in INDEPENDENT_LINES:
        by_line[line].sort(key=lambda task: task["id"])
        require(by_line[line], f"No eligible draft tasks on line {line}")
    # These four expanded lines must not repeat an ID across the 50 variants.
    for line in (9, 10, 11, 12):
        require(len(by_line[line]) >= 50,
                f"Line {line}: need at least 50 eligible draft IDs for a no-repeat run; "
                f"found {len(by_line[line])}")
    return blocks, by_line, exclusions


def balanced_pairs(short_blocks, main_blocks, rng, count):
    # The nine cyclic diagonals partition K(9,9). Five complete diagonals
    # contribute 45 pairs (degree 5 per text); five edges of a sixth add
    # one occurrence to five distinct texts on each side.
    a_order = list(range(9))
    b_order = list(range(9))
    shifts = list(range(9))
    rng.shuffle(a_order)
    rng.shuffle(b_order)
    rng.shuffle(shifts)
    whole, extra = divmod(count, 9)
    pairs = [(a_order[i], b_order[(i + shift) % 9])
             for shift in shifts[:whole] for i in range(9)]
    extra_rows = list(range(9))
    rng.shuffle(extra_rows)
    if extra:
        pairs.extend((a_order[i], b_order[(i + shifts[whole]) % 9])
                     for i in extra_rows[:extra])
    rng.shuffle(pairs)
    require(len(set(pairs)) == count, "Internal error: repeated text pair")
    for ai, bi in pairs:
        fixed = short_blocks[ai][1] + main_blocks[bi][1]
        require(len({t["family"] for t in fixed}) == 8,
                f"Text pair has conflicting families: {short_blocks[ai][0]}, {main_blocks[bi][0]}")
    return pairs


def select_independent(decks, fixed):
    """Backtrack only if families conflict across lines; preserve deck cycles."""
    used_families = {t["family"] for t in fixed}
    used_ids = {t["id"] for t in fixed}
    selected = {}

    def visit(remaining):
        if not remaining:
            return True
        choices = {line: [t for t in decks[line]
                          if t["family"] not in used_families and t["id"] not in used_ids]
                   for line in remaining}
        line = min(remaining, key=lambda n: (len(choices[n]), n))
        for task in choices[line]:
            selected[line] = task
            used_families.add(task["family"])
            used_ids.add(task["id"])
            if visit(tuple(n for n in remaining if n != line)):
                return True
            used_families.remove(task["family"])
            used_ids.remove(task["id"])
            del selected[line]
        return False

    require(visit(INDEPENDENT_LINES),
            "Cannot fill a variant with distinct families using the current deck cycles")
    for line, task in selected.items():
        decks[line].remove(task)
    return selected


def validate_variants(variants, text_ids, count):
    require(len(variants) == count, "Incorrect variant count")
    combinations = set()
    pairs = set()
    text_usage = {kind: Counter() for kind in ("short", "main")}
    for variant in variants:
        tasks = variant["tasks"]
        require([t["no"] for t in tasks] == list(range(1, 28)), "Incorrect numbering")
        require(all(t["line"] == t["no"] for t in tasks), "Task line/number mismatch")
        require(len({t["id"] for t in tasks}) == 27, "Repeated ID in a variant")
        require(len({t["family"] for t in tasks}) == 27, "Repeated family in a variant")
        require(all(eligibility(t) is None for t in tasks), "Excluded task in a variant")
        require(sum(t["max_score"] for t in tasks[:26]) == 28, "Part 1 score is not 28")
        require(tasks[26]["max_score"] == 22, "Essay score is not 22")
        require(sum(t["max_score"] for t in tasks) == 50, "Total score is not 50")
        for kind, lines, text_id in (("short", SHORT_LINES, variant["text_pair"][0]),
                                     ("main", MAIN_LINES, variant["text_pair"][1])):
            require(text_id in text_ids, "Missing source text")
            require(all(tasks[line - 1].get("text") == text_id for line in lines),
                    "Text-bound tasks reference a different text")
            text_usage[kind][text_id] += 1
        pairs.add(tuple(variant["text_pair"]))
        combinations.add(tuple(t["id"] for t in tasks))
    require(len(combinations) == count, "Repeated complete variant combination")
    require(len(pairs) == count, "Repeated A/B pair")
    for kind, counts in text_usage.items():
        require(len(counts) == 9 and set(counts.values()) == {5, 6},
                f"Unbalanced {kind} text use: {dict(counts)}")
    for line in (9, 10, 11, 12):
        require(len({v["tasks"][line - 1]["id"] for v in variants}) == count,
                f"ID repetition on line {line}")
    return combinations, pairs, text_usage


def usage_report(placements):
    counts = Counter(value for value, _ in placements)
    locations = defaultdict(list)
    for value, position in placements:
        locations[value].append(position)
    return {
        "placements": len(placements),
        "distinct": len(counts),
        "repeated_values": sum(n > 1 for n in counts.values()),
        "repeat_placements_beyond_first": sum(n - 1 for n in counts.values()),
        "counts": dict(sorted(counts.items())),
        "repeated_locations": {value: locations[value] for value in sorted(counts)
                               if counts[value] > 1},
    }


def assemble(tasks, texts, seed, count, source_hashes):
    require(count == 50, "This assembler supports exactly 50 variants")
    blocks, by_line, exclusions = source_blocks(tasks, texts)
    rng = random.Random(seed)
    pairs = balanced_pairs(blocks["short"], blocks["main"], rng, count)
    decks = {line: [] for line in INDEPENDENT_LINES}
    cycles = Counter()
    variants = []
    for index, (ai, bi) in enumerate(pairs, 1):
        a_id, short_tasks = blocks["short"][ai]
        b_id, main_tasks = blocks["main"][bi]
        for line in INDEPENDENT_LINES:
            if not decks[line]:
                decks[line] = list(by_line[line])
                rng.shuffle(decks[line])
                cycles[line] += 1
        fixed = short_tasks + main_tasks
        selected = select_independent(decks, fixed)
        chosen = sorted(fixed + list(selected.values()), key=lambda t: t["line"])
        numbered = [dict(copy.deepcopy(task), no=task["line"]) for task in chosen]
        variants.append({
            "id": f"ru-2027-MIX-v{index:03d}",
            "title": f"Смешанный полный вариант {index:03d}",
            "status": "draft",
            "seed": seed,
            "text_pair": [a_id, b_id],
            "source_text_blocks": [
                {"kind": "short", "text_id": a_id, "lines": list(SHORT_LINES),
                 "task_ids": [t["id"] for t in short_tasks]},
                {"kind": "main", "text_id": b_id, "lines": list(MAIN_LINES),
                 "task_ids": [t["id"] for t in main_tasks]},
            ],
            "repeated_parts_are_expected": True,
            "human_methodologist_accepted": False,
            "max_scores": {"part_1": sum(t["max_score"] for t in numbered[:26]),
                           "essay": numbered[26]["max_score"],
                           "total": sum(t["max_score"] for t in numbered)},
            "tasks": numbered,
        })
    combinations, pair_set, text_usage = validate_variants(
        variants, {t["id"] for t in texts}, count)
    ids = []
    families = []
    per_line = {}
    for variant in variants:
        for task in variant["tasks"]:
            position = {"variant_id": variant["id"], "no": task["no"]}
            ids.append((task["id"], position))
            families.append((task["family"], position))
    for line in range(1, 28):
        selected = [v["tasks"][line - 1] for v in variants]
        per_line[str(line)] = {
            "placements": len(selected),
            "eligible_bank_ids": len(by_line[line]) if line in INDEPENDENT_LINES else 9,
            "distinct_selected_ids": len({t["id"] for t in selected}),
            "repeat_placements_beyond_first": len(selected) - len({t["id"] for t in selected}),
            "distinct_selected_families": len({t["family"] for t in selected}),
            "deck_cycles_started": cycles[line] if line in INDEPENDENT_LINES else None,
            "unused_ids_in_current_deck": len(decks[line]) if line in INDEPENDENT_LINES else None,
        }
    report = {
        "status": "draft",
        "human_methodologist_accepted": False,
        "seed": seed,
        "variant_count": len(variants),
        "source_sha256": source_hashes,
        "source_bank_task_ids": len(tasks),
        "source_text_count": len(texts),
        "excluded_task_counts": dict(sorted(exclusions.items())),
        "distinct_complete_combinations": len(combinations),
        "distinct_text_pairs": len(pair_set),
        "possible_text_pairs": len(blocks["short"]) * len(blocks["main"]),
        "text_pairs": [v["text_pair"] for v in variants],
        "balanced_counts": {kind: dict(sorted(counts.items())) for kind, counts in text_usage.items()},
        "text_reuse": {
            "placements": sum(sum(counts.values()) for counts in text_usage.values()),
            "distinct": sum(len(counts) for counts in text_usage.values()),
            "repeat_placements_beyond_first": sum(sum(counts.values()) - len(counts)
                                                  for counts in text_usage.values()),
        },
        "task_id_reuse": usage_report(ids),
        "family_reuse": usage_report(families),
        "per_line": per_line,
        "repeated_parts_are_expected": True,
        "new_authored_tasks_created": 0,
        "reuse_note": "Повторное включение ID, семейства или текста не считается новым авторским заданием.",
        "validation": {
            "all_variants_have_27_distinct_ids_and_families": True,
            "all_text_blocks_intact": True,
            "all_numbers_are_1_through_27": True,
            "all_scores_are_28_plus_22_equals_50": True,
            "all_texts_used_5_or_6_times": True,
            "no_id_reuse_on_lines_9_through_12": True,
        },
    }
    return variants, report


def write_outputs(output, report_path, variants, report):
    payloads = [(output, json.dumps(variants, ensure_ascii=False, indent=2) + "\n"),
                (report_path, json.dumps(report, ensure_ascii=False, indent=2) + "\n")]
    output.parent.mkdir(parents=True, exist_ok=True)
    pending = []
    try:
        for destination, payload in payloads:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent,
                                             prefix=f".{destination.name}.", delete=False) as handle:
                pending.append((Path(handle.name), destination))
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
        for temporary, destination in pending:
            os.replace(temporary, destination)
    finally:
        for temporary, _ in pending:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--tasks", type=Path, required=True)
    parser.add_argument("--texts", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="Output variants JSON file")
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--count", type=int, default=50, choices=(50,))
    parser.add_argument("--count50", dest="count", action="store_const", const=50,
                        help="Alias for --count 50")
    args = parser.parse_args(argv)
    report_path = args.output.with_name(args.output.stem + "-report.json")
    try:
        require(args.output.suffix.lower() == ".json", "--output must name a .json file")
        inputs = {args.tasks.resolve(), args.texts.resolve()}
        require(args.output.resolve() not in inputs and report_path.resolve() not in inputs,
                "Output must not overwrite an input bank")
        tasks, task_hash = read_bank(args.tasks)
        texts, text_hash = read_bank(args.texts)
        variants, report = assemble(tasks, texts, args.seed, args.count,
                                    {"tasks": task_hash, "texts": text_hash})
        write_outputs(args.output, report_path, variants, report)
    except (AssemblyError, OSError, json.JSONDecodeError) as error:
        print(f"Assembly refused: {error}", file=sys.stderr)
        return 2
    print(json.dumps({"variants": str(args.output), "report": str(report_path),
                      "count": len(variants),
                      "distinct_complete_combinations": report["distinct_complete_combinations"],
                      "distinct_task_ids": report["task_id_reuse"]["distinct"],
                      "repeat_task_placements": report["task_id_reuse"]["repeat_placements_beyond_first"]},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
