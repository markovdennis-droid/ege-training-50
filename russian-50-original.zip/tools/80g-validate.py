from pathlib import Path
import json,re,collections,html
P=Path('output/b80g')
def load(n):return json.loads((P/n).read_text())
a=load('tasks.json');new=load('new-tasks.json');vs=load('variants.json');ss=load('sources.json');by={t['id']:t for t in a}
assert len(a)==1147 and len(by)==1147 and len(new)==80
assert len({t['family'] for t in a})==1147
assert collections.Counter(t['line'] for t in new)=={5:7,6:7,8:6,**{n:6 for n in range(13,23)}}
for t in a:
 assert type(t['line']) is int and 1<=t['line']<=27 and t['stem'] and t['status'] in ['draft','on_hold'],t['id']
 assert t['max_score']==(22 if t['line']==27 else 2 if t['line'] in [8,22] else 1),t['id']
 assert all(s in ss for s in t['source_refs']),(t['id'],t['source_refs'])
 if t['line']!=27:assert t['key'] and all(isinstance(k,str) and k for k in t['key'])
 if t['answer_type']=='seq':
  assert len(t['left'])==5 and len(t['right'])==9 and all(len(k)==5 and len(set(k))==5 and set(k)<=set('123456789') for k in t['key']),t['id']
  if t.get('left_markup'):assert [html.unescape(re.sub('</?b>','',s)) for s in t['left_markup']]==t['left'],t['id']
for t in new:
 assert t['status']=='draft' and t['allowed_2027'] is None and t['needs_source'] and not t['norm_basis']['confirmed'] and t['norm_basis']['rule_source'],t['id']
 assert t['source_refs'] and t['agent_review']['state']=='completed_draft'
 if t.get('opts') and t['line']!=21:assert len(t['opts'])==5,t['id']
 if t['line']==21:assert 5<=len(t.get('opts',[]))<=9,t['id']
 n=t['line'];k=t['key'][0];e=t.get('evidence',{})
 if n==5:assert all(len(re.findall(r'\b[А-ЯЁ]{2,}\b',s))==1 for s in t['opts']),t['id']
 if n==6:assert ('сохраняя смысл' in t['stem'] or 'близким по значению' in t['stem']) and t['key_policy']['on_unmatched']=='manual_review',t['id']
 if n==8:
  assert e['left_types']==[e['error_types_by_right'][int(c)-1] for c in k],t['id']
  assert sum(c is not None for c in e['error_types_by_right'])==5,t['id']
 if n in [13,14]:
  criterion=e.get('answer_criterion','joined');assert criterion in ['joined','split','all_marked_joined'],t['id']
  assert k==''.join(str(j) for j,b in enumerate(e['joined_by_option'],1) if b==(criterion in ['joined','all_marked_joined'])),t['id']
 if n==15:assert k==''.join(str(j) for j,s in enumerate(e['letters_by_slot'],1) if s=='нн'),t['id']
 if n==16:assert k==''.join(str(j) for j,s in enumerate(e['punctuated_options'],1) if s.count(',')==1),t['id']
 if 17<=n<=20:assert k==''.join(str(j) for j,b in enumerate(e['comma_by_slot'],1) if b),t['id']
 if n==21:
  repeated=[r for r,c in collections.Counter(e['rule_by_option']).items() if c>1];assert repeated==[e['shared_rule']],(t['id'],repeated)
  assert k==''.join(str(j) for j,r in enumerate(e['rule_by_option'],1) if r==e['shared_rule']),t['id']
 if n==22:assert [t['right'][int(c)-1] for c in k]==e['term_by_left'],t['id']
 if n in [8,22]:assert k!='12345',t['id']
 if t['answer_type']=='digits':assert all(key==''.join(sorted(set(key))) for key in t['key']),t['id']
used=[]
for v in vs:
 assert len(v['tasks'])==27 and [t['no'] for t in v['tasks']]==list(range(1,28))
 assert sum(t['max_score'] for t in v['tasks'])==50
 for t in v['tasks']:
  assert t['status']!='on_hold';assert {k:val for k,val in t.items() if k!='no'}==by[t['id']],t['id'];used.append(t['id'])
assert len(set(used))==216
assert sum(i.startswith('rus-2027-b80g') for i in used)==80
def norm(s):return re.sub(r'\s+',' ',s.casefold().replace('ё','е')).strip()
dup={}
for kind in ['whole','opts','left','example']:
 bins=collections.defaultdict(list)
 for t in a:
  if kind=='whole':bodies=[json.dumps([t['stem'],t.get('opts'),t.get('left'),t.get('right'),t.get('text')],ensure_ascii=False)]
  elif kind=='example':bodies=(t.get('right',[]) if t['line']==8 else t.get('left',[]) if t['line']==22 else t.get('opts',[]) if t['line'] in [5,13,14,16] else [])
  elif kind in t and not (kind=='left' and t['line']==8):bodies=[json.dumps(t[kind],ensure_ascii=False)]
  else:continue
  for b in bodies:bins[norm(b)].append(t['id'])
 hits=[list(dict.fromkeys(ids)) for ids in bins.values() if len(set(ids))>1 and any('b80g' in i for i in ids)]
 dup[kind]=hits
 assert not hits,(kind,hits)
r={'inventory':1147,'new80g':80,'on_hold':1,'unique_ids':1147,'unique_families':1147,'updated_full_variants':8,'new_text_pairs':0,'same_text_pairs_from_80f':8,'new_tasks_in_variants':80,'part1_each':28,'essay_max':22,'new_answer_evidence_recomputed':True,'duplicate_check_scope':'Exact full tasks, option sets and sentences; matching grammar-type labels are not treated as examples; paraphrased facts need separate methodical review','source_registry_complete':True,'human_methodologist_acceptance':False,'browser_visual_check':'not performed; actual scoring and DOM model are checked separately'}
(P/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(P/'duplicate-checks.json').write_text(json.dumps(dup,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
