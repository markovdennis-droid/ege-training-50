from pathlib import Path
import json,copy,hashlib,re,collections
W=Path('work/r80-02');O=Path('output/r80-02');O.mkdir(exist_ok=True,parents=True)
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def bare(item):
 s=item['template'];tokens=re.findall(r'[^\s,;()]+',s);tok=next(t for t in tokens if '..' in t);return tok.replace('..',item['letter'])
def baselemma(item):return re.sub(r'(ся|сь)$','',item.get('infinitive',item.get('lemma',bare(item))).lower())
def fam(t):return 'r802-'+hashlib.sha256(json.dumps([t['line'],sorted(t['words'])],ensure_ascii=False).encode()).hexdigest()[:20]
old=load('output/b80g/tasks.json');tasks=copy.deepcopy(old);by={t['id']:t for t in tasks};before={t['id']:copy.deepcopy(t) for t in tasks};sources=load('output/b80g/sources.json');texts=load('output/b80g/texts.json');planned=[];passports=[];inventory=[]
for n in range(9,13):
 a=load(W/f'authors/line-{n:02}.json');expected={t['id'] for t in load(W/f'input/line-{n:02}.json')['targets']};assert {t['id'] for t in a['tasks']}==expected
 planned+=a['tasks'];passports+=a['passports'];inventory+=a['inventory_used']
 for s in a['sources']:
  sid=s['id'];info={k:v for k,v in s.items() if k!='id'}
  if sid in sources and sources[sid]!=info:assert sources[sid].get('url')==info.get('url'),('source collision',sid)
  else:sources[sid]=info
for report in ['inventory-09-10','final-findings-09-10']:
 for entry in load(W/f'reviews/{report}.json').get('sources',[]):
  sid=entry['id'];info={k:v for k,v in entry.items() if k!='id'};info.setdefault('title','Нормативный источник проверки: '+sid);sources.setdefault(sid,info)
P={p['task_id']:p for p in passports};newids={t['id'] for t in planned};assert len(newids)==80
# Item-level fixes are applied to passports; all display/scoring representations are rebuilt.
edits=load(W/'approved-item-edits.json') if (W/'approved-item-edits.json').exists() else []
for e in edits:
 item=P[e['task_id']]['rows'][e['row_index']]['items'][e['item_index']]
 if e.get('replacement_item') is not None:P[e['task_id']]['rows'][e['row_index']]['items'][e['item_index']]=copy.deepcopy(e['replacement_item'])
 else:item.update(copy.deepcopy(e['patch']))
 if e.get('add_source_refs'):
  item=P[e['task_id']]['rows'][e['row_index']]['items'][e['item_index']];item['source_refs']=list(dict.fromkeys(item.get('source_refs',[])+e['add_source_refs']))
# Canonical items used for both this batch and repairs of the previously reworked80.
canonical={}
for p in passports:
 for r in p['rows']:
  for x in r['items']:
   x.pop('usage_count',None);x['word']=bare(x);canonical.setdefault((p['line'],r['group'],x['word'],x['letter']),copy.deepcopy(x))
# Prior R80-01 receives the same audited contexts/rules; it is not counted as80new edits.
previous=load('output/b80g/snapshot/bank/material/r80-current/row-passports.json');extra=[]
oldfreq=collections.Counter((p['line'],bare(x)) for p in previous for r in p['rows'] for x in r['items'])
blocked_rows={(p['line'],r['group'],tuple(sorted(bare(x) for x in r['items']))) for p in passports+previous for r in p['rows']}
context_overrides={}
for report in ['inventory-09-10','inventory-11-12']:
 for f in load(W/f'reviews/{report}.json')['findings']:
  if f.get('proposed_template'):context_overrides[f['template']]={'template':f['proposed_template']}
  elif isinstance(f.get('proposed_edit'),dict) and f.get('template') and f['proposed_edit'].get('template'):context_overrides[f['template']]={'template':f['proposed_edit']['template']}
for p in previous:
 p=copy.deepcopy(p);tid=p['task_id'];originalp=copy.deepcopy(p)
 for r in p['rows']:
  for j,x in enumerate(r['items']):
   x['word']=bare(x);key=(p['line'],r['group'],x['word'],x['letter'])
   if key in canonical:r['items'][j]=copy.deepcopy(canonical[key])
   y=r['items'][j]
   if y['template'] in context_overrides:y.update(context_overrides[y['template']])
   if p['line']==11 and y['word']=='беженка':y['rule']='Беженка соотносится с существительным беженец: Е сохраняется в производящей основе; написание проверяется словарём.'
   if p['line']==9:y['rule']=y['rule'].replace('ве́сны','вёсны')
 # Replace selected invalid/misclassified entries and reflexive/base-family hints.
 occupied={x['word'] for r in p['rows'] for x in r['items']}
 seen=set()
 for r in p['rows']:
  for j,x in enumerate(r['items']):
   bad=(p['line']==9 and x['word'] in ['атаковать','заросший']) or (p['line']==11 and x['word']=='сначала') or (p['line']==12 and (x['word'] in ['зависимый','терпимый','учащийся','служащий'] or baselemma(x) in seen))
   if bad:
    donors=[d for (ln,g,word,letter),d in canonical.items() if ln==p['line'] and g==r['group'] and letter==x['letter'] and word not in occupied and oldfreq[(ln,word)]<4 and (ln,g,tuple(sorted([z['word'] for k,z in enumerate(r['items']) if k!=j]+[word]))) not in blocked_rows and (ln!=12 or baselemma(d) not in seen)]
    assert donors,('no donor',tid,x)
    d=copy.deepcopy(sorted(donors,key=lambda d:(oldfreq[(p['line'],d['word'])],d['word']))[0]);oldfreq[(p['line'],x['word'])]-=1;oldfreq[(p['line'],d['word'])]+=1;r['items'][j]=d;blocked_rows.add((p['line'],r['group'],tuple(sorted(z['word'] for z in r['items']))));occupied.add(d['word']);x=d
   if p['line']==12:seen.add(baselemma(x))
 if p!=originalp:extra.append(p)
from bulk_rework import assemble_remaining
first80_ids=set(newids)
bulk_tasks,bulk_pass,bulk_report=assemble_remaining(old,planned,passports+extra,canonical)
bulk_ids={t['id'] for t in bulk_tasks}
planned+=bulk_tasks;passports+=bulk_pass;newids.update(bulk_ids)
dump(O/'bulk-report.json',bulk_report)
allpass=passports+extra;allP={p['task_id']:p for p in allpass};authorby={t['id']:t for t in planned};changed=[]
for tid,p in allP.items():
 oldt=before[tid];t=by[tid]
 if tid in authorby:t.update(copy.deepcopy(authorby[tid]))
 p['id']='r80-02:'+tid;p['review_status']='agent_checked_draft_pending_human_methodologist' if tid in newids else 'inventory_refreshed_draft_pending_task_review'
 opts=[];drill=[];words=[];exps=[];keys=[];refs=[]
 for i,r in enumerate(p['rows'],1):
  items=r['items'];letters=[x['letter'] for x in items];filled=[];triples=[]
  for x in items:
   x.pop('usage_count',None);x['word']=bare(x);pre,post=x['template'].split('..');filled.append(pre+x['letter']+post);triples.append([pre,x['letter'],post]);words.append(x['word']);refs+=x.get('source_refs',[])
  same=len(set(letters))==1
  if same:keys.append(str(i))
  r['selected']=same;r['letters']=letters
  opts.append(', '.join(x['template'] for x in items));drill.append(triples)
  exps.append(str(i)+') '+', '.join(filled)+' — '+' / '.join(x.upper() for x in letters)+'. '+' '.join(x['rule'] for x in items))
 t.update({'opts':opts,'drill':{'kind':'letters','hint':'Вставьте пропущенные буквы. Каждая позиция проверяется отдельно.','rows':drill},'words':words,'key':[''.join(keys)],'exp':'\n\n'.join(exps)+'\n\nОтвет: '+''.join(keys)+'.','answer_type':'digits','match':'unordered','max_score':1,'status':'draft','needs_source':True,'allowed_2027':None,'reviewer_id':None,'reviewed_at':None,'selection_blueprint':p['id']})
 t['year']=2027;t['base_year']=2026;t['source']='assembled:audited-rule-inventory' if tid in bulk_ids else 'authored:rule-blueprints-r80-02' if tid in newids else 'authored:rule-blueprints-r80-01-refreshed'
 t['source_refs']=list(dict.fromkeys(['FIPI27','MR26']+refs));t['norm_basis']={'claim':'Каждый пропуск обоснован в паспорте ряда; нормативные источники отделены от формата; допуск человеком не получен.','rule_source':list(dict.fromkeys(refs)),'type_source':'FIPI27; MR26: соответствующая линия','confirmed':False}
 t['method_work_state']='reworked_draft_pending_human_methodologist' if tid in newids else 'inventory_refreshed_draft_pending_task_review'
 t['agent_review']={'state':'inventory_checked_rule_assembled_draft' if tid in bulk_ids else 'completed_after_item_fixes_draft' if tid in newids else 'inventory_audit_only','individually_blind_solved':tid in first80_ids,'human_methodologist_accepted':False,'reports':['reviews/final-findings-09-10.json','reviews/final-findings-11-12.json']}
 t['version']=oldt['version']+1 if type(oldt.get('version')) is int else None
 if t['version'] is None:t['recovery_revision']=oldt.get('recovery_revision',0)+1
 t['replaces_family']=oldt['family'];t['family']=fam(t)
 changed.append({'id':tid,'planned_batch':tid in newids,'before':oldt,'after':copy.deepcopy(t)})
variants=copy.deepcopy(load('output/b80g/variants.json'));pools={n:sorted(t['id'] for t in planned if t['line']==n) for n in range(9,13)}
for i,v in enumerate(variants):
 v['previous_variant_id']=v['id'];v['id']=f'ru-2027-R802-v{i+1:03}';v['title']=f'R80-02 · вариант {i+1:03} · тексты80F';v['text_pair_origin']='80F; новых текстовых пар нет'
 for j,t in enumerate(v['tasks']):
  tid=pools[t['line']][i] if t['line'] in pools else t['id'];v['tasks'][j]={**copy.deepcopy(by[tid]),'no':j+1}
summary={'date':'2026-11-12','batch':'R9-12-complete','inventory':1147,'new_task_ids':0,'planned_reworked':len(newids),'first_blind_reviewed':len(first80_ids),'rule_assembled_after_inventory_audit':len(bulk_ids),'previous_reworked_refreshed':len(extra),'revised_ids':sorted(newids),'on_hold':1,'remaining_original_backlog':sum(t.get('method_work_state')=='needs_rework_after_teacher_comments' for t in tasks),'updated_full_variants':8,'new_text_pairs':0,'human_methodologist_accepted':0}
assert len(tasks)==1147 and len({t['id'] for t in tasks})==1147 and len({t['family'] for t in tasks})==1147
for name,a in [('tasks',tasks),('new-tasks',[]),('revised-tasks',[by[i] for i in sorted(newids)]),('first80-tasks',[by[i] for i in sorted(first80_ids)]),('sources',sources),('texts',texts),('variants',variants),('batch-summary',summary),('passports',allpass),('assembly-inventory',list(canonical.values())),('inventory',list({(p['line'],r['group'],x['template'],x['letter']):x for p in allpass for r in p['rows'] for x in r['items']}.values())),('patch-history',changed)]:dump(O/(name+'.json'),a)
dump(O/'blueprints.json',{'schema_version':1,'blueprints':[{**copy.deepcopy(p),'task':copy.deepcopy(by[p['task_id']])} for p in allpass]})
dump(O/'base-variants8.json',variants)
import subprocess,sys
subprocess.run([sys.executable,str(W/'assemble50.py'),'--tasks',str(O/'tasks.json'),'--texts',str(O/'texts.json'),'--output',str(O/'variants.json'),'--seed','20271112','--count','50'],check=True)
summary['updated_full_variants']=50
summary['mixed_variant_parts_repeat']=True
dump(O/'batch-summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='revised_ids'},ensure_ascii=False))
