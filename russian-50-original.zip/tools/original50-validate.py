from pathlib import Path
import json,re,collections,hashlib,itertools,html
O=Path('output/original50')
def load(n):return json.loads((O/n).read_text())
def norm(s):return re.sub(r'\s+',' ',str(s).casefold().replace('ё','е')).strip()
def seq(x):return [x[k] for k in sorted(x,key=int)] if isinstance(x,dict) else x
def words(s):return re.findall(r'[А-Яа-яЁёA-Za-z0-9]+(?:[-’\'][А-Яа-яЁёA-Za-z0-9]+)*',s)
A=load('tasks.json');N=load('new-tasks.json');T=load('texts.json');V=load('variants.json');S=load('sources.json');B={t['id']:t for t in A};TB={t['id']:t for t in T};newids={t['id'] for t in N}
assert len(A)==1742 and len(B)==1742 and len(N)==595 and len(T)==100 and len(TB)==100 and len(V)==50
assert len({t['family'] for t in A})==len(A)
expected={1:41,2:41,3:41,5:14,6:15,7:29,8:19,**{n:19 for n in range(13,23)},23:41,24:41,25:41,26:41,27:41}
assert collections.Counter(t['line'] for t in N)==expected
for t in A:
 assert type(t['line']) is int and 1<=t['line']<=27 and t['stem'],t['id']
 assert t['max_score']==(22 if t['line']==27 else 2 if t['line'] in [8,22] else 1),t['id']
 assert t['status'] in ['draft','on_hold'] and all(x in S for x in t['source_refs']),t['id']
 if t['line']!=27:assert t['key'] and all(isinstance(k,str) and k for k in t['key']),t['id']
 if t.get('text'):assert t['text'] in TB,t['id']
 if t['answer_type']=='seq':
  assert len(t['left'])==5 and len(t['right'])==9
  assert all(len(k)==5 and len(set(k))==5 and set(k)<=set('123456789') for k in t['key']),t['id']
  if t.get('left_markup'):assert [html.unescape(re.sub('</?b>','',x)) for x in t['left_markup']]==t['left'],t['id']
for t in N:
 n=t['line'];e=t.get('evidence',{});k=t['key'][0] if t['key'] else ''
 assert t['status']=='draft' and t['allowed_2027'] is None and t['needs_source'] and not t['norm_basis']['confirmed'] and t['norm_basis']['rule_source'],t['id']
 if t.get('opts') and n!=21:assert len(t['opts'])==5,t['id']
 if n in [5,7]:assert all(len(re.findall(r'\b[А-ЯЁ]{2,}\b',x))==1 for x in t['opts']),t['id']
 if n==6:assert 'сохраняя смысл' in t['stem'] and t['key_policy']['on_unmatched']=='manual_review',t['id']
 if n==8:
  assert sum(x is not None for x in e['error_types_by_right'])==5
  assert e['left_types']==[e['error_types_by_right'][int(c)-1] for c in k],t['id']
 if n in [13,14]:
  criterion=e.get('answer_criterion','joined');assert criterion in ['joined','all_marked_joined','split']
  assert k==''.join(str(i) for i,b in enumerate(e['joined_by_option'],1) if b==(criterion!='split')),t['id']
 if n==15:assert k==''.join(str(i) for i,x in enumerate(e['letters_by_slot'],1) if x=='нн'),t['id']
 if n==16:assert k==''.join(str(i) for i,x in enumerate(seq(e['punctuated_options']),1) if x.count(',')==1),t['id']
 if 17<=n<=20:assert k==''.join(str(i) for i,b in enumerate(seq(e['comma_by_slot']),1) if b),t['id']
 if n==21:
  er=[x.get('rule_code') if isinstance(x,dict) else x for x in seq(e['rule_by_option'])];sr=e.get('shared_rule_code',e['shared_rule'])
  assert k==''.join(str(i) for i,x in enumerate(er,1) if x==sr),t['id']
  assert [x for x,c in collections.Counter(er).items() if c>1]==[sr],t['id']
 if n==22:assert [t['right'][int(c)-1] for c in k]==e['term_by_left'],t['id']
 if t.get('text'):
  assert t['text_version']==TB[t['text']]['version']
  for m in re.finditer(r'предложени[яй]\s+(\d+)\s*[–—-]\s*(\d+)',t['stem'],re.I):assert 1<=int(m[1])<=int(m[2])<=len(TB[t['text']]['sentences']),t['id']
 if n==27:
  assert t['author_position'] and t['problem'] and len(t['essay_guide']['pairs'])>=2
  for pair in t['essay_guide']['pairs']:
   assert pair['relation'] and pair['comment']
   for lo,hi in pair['examples']:assert 1<=lo<=hi<=len(TB[t['text']]['sentences']),t['id']
# Newly authored texts: length, numbering and a literal unique source.
text_metrics=[]
for t in T:
 count=len(words(' '.join(t['sentences'])));main=any(x['text']==t['id'] and x['line']==27 for x in A if x.get('text'))
 if t['id'].startswith('ru-2027-O-'):
  if not main:assert len(re.findall(r'\b[А-ЯЁ]{2,}\b',' '.join(t['sentences'])))==5,('five highlighted words',t['id'])
  assert (450<=count<=650 and 25<=len(t['sentences'])<=32) if main else (130<=count<=200 and 7<=len(t['sentences'])<=10),(t['id'],count,len(t['sentences']))
 text_metrics.append({'id':t['id'],'kind':'main' if main else 'short','words':count,'sentences':len(t['sentences'])})
# Exact exercise equality ignores answer order and metadata, but includes the linked text content.
sigs=collections.defaultdict(list)
for t in A:
 source=' '.join(TB[t['text']]['sentences']) if t.get('text') else ''
 body=[t['line'],norm(t['stem']),sorted(map(norm,t.get('opts',[]))),sorted(map(norm,t.get('left',[]))),sorted(map(norm,t.get('right',[]))),norm(source)]
 sigs[json.dumps(body,ensure_ascii=False)].append(t['id'])
duplicates=[ids for ids in sigs.values() if len(ids)>1 and any(i in newids for i in ids)]
assert not duplicates,('exact repeated exercise',duplicates)
# Similarity is a warning for editorial review; it is not a semantic originality guarantee.
sim=[]
for kind in ['main','short']:
 same=[t for t in T if next(m['kind'] for m in text_metrics if m['id']==t['id'])==kind]
 gram={}
 for t in same:
  w=[norm(x) for x in words(' '.join(t['sentences']))];gram[t['id']]={tuple(w[i:i+4]) for i in range(len(w)-3)}
 for a,b in itertools.combinations(same,2):
  x,y=gram[a['id']],gram[b['id']];score=len(x&y)/max(1,len(x|y))
  if score>=0.15:sim.append({'a':a['id'],'b':b['id'],'four_word_ngram_jaccard':round(score,4)})
assert not sim,('high text overlap requires review',sim)
used=[];families=[];textids=[]
for v in V:
 assert len(v['tasks'])==27 and [t['no'] for t in v['tasks']]==list(range(1,28))
 assert sum(t['max_score'] for t in v['tasks'] if t['no']<27)==28 and v['tasks'][-1]['max_score']==22
 for t in v['tasks']:
  assert {k:x for k,x in t.items() if k!='no'}==B[t['id']] and t['status']!='on_hold'
  used.append(t['id']);families.append(t['family'])
 textids+=v['text_pair']
selected_set=set(used)
selected_content_duplicates=[ids for ids in sigs.values() if len(set(ids)&selected_set)>1]
assert not selected_content_duplicates,('repeated complete exercise in variants',selected_content_duplicates)
assert len(used)==len(set(used))==1350 and len(set(families))==1350 and len(set(textids))==100
r={'inventory':1742,'new_tasks':595,'new_texts':82,'original_full_variants':50,'selected_task_ids':1350,'selected_unique_task_ids':1350,'selected_unique_families':1350,'selected_unique_texts':100,'repeated_task_ids':0,'repeated_families':0,'repeated_texts':0,'exact_new_exercise_duplicates':0,'exact_selected_exercise_duplicates':0,'high_text_overlap_pairs':0,'part1_each':28,'essay_max':22,'human_methodologist_acceptance':False,'browser_visual_check':'not performed; actual scoring and functional rendering tested separately'}
dump=lambda n,a:(O/n).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
dump('checks.json',r);dump('text-metrics.json',text_metrics);dump('text-similarity.json',sim);print(json.dumps(r,ensure_ascii=False))
