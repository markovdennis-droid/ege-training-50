from pathlib import Path
import json,re,collections,hashlib
O=Path('output/r80-02')
def load(n):return json.loads((O/n).read_text())
A=load('tasks.json');N=load('revised-tasks.json');P=load('passports.json');S=load('sources.json');V=load('variants.json');B={t['id']:t for t in A};planned={t['id'] for t in N};base=json.loads(Path('output/b80g/tasks.json').read_text());old={t['id']:t for t in base}
assert len(A)==1147 and set(B)==set(old) and len(planned)==511
assert len({t['family'] for t in A})==1147
assert collections.Counter(t['line'] for t in N)=={9:132,10:108,11:128,12:143}
def cls(c):return 'vowel' if c in 'аеёиоуыэюя' else 'sign' if c in 'ъь' else 'consonant'
def bare(x):return next(z for z in re.findall(r'[^\s,;()]+',x['template']) if '..' in z).replace('..',x['letter'])
def vb(x):return re.sub('(ся|сь)$','',x.get('infinitive',x.get('lemma',bare(x))))
rowsig=collections.defaultdict(list);stats=collections.defaultdict(collections.Counter);parts=collections.Counter();changed=set()
for p in P:
 t=B[p['task_id']];tid=t['id'];changed.add(tid);assert len(p['rows'])==5 and len(t['opts'])==5 and len(t['drill']['rows'])==5
 assert t['status']=='draft' and t['allowed_2027'] is None and t['needs_source'] and not t['norm_basis']['confirmed']
 assert all(s in S for s in t['source_refs']),(tid,[s for s in t['source_refs'] if s not in S])
 assert t['version']==(old[tid]['version']+1 if type(old[tid]['version']) is int else None)
 assert t['replaces_family']==old[tid]['family']
 keys=[];words=[];lemmas=[]
 for i,r in enumerate(p['rows']):
  it=r['items'];assert len(it)==(3 if t['line'] in [9,10] else 2)
  letters=[x['letter'] for x in it];assert all(len(c)==1 for c in letters)
  assert len({cls(c) for c in letters})==1,(tid,i,letters)
  if len(set(letters))==1:keys.append(str(i+1))
  elif len(it)==3:assert sorted(collections.Counter(letters).values())==[1,2],(tid,i,letters)
  assert t['opts'][i]==', '.join(x['template'] for x in it)
  rw=[]
  for j,x in enumerate(it):
   assert x['template'].count('..')==1 and x['word']==bare(x),(tid,i,j)
   pre,post=x['template'].split('..');assert t['drill']['rows'][i][j]==[pre,x['letter'],post]
   assert x['rule'] and x['source_refs'];assert all(s in S for s in x['source_refs']),(tid,x['source_refs'])
   rw.append(x['word']);words.append(x['word']);lemmas.append(vb(x) if t['line']==12 else x.get('lemma',x['word']))
   stats[(t['line'],tid in planned)][x['word']]+=1;parts['planned' if tid in planned else 'refreshed']+=1
   if t['line']==12:
    assert not x.get('infinitive') or x['infinitive'] not in x['template'],(tid,x)
  sig=(t['line'],tuple(sorted(rw)));rowsig[sig].append((tid,i+1))
 assert t['key']==[''.join(keys)] and 1<=len(keys)<=4
 assert t['words']==words and len(words)==len(set(words)),tid
 if tid in planned:assert len(lemmas)==len(set(lemmas)),(tid,'lemma repeat',lemmas)
 if tid not in planned:assert t['key']==old[tid]['key'],tid
 assert ('Ответ: '+t['key'][0]+'.') in t['exp']
first80={t['id'] for t in load('first80-tasks.json')}
for n in range(9,13):
 c=collections.Counter(x['word'] for p in P if p['task_id'] in first80 and p['line']==n for r in p['rows'] for x in r['items']);assert max(c.values())<=4
bulk=load('bulk-report.json');covered=[]
for cohort in bulk['cohorts']:
 c=collections.Counter(w for tid in cohort['tasks'] for w in B[tid]['words']);assert dict(sorted(c.items()))==cohort['word_counts'] and max(c.values())<=4;covered+=cohort['tasks']
assert set(covered)==planned-first80 and len(covered)==431
dup=[v for v in rowsig.values() if len(v)>1]
assert not dup,('duplicate rows after patches',dup)
for t in A:
 if t['id'] not in changed:assert t==old[t['id']],t['id']
used=[]
for v in V:
 assert len(v['tasks'])==27 and sum(t['max_score'] for t in v['tasks'])==50
 for t in v['tasks']:
  assert t['status']!='on_hold' and {k:x for k,x in t.items() if k!='no'}==B[t['id']]
  if t['line'] in [9,10,11,12]:assert t['id'] in changed
  used.append(t['id'])
assert len(V)==50
assert len({tuple(t['id'] for t in v['tasks']) for v in V})==50
for n in range(9,13):assert len({t['id'] for v in V for t in v['tasks'] if t['line']==n})==50
r={'inventory':1147,'new_task_ids':0,'planned_reworked':511,'individually_blind_reviewed':80,'rule_assembled_after_inventory_audit':431,'refreshed_previous':len(P)-511,'planned_rows':2555,'planned_letter_positions':parts['planned'],'all_passport_rows':len(P)*5,'all_letter_positions':sum(parts.values()),'keys_recomputed':len(P),'row_duplicates_among_reworked':0,'max_word_repetitions_per_line_cohort':4,'previous_max_word_repetitions':{str(n):max(stats[(n,False)].values()) for n in range(9,13)},'remaining_original_backlog':sum(t.get('method_work_state')=='needs_rework_after_teacher_comments' for t in A),'full_variants':50,'whole_variant_combinations_unique':50,'parts_repeat_between_variants':True,'part1_each':28,'essay_max':22,'human_methodologist_acceptance':False,'visual_browser_check':'not performed; functional tests use actual script in Node VM'}
(O/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
