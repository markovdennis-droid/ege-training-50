from pathlib import Path
import json,copy,shutil,zipfile,hashlib,csv
O=Path('output/review-80ef');B=O/'snapshot';W=Path('work/review-80ef')
def load(p):return json.loads(Path(p).read_text())
def dump(p,a):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
# Полный прежний снимок переносится с PDF и историей; актуальные данные заменяются по ID.
if not B.exists():shutil.copytree('output/b80e/snapshot',B)
for fn in ['new-tasks.json','batch-summary.json','checks.json','sources.json','core-checks.json','coverage.csv','duplicate-checks.json','rejected-candidates.json']:
 p=B/fn
 if p.exists():
  h=B/'history/b80e';h.mkdir(parents=True,exist_ok=True)
  if not (h/fn).exists():shutil.copyfile(p,h/fn)
for t in (B/'bank/tasks').glob('line-*.json'):t.unlink()
a=load(O/'tasks.json');by={t['id']:t for t in a};texts=load(O/'texts.json');variants=load(O/'variants.json')
for n in range(1,28):dump(B/f'bank/tasks/line-{n:02}.json',[t for t in a if t['line']==n])
for t in texts:dump(B/f'bank/texts/{t["id"]}.json',t)
# Старые учебные комбинации сохранены только в истории, новый индекс содержит8новых.
oldvariants=B/'history/pre80f-variants';oldvariants.mkdir(exist_ok=True)
for p in (B/'bank/variants').glob('*.json'):
 if not p.name.startswith('ru-2027-F-') and not (oldvariants/p.name).exists():shutil.copyfile(p,oldvariants/p.name)
 p.unlink()
for v in variants:dump(B/f'bank/variants/{v["id"]}.json',v)
dump(B/'bank/variants/index.json',[{'id':v['id'],'title':v['title'],'file':v['id']+'.json','status':'draft'} for v in variants])
for name in ['tasks','texts','variants','sources','new-tasks','batch-summary','patch-history','text-history','review-decisions','coverage','checks','duplicate-checks']:
 shutil.copyfile(O/(name+'.json'),B/(name+'.json'))
if (O/'core-checks.json').exists():shutil.copyfile(O/'core-checks.json',B/'core-checks.json')
with (B/'coverage.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['line','inventory','active','target','remaining']);w.writeheader();w.writerows(load(O/'coverage.json'))
# Источники и журналы проверок текущего прохода, включая не принятые кандидаты.
for p in Path('work/agents/reviews').glob('*'):
 if p.is_file():d=B/'reviews'/p.name;d.parent.mkdir(exist_ok=True);shutil.copyfile(p,d)
for p in Path('work/agents/new80f').glob('*.json'):
 d=B/'history/author-80f'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for p in W.glob('baseline-*.json'):
 d=B/'history/pre80f'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for p in (W/'r80-fixed').glob('*'):
 if p.is_file():d=B/'bank/material/r80-current'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
# Вложенные полные записи blueprint синхронизируются с актуальными версиями и семьями.
r80ids={t['id'] for t in load(W/'r80-fixed/tasks.json')};dump(B/'bank/material/r80-current/tasks.json',[by[i] for i in sorted(r80ids)])
def sync(obj):
 if isinstance(obj,dict):
  if obj.get('id') in r80ids and 'stem' in obj and 'key' in obj:return copy.deepcopy(by[obj['id']])
  return {k:sync(v) for k,v in obj.items()}
 if isinstance(obj,list):return [sync(v) for v in obj]
 return obj
dump(B/'bank/material/r80-current/blueprints.json',sync(load(W/'r80-fixed/blueprints.json')))
for name in ['build_snapshot.py','make_html.py','validate.py','package.py','test_core.cjs','test_render.cjs']:
 if (W/name).exists():shutil.copyfile(W/name,B/'tools'/('80f-'+name))
# Старые инструменты сборки80E — только история; текущий валидатор запускается из архива.
oldtoolnames=['test_core.cjs','validate_snapshot.py','build.py','make_html.py','restore_full.py','recover_bold.py']
for name in oldtoolnames:
 src=B/'tools'/name
 if src.exists():
  dest=B/'history/pre80f-tools'/name;dest.parent.mkdir(exist_ok=True)
  if not dest.exists():shutil.copyfile(src,dest)
  src.unlink()
portable=(W/'validate.py').read_text().replace("P=Path('output/review-80ef')","P=Path(__file__).resolve().parent.parent")
(B/'tools/validate_snapshot.py').write_text(portable)
(B/'tools/README.md').write_text('Текущий автономный контроль: python3 tools/validate_snapshot.py из распакованного архива. Скрипты с префиксом80f- сохраняют исходный процесс сборки и пути рабочего окружения; для продолжения используйте актуальные tasks/texts/variants JSON. Прежние инструменты80E — только вhistory/pre80f-tools.\n')
readme='''# Русский язык · 80F · полная контентная сборка

11.11.2026. Откройте один russian-bank-80f.html. Интернет для решений, ключей и заметок не требуется. В самом HTML есть кнопка скачивания этого полного архива. Это контентная сборка для проверки, не замена работающему серверу.

## Счёт

987 прежних ID +80 новых =1067 записей. Из них1066 активных черновиков, одно прежнее №6 on_hold: сохранено для истории и вычитки, исключено из вариантов и автоматического оценивания. Правки старых ID не считаются новыми заданиями. Все исходные PDF и история R80/80C/80E сохранены; отсутствующая в присланных файлах партия80D не добавлялась выдуманным счётом.

Новые80: по8 заданий №1,2,3,23,24,25,26,27 (64), ещё16 №7. Написано8 коротких и8 основных оригинальных текстов. Восемь новых полных вариантов:27 заданий, включая сочинение. В каждом9 новых заданий80F и18 уже существовавших. Восемь оставшихся новых №7 доступны отдельно в банке. Новые тексты независимы друг от друга; прежняя пара001 сохранена отдельно. Всего9 пар текстов, а не50.

Максимум каждого варианта50: часть1 —28, сочинение —22. Сочинение здесь автоматически не оценивается. Совпадение с авторским ключом не означает приёмки методистом.

## Что исправлено

Замечания предыдущей проверки80E внесены централизованно: примеры с общим обстоятельством в ССП, обособлением определений, точностью правил НЕ/пунктуации и выделений средств выразительности. Неоднозначное «создала решение» заменено нормативно обоснованным «заняла первенство». Спорное другое №6 отложено. Для восстановленного «поднять кругозор» добавлен словарный ответ «раздвинуть» и открытая политика ключей.

В80 переработанных №9–12 проверены400рядов/1000пропусков; в15 заданиях уточнены16позиций. Контексты исключают конкурирующее заполнение пропуска, для «пр..шить» целиком заменён языковой материал на «пр..дорожный». Ключи не менялись. Паспорта рядов, инвентарь, blueprint и тренировочные поля синхронизированы. Техническая проверка не является полной словарной приёмкой всех использованных слов. Ещё511 прежних №9–12 явно помечены для дальнейшей переработки; нынешняя сборка не объявляет их исправленными.

В новых текстовых блоках после редакций повторно сверены условия, ключи, объяснения и возможные пары примеров для сочинения. Журналы агентной проверки находятся вreviews. Это проверка моделями, а не независимая экспертиза преподавателя. Статусыdraft, needs_source и allowed_2027=null не сняты. Нормативный источник и источник формата не подменяют друг друга.

## Продолжение

bank/tasks — актуальная разбивка по линиям; tasks.json — полный тот же снимок; new-tasks.json — только80F. bank/variants/index.json —8новых вариантов. Полные прежние варианты вhistory/pre80f-variants не считаются новыми текстовыми комплектами. bank/material/r80-current — актуальные материалы генератора; старые r80-01-* оставлены как неизменяемая история.

Версии747 восстановленных записей, не напечатанные вPDF, остаютсяnull. Новые изменения таких записей обозначены recovery_revision; исходные family изPDF не выдаются за восстановленные подлинники. При замене материала есть replaces_family. patch-history.json хранит до/после, text-history.json — прежние редакции текстов.

Для50 вариантов нужен учёт по каждой линии: дефицит активного материала675 позиций, а не1350−1067 (избыток одних линий не заменяет недобор других). Плюс остаётся методическая доработка старого материала. Таблицаcoverage.csv показывает распределение.

## Проверки

Структура1067записей, ссылки, уникальныеID/family,8вариантов по27, источники и аннотированные эталоны80E проверены машинно. Реальная функция подсчёта извлекается из итоговогоHTML и запускается вNodeVM: все авторские ответы, частичный балл8/22, открытые ключи иon_hold. Отдельно выполняется проход рендера всех записей с модельюDOM; это не визуальная браузерная проверка. ЗапускChromium ранее заблокирован ограничением среды на сокеты, поэтому скриншотная/визуальная проверка не объявляется пройденной. Точные результаты находятся вchecks.json/core-checks.json/render-checks.json.
'''
(B/'README.md').write_text(readme)
if (O/'render-checks.json').exists():shutil.copyfile(O/'render-checks.json',B/'render-checks.json')
# Дополняем принятые решения, сохраняя исходный документ.
p=B/'РЕШЕНИЯ.md';txt=p.read_text();marker='# Дополнение 11.11.2026 · 80F'
if marker not in txt:p.write_text(txt+'\n\n'+marker+'\n\nЦель50×27. Авторские тексты. Агентные проверки не снимают draft. Один спорный №6 on_hold исключён из вариантов. Неизвестная исходная версия остаётсяnull; текущие исправления сохраняются в истории. Состав новой партии и ограничения — README.md.\n')
sha={str(f.relative_to(B)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(B.rglob('*')) if f.is_file() and f.name!='SHA256SUMS.json'};dump(B/'SHA256SUMS.json',sha)
with zipfile.ZipFile(O/'russian-bank-80f.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(B))
print('Snapshot files',len(sha),'ZIP bytes',(O/'russian-bank-80f.zip').stat().st_size)
