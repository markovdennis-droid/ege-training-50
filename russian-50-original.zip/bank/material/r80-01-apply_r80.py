"""Проверка: python3 apply_r80.py --project /path/to/site
Для записи добавить --apply. Перед записью проверяются все 80 исходных записей.
"""
import argparse,copy,hashlib,json,os,sys
from pathlib import Path
from datetime import datetime
HERE=Path(__file__).resolve().parent

def enc(v):return(json.dumps(v,ensure_ascii=False,indent=1)+'\n').encode()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--apply',action='store_true');a=p.parse_args();root=a.project.resolve()
 edits=json.loads((HERE/'edits.json').read_text());changed={};data={};before={}
 try:
  for e in edits:
   line=e['after']['line'];rel=f'bank/tasks/line-{line:02}.json'
   if rel not in data:data[rel]=json.loads((root/rel).read_text())
   ts=data[rel];hit=[i for i,t in enumerate(ts)if t.get('id')==e['id']]
   if len(hit)!=1 or ts[hit[0]]!=e['before']:raise ValueError(f"Исходная запись изменилась: {e['id']}. Ничего не записано.")
   ts[hit[0]]=e['after']
  for rel,ts in data.items():changed[rel]=enc(ts)
  byid={e['id']:e for e in edits}
  for f in sorted((root/'bank/variants').glob('*.json')):
   if f.name=='index.json':continue
   v=json.loads(f.read_text());modified=False
   for i,t in enumerate(v.get('tasks',[])):
    e=byid.get(t.get('id'))
    if not e:continue
    if t.get('version')!=e['expected_version'] or t.get('opts')!=e['before'].get('opts') or t.get('key')!=e['before'].get('key'):raise ValueError(f"Версия задания в {f.name} изменилась: {e['id']}")
    no=t.get('no',e['after']['line']);v['tasks'][i]=dict(e['after'],no=no);modified=True
   if modified:
    rel=str(f.relative_to(root));changed[rel]=enc(v)
    js='window.VARIANTS=window.VARIANTS||Object.create(null);\nwindow.VARIANTS['+json.dumps(v.get('id',f.stem))+']='+json.dumps(v,ensure_ascii=False,separators=(',',':'))+';\n';changed[str(Path(rel).with_suffix('.js'))]=js.encode()
  for filename,rel in [('blueprints.json','bank/material/r80-01-blueprints.json'),('sources.json','bank/material/r80-01-sources.json')]:
   body=(HERE/filename).read_bytes();target=root/rel
   if target.exists() and target.read_bytes()!=body:raise ValueError(f'Файл материала уже изменён: {rel}')
   changed[rel]=body
 except(OSError,ValueError,KeyError,TypeError)as error:print(str(error),file=sys.stderr);return 1
 print('Подготовлены 80 замен; файлов:',len(changed))
 if not a.apply:print('Проверка без записи. Для применения добавьте --apply.');return 0
 backup=root/('backup-r80-01-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir();done=[]
 try:
  for rel,body in changed.items():
   target=root/rel;before[rel]=target.read_bytes()if target.exists()else None
   if before[rel]is not None:
    b=backup/rel;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(before[rel])
   target.parent.mkdir(parents=True,exist_ok=True);target.with_suffix(target.suffix+'.r80-tmp').write_bytes(body)
  for rel in changed:
   target=root/rel;os.replace(target.with_suffix(target.suffix+'.r80-tmp'),target);done.append(rel)
 except OSError:
  for rel in done:
   if before[rel]is None:(root/rel).unlink(missing_ok=True)
   else:(root/rel).write_bytes(before[rel])
  raise
 finally:
  for rel in changed:
   target=root/rel;target.with_suffix(target.suffix+'.r80-tmp').unlink(missing_ok=True)
 print('Применено 80 редакций; резервная копия:',backup)
 print('Банк не пополнен новыми ID. draft/needs_source сохранены.')
 return 0
if __name__=='__main__':sys.exit(main())
