from pathlib import Path
import re,json,collections,random,hashlib,copy
W=Path('work/original50');P=W/'stress'
src=(P/'fipi-2026-phonetics.txt').read_text();lines=src.splitlines();group=None;entries=[];page=1
headers={'Имена существительные':'noun','Имена прилагательные':'adjective','Глаголы':'verb','Причастия и отглагольные прилагательные':'participle','Деепричастия':'gerund','Наречия':'adverb'}
for line in lines:
 line=line.strip()
 if '\f' in line:page+=1
 header=re.sub(r'\s+',' ',line)
 if header in headers:group=headers[header];continue
 if line.startswith('Обратите внимание!'):break
 if not group or not line or line.startswith(('Навигатор','РУССКИЙ','У слов','измерительных','использована')):continue
 for part in line.split(';'):
  # Strip grammatical explanatory labels while retaining explicit parallel forms before them.
  pos=re.search(r'\b(?:им\.|род\.|вин\.|кр\.|сравн\.|превосх\.|прош\.|глаг\.|сущ\.|прил\.|3-е|2-е)',part)
  if pos:part=part[:pos.start()]
  for tok in re.findall(r'[А-Яа-яЁё]+',part):
   caps=[i for i,c in enumerate(tok) if c.isupper()]
   if len(tok)>2 and len(caps)==1 and tok[caps[0]] in 'АЕЁИОУЫЭЮЯ':
    entries.append({'word':tok.lower(),'correct':tok,'stress_index':caps[0],'group':group,'source_line':line,'source':'ORIGINAL-ORTHO2026'})
# Homographs and their variants are never used as false alternatives.
by=collections.defaultdict(list)
for e in entries:by[e['word']].append(e)
inventory=[];excluded=[]
for word,items in by.items():
 variants=sorted({e['stress_index'] for e in items})
 if len(variants)>1:excluded.append({'word':word,'reason':'контекстно зависимые нормативные варианты ударения','variants':variants});continue
 e=copy.deepcopy(items[0]);e['groups']=sorted({x['group'] for x in items});inventory.append(e)
assert len(inventory)>=190,len(inventory)
base=json.load(open(W/'baseline-tasks.json'));old=[t for t in base if t['line']==4];idx={e['word']:e for e in inventory};problems=[]
for t in old:
 for i,opt in enumerate(t['opts'],1):
  token=re.search(r'[А-Яа-яЁё]+',opt).group();e=idx.get(token.lower())
  if e is None:problems.append({'id':t['id'],'position':i,'word':opt,'reason':'форма не выделена как самостоятельный элемент списка2026'})
  else:
   expected=token==e['correct'];actual=str(i) in t['key'][0]
   if actual!=expected:problems.append({'id':t['id'],'position':i,'word':opt,'reason':'ключ не совпадает с позицией основного ударения2026'})
# Refresh all50 under their existing IDs; no new tasks are counted.
rng=random.Random(20271112);freq=collections.Counter();usedfamilies=set();out=[];history=[]
for i,t in enumerate(sorted(old,key=lambda t:t['id'])):
 for attempt in range(2000):
  count=[2,3,1,4,3][i%5];truth=set(rng.sample(range(5),count));chosen=[];words=set()
  groups=['noun','noun','verb','verb','aux'];rng.shuffle(groups)
  for j in range(5):
   available=[e for e in inventory if (e['group']==groups[j] if groups[j]!='aux' else e['group'] not in ['noun','verb']) and e['word'] not in words and freq[e['word']]<2 and (j in truth or ('ё' not in e['word'] and sum(c in 'аеёиоуыэюя' for c in e['word'])>=2))]
   rng.shuffle(available);available.sort(key=lambda e:(freq[e['word']],any(e['group']==c['group'] for c in chosen)))
   if not available:break
   e=copy.deepcopy(rng.choice(available[:min(25,len(available))]));chosen.append(e);words.add(e['word'])
  if len(chosen)!=5 or len({e['group'] for e in chosen})<3:continue
  family=tuple(sorted(words))
  if family in usedfamilies:continue
  break
 else:raise RuntimeError('Cannot refresh stress task '+t['id'])
 usedfamilies.add(family);opts=[];evidence=[]
 for j,e in enumerate(chosen):
  if j in truth:spelling=e['correct'];correct=True
  else:
   spots=[k for k,c in enumerate(e['word']) if c in 'аеёиоуыэюя' and k!=e['stress_index']];spot=rng.choice(spots);spelling=e['word'][:spot]+e['word'][spot].upper()+e['word'][spot+1:];correct=False
  opts.append(spelling);freq[e['word']]+=1;evidence.append({**e,'shown':spelling,'is_correct':correct})
 n=copy.deepcopy(t);n['opts']=opts;n['key']=[''.join(str(j+1) for j in sorted(truth))];n['exp']='\n'.join(f"{j+1}. {'Верно' if e['is_correct'] else 'Неверно'}. Нормативное основное ударение: {e['correct']}." for j,e in enumerate(evidence));n['evidence']={'stress_items':evidence,'source_policy':'Только явно перечисленные формы из официального списка2026; отдельный допуск2027 ожидается.','alternative_policy':'Неверные позиции расходятся с указанным основным ударением. Ё-слова используются только как верные; контекстные омографы исключены.'};n['version']=t['version']+1 if type(t.get('version')) is int else None
 if n['version'] is None:n['recovery_revision']=t.get('recovery_revision',0)+1
 n['replaces_family']=t['family'];n['family']='orig4-'+hashlib.sha256(json.dumps(family,ensure_ascii=False).encode()).hexdigest()[:20];n['source']='refreshed:official-ortho-list-2026';n['source_refs']=list(dict.fromkeys(t.get('source_refs',[])+['ORIGINAL-ORTHO2026']));n['norm_basis']={'claim':'Основное ударение по явно перечисленным формам официального списка2026; варианты2027 отдельно не утверждены.','rule_source':['ORIGINAL-ORTHO2026'],'type_source':'ФИПИ2027: формат№4','confirmed':False};n['allowed_2027']=None;n['needs_source']=True;n['status']='draft';n['method_work_state']='official_2026_list_refreshed_pending_independent_review';out.append(n);history.append({'id':t['id'],'before':t,'after':n})
assert len(out)==50 and max(freq.values())<=2
for name,a in [('inventory',inventory),('excluded',excluded),('baseline-findings',problems),('tasks',out),('history',history)]:
 (P/(name+'.json')).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
(P/'source.json').write_text(json.dumps({'id':'ORIGINAL-ORTHO2026','title':'ФИПИ. Навигатор самостоятельной подготовки кЕГЭ2026. Фонетика иорфоэпия','url':'https://doc.fipi.ru/navigator-podgotovki/navigator-ege/2026/ru-1-fonetika.pdf','locator':'С.1–5: Орфоэпический список2026, явно перечисленные формы; источник основного ударения, не автоматический допуск2027.','role':'normative_and_list_2026','accessed_at':'2026-11-12'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'listed_unique_forms':len(inventory),'homographs_excluded':len(excluded),'baseline_issues':len(problems),'refreshed_existing_ids':50,'new_ids':0,'max_word_uses':max(freq.values())},ensure_ascii=False))
