from pathlib import Path
import pdfplumber,re,json,html
P=Path('work/full-bank');tasks=json.loads((P/'tasks.json').read_text());byid={t['id']:t for t in tasks if t['line']==22};current=None;active=None;found={};plain={}
def markup(line,start=0):
 text=line['text'];mask=[False]*len(text);pos=0
 for c in line['chars']:
  cs=c['text'];j=text.find(cs,pos)
  if j<0:continue
  for k in range(j,min(j+len(cs),len(mask))):mask[k]='Bold' in c['fontname']
  pos=j+len(cs)
 for j in range(1,len(text)-1):
  if text[j].isspace() and mask[j-1] and mask[j+1]:mask[j]=True
 out='';bold=False
 for j in range(start,len(text)):
  if mask[j]!=bold:out+='<b>' if mask[j] else '</b>';bold=mask[j]
  out+=html.escape(text[j],quote=False)
 if bold:out+='</b>'
 return out
with pdfplumber.open('upload/Банк_целиком_задания.pdf') as pdf:
 pages=sorted({n for t in byid.values() for n in range(t['recovery']['question_pdf_pages'][0],t['recovery']['question_pdf_pages'][1]+1)})
 for n in pages:
  for line in pdf.pages[n-1].extract_text_lines(x_tolerance=2,y_tolerance=3,return_chars=True):
   s=line['text']
   if re.fullmatch('rus-2027-[a-z0-9-]+',s):current=s if s in byid else None;active=None;continue
   if not current:continue
   m=re.match(r'^([АБВГД])\s+',s)
   if m:
    active=ord(m[1])-ord('А') if m[1] in ['А','Б','В'] else {'Г':3,'Д':4}[m[1]]
    # Кириллица не вся последовательна по порядку: В отдельно гарантирована индексом.
    active={'А':0,'Б':1,'В':2,'Г':3,'Д':4}[m[1]]
    found.setdefault(current,{}).setdefault(active,[]).append(markup(line,m.end()));continue
   if re.match(r'^\d+\s+',s) or s.startswith('Ваш ответ:'):active=None
   elif active is not None:found[current][active].append(markup(line))
for id,t in byid.items():
 arr=[' '.join(found[id][j]) for j in range(5)]
 for j,s in enumerate(arr):
  raw=html.unescape(re.sub('</?b>','',s));assert raw==t['left'][j],(id,j,raw,t['left'][j])
 t['left_markup']=arr;t['recovery']['bold_highlights_not_reconstructed']=False;t['recovery']['bold_recovered_from_pdf_fonts']=True
(P/'tasks.json').write_text(json.dumps(tasks,ensure_ascii=False,indent=2)+'\n');(P/'bank/tasks/line-22.json').write_text(json.dumps([t for t in tasks if t['line']==22],ensure_ascii=False,indent=2)+'\n')
f=P/'bank/variants/ru-2027-v001-recovered.json';v=json.loads(f.read_text());
for j,t in enumerate(v['tasks']):
 if t['id'] in byid:v['tasks'][j]={**byid[t['id']],'no':t['no']}
f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print('Полужирные фрагменты восстановлены у',len(byid),'заданий №22.')
