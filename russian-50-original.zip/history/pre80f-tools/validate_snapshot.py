from pathlib import Path
import json,re,collections,html,hashlib
P=Path(__file__).resolve().parent.parent;tasks=sum((json.loads(f.read_text()) for f in sorted((P/'bank/tasks').glob('line-*.json'))),[]);new=json.loads((P/'new-tasks.json').read_text());ids=[t['id'] for t in tasks];errs=[];warn=[]
assert len(tasks)==987 and len(set(ids))==987 and len(new)==80
for t in tasks:
 assert type(t['line']) is int and 1<=t['line']<=27,t['id']
 assert t['stem'],t['id'];assert t['status']=='draft',t['id']
 if t['line']!=27:assert t['key'] and all(isinstance(k,str) and k for k in t['key']),t['id']
 if t['answer_type']=='seq':
  assert len(t['left'])==5 and len(t['right'])==9 and len(t['key'][0])==5 and len(set(t['key'][0]))==5,t['id']
  if t.get('left_markup'):
   assert [html.unescape(re.sub('</?b>','',s)) for s in t['left_markup']]==t['left'],t['id']
 if t.get('version') is None:warn.append(t['id'])
for t in new:
 assert type(t['version']) is int and t['version']>=1 and t['source_refs'] and t['norm_basis']['rule_source'],t['id']
 assert not t['norm_basis']['confirmed'] and t['needs_source'] and t['allowed_2027'] is None,t['id']
 n=t['line'];k=t['key'][0];e=t.get('evidence',{})
 if n==8:
  assert e['left_types']==[e['error_types_by_right'][int(c)-1] for c in k],t['id']
  assert sum(x is not None for x in e['error_types_by_right'])==5
 if n in [13,14]:assert k==''.join(str(j) for j,b in enumerate(e['joined_by_option'],1) if b),t['id']
 if n==14:
  for ss,b in zip(e['correct_spellings_by_option'],e['joined_by_option']):assert b==all(' ' not in s and '-' not in s for s in ss),(t['id'],ss,b)
 if n==15:assert k==''.join(str(j) for j,s in enumerate(e['letters_by_slot'],1) if s=='нн'),t['id']
 if n==16:assert k==''.join(str(j) for j,s in enumerate(e['punctuated_options'],1) if s.count(',')==1),t['id']
 if 17<=n<=20:assert k==''.join(str(j) for j,b in enumerate(e['comma_by_slot'],1) if b),t['id']
 if n==21:
  counter=collections.Counter(e['rule_by_option']);assert [r for r,c in counter.items() if c>1]==[e['shared_rule']]
  assert k==''.join(str(j) for j,r in enumerate(e['rule_by_option'],1) if r==e['shared_rule']),t['id']
 if n==22:assert [t['right'][int(c)-1] for c in k]==e['term_by_left'],t['id']
 if t.get('opts') and n in [5,13,14,16]:assert len(t['opts'])==5,t['id']
 if n==5:
  assert sum(t['opts'][t['error_position']-1].count(w)>0 for w in re.findall(r'\b[А-ЯЁ]{2,}\b',t['opts'][t['error_position']-1]))>=1
  assert all(len(re.findall(r'\b[А-ЯЁ]{2,}\b',s))==1 for s in t['opts']),t['id']
 if n in [8,22]:assert k!='12345',t['id']
 if n>=13:assert k==''.join(sorted(k)) if n!=22 else True,t['id']
report={'bank_tasks':len(tasks),'new_tasks':len(new),'unique_ids':len(set(ids)),'new_unique_families':len({t['family'] for t in new}),'new_keys_recomputed':True,'seq_field_checks':'pass','old22_bold_recovered':19,'unknown_original_versions':len(warn),'new_status':'draft','independent_methodical_acceptance':False,'automatic_checks_only':True}
(P/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
