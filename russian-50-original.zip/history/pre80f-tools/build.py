from pathlib import Path
import sys,json,re,copy,random,hashlib,collections,html
sys.path.insert(0,str(Path(__file__).parent.resolve()));import author_data as A
ROOT=Path('work/full-bank');OUT=Path('output/b80e');OUT.mkdir(parents=True,exist_ok=True)
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def norm(s):return re.sub(r'[^a-zа-я0-9]','',re.sub('</?b>','',s.lower()).replace('ё','е'))
BASE=json.loads((ROOT/'tasks.json').read_text());NEW=[]
SOURCES={
'E-FIPI27':{'title':'ФИПИ. Проект демоверсии, спецификации и кодификатора ЕГЭ 2027','url':'https://fipi.ru/ege/demoversii-specifikacii-kodifikatory','role':'Формат и состав линий; сам по себе не подтверждает норму авторского примера.'},
'E-NE':{'title':'Полный академический справочник. Раздельное написание НЕ','url':'https://gramota.ru/biblioteka/spravochniki/pravila-russkoy-orfografii-i-punktuatsii/razdelnoe-napisanie-ne','locator':'§146; смежные разделы о слитном написании и частице НИ'},
'E-NN':{'title':'Полный академический справочник. Н и НН в производных словах','url':'https://gramota.ru/biblioteka/spravochniki/pravila-russkoy-orfografii-i-punktuatsii/dvoynoe-n-i-odno-n-v-slovakh-obrazovannykh-ot-prilagatelnykh-i-prichastiy','locator':'правописание причастий, отглагольных прилагательных и производных наречий'},
'E-SPELL':{'title':'Грамота.ру. Учебник: слитное, дефисное и раздельное написание','url':'https://gramota.ru/uchebnik','locator':'проверка каждого написания по теме и словарной статье обязательна'},
'E-INTRO':{'title':'Полный академический справочник. Вводные слова, сочетания и предложения','url':'https://gramota.ru/biblioteka/spravochniki/pravila-russkoy-orfografii-i-punktuatsii/znaki-prepinaniya-pri-vvodnykh-slovakh-sochetaniyakh-slov-i-predlozheniyakh','locator':'вводность и отличие от членов предложения'},
'E-SUB':{'title':'Полный академический справочник. Сложноподчинённое предложение','url':'https://gramota.ru/biblioteka/spravochniki/pravila-russkoy-orfografii-i-punktuatsii/znaki-prepinaniya-v-slozhnopodchinennom-predlozhenii','locator':'§115; однородное подчинение; стык союзов и конструкция ЕСЛИ … ТО'},
'E-HOM':{'title':'Полный академический справочник. Однородные члены предложения','url':'https://www.orthographia.ru/punctum_uk.php?rid=72','locator':'§25–27: одиночные, повторяющиеся и двойные союзы'},
'E-ISOL':{'title':'Грамота.ру. Русский язык: краткий теоретический курс. Осложнённые предложения','url':'https://gramota.ru/biblioteka/spravochniki/russkij-yazyk-kratkij-teoreticheskij-kurs-dlya-shkolnikov/oslozhnennye-predlozheniya','locator':'согласованные определения, деепричастия, обращения и вводные конструкции'},
'E-LEX':{'title':'Грамота.ру. Метасловарь','url':'https://gramota.ru/poisk?mode=slovari','locator':'для каждого задания требуется сверка конкретного словосочетания; полный словарный допуск пока не выполнен'},
'E-TROPES':{'title':'ФИПИ. Кодификатор проверяемых средств выразительности','url':'https://fipi.ru/ege/demoversii-specifikacii-kodifikatory','locator':'состав средств выразительности; авторская классификация примеров ещё не принята методистом'},
'E-AUTH':{'title':'Авторская партия 80E · 10.11.2026','role':'Оригинальные предложения и объяснения. Источник не является независимой экспертизой.'}}
for label,p in [('INPUT-BANK-TASKS','upload/Банк_целиком_задания.pdf'),('INPUT-BANK-KEYS','upload/Банк_целиком_ключи_и_объяснения.pdf'),('INPUT-V001','work/pdf-import/Билет_ru-2027-v001_задания.pdf')]:SOURCES[label]={'title':Path(p).name,'local_source':p}
# Словарное значение и редактирование отвлекающих: без стилистически спорной заготовки.
A.PARONYMS[4][3][3]='Резчик вырезал фигурку из ЦЕЛЬНОГО куска дерева.'

def add(n,i,**kw):
 ids=['E-AUTH','E-FIPI27'];t={'id':f'rus-2027-b80e-{n:02}-{i:04}','line':n,'year':2027,'base_year':2026,'version':1,'status':'draft','family':f'b80e-{n:02}-{i:04}','source':'authored:b80e-2026-11-10','source_refs':ids,'allowed_2027':None,'needs_source':True,'reviewer_id':None,'reviewed_at':None,'max_score':2 if n in [8,22] else 1,'answer_type':'seq' if n in [8,22] else 'word' if n in [5,6] else 'digits','match':'exact' if n in [5,6,8,22] else 'unordered','norm_basis':{'claim':'Авторское основание указано в разборе.','rule_source':None,'type_source':'E-FIPI27','confirmed':False,'pending':'Независимая методическая приёмка, сверка нормы и полноты альтернатив не пройдены.'}}
 t.update(kw);NEW.append(t);return t

def set_source(t,*codes):
 t['source_refs']+=list(codes);t['norm_basis']['rule_source']=list(codes)

for i,(bad,key,exp,good) in enumerate(A.PARONYMS,1):
 opts=good.copy();slot=random.Random(8500+i).randrange(5);opts.insert(slot,bad)
 assert all(norm(key) not in norm(o) for j,o in enumerate(opts) if j!=slot)
 t=add(5,i,stem='В одном из выделенных ниже слов неверно употреблён пароним. Исправьте лексическую ошибку, подобрав к выделенному слову пароним. Запишите подобранное слово в нужной форме.',opts=opts,key=[key],exp=f'Ошибка в предложении {slot+1}. '+exp,error_position=slot+1,review_focus='Подтвердить нормативность четырёх отвлекающих и единственность обязательного исправления.');set_source(t,'E-LEX')
for i,(s,keys,exp,fact) in enumerate(A.LEXICAL,1):
 t=add(6,i,stem='Отредактируйте предложение: исправьте лексическую ошибку, заменив неверно употреблённое слово близким по значению. Запишите подобранное слово в нужной форме.\n\n'+re.sub(r'\b[А-ЯЁ]{2,}\b',lambda m:m[0].lower(),s),key=keys,exp=exp,linguistic_fact=fact,key_policy={'kind':'open','on_unmatched':'manual_review','note':'Авторский список не объявляется исчерпывающим. Ответ вне списка не получает автоматический ноль до ручной проверки.'});set_source(t,'E-LEX')
for i,rows in enumerate(A.GRAM,1):
 tags=[tag for tag,_,_ in rows if tag];assert len(tags)==len(set(tags))==5 and len(rows)==9
 lefttags=tags.copy();random.Random(8800+i).shuffle(lefttags);rr=rows.copy();random.Random(8810+i).shuffle(rr)
 key=''.join(str(next(j for j,r in enumerate(rr,1) if r[0]==tag)) for tag in lefttags)
 if key=='12345':rr=rr[1:]+rr[:1];key=''.join(str(next(j for j,r in enumerate(rr,1) if r[0]==tag)) for tag in lefttags)
 t=add(8,i,stem='Установите соответствие между грамматическими ошибками и предложениями, в которых они допущены. К каждой позиции первого списка подберите соответствующую позицию из второго списка.',left=[A.GRAM_NAMES[tag] for tag in lefttags],right=[r[1] for r in rr],key=[key],exp='\n'.join(f'{j}. '+e for j,(tag,s,e) in enumerate(rr,1)),evidence={'error_types_by_right':[r[0] for r in rr],'left_types':lefttags});set_source(t,'E-FIPI27','E-ISOL')
for i,rows in enumerate(A.NE,1):
 rr=rows.copy();random.Random(81300+i).shuffle(rr);key=''.join(str(j) for j,(_,ok,_) in enumerate(rr,1) if ok)
 t=add(13,i,stem='Укажите варианты ответов, в которых НЕ (НИ) с выделенным словом пишется слитно. Запишите номера ответов.',opts=[r[0] for r in rr],key=[key],exp='\n'.join(f'{j}. {"Слитно" if ok else "Раздельно"}: {e}' for j,(_,ok,e) in enumerate(rr,1)),evidence={'joined_by_option':[r[1] for r in rr]});set_source(t,'E-NE')
for i,rows in enumerate(A.SPELL,1):
 rr=rows.copy();random.Random(81400+i).shuffle(rr);key=''.join(str(j) for j,(_,_,ok,_) in enumerate(rr,1) if ok)
 t=add(14,i,stem='Укажите варианты ответов, в которых все выделенные слова пишутся слитно. Запишите номера ответов.',opts=[r[0] for r in rr],key=[key],exp='\n'.join(f'{j}. '+', '.join(forms)+'. '+e for j,(_,forms,ok,e) in enumerate(rr,1)),evidence={'correct_spellings_by_option':[r[1] for r in rr],'joined_by_option':[r[2] for r in rr]});set_source(t,'E-SPELL')
for i,(s,exps) in enumerate(A.NN,1):
 ms=list(re.finditer(r'\[(нн|н)\]',s));assert len(ms)==len(exps)
 key=''.join(str(j) for j,m in enumerate(ms,1) if m[1]=='нн');counter=iter(range(1,len(ms)+1));stem=re.sub(r'\[(нн|н)\]',lambda m:'('+str(next(counter))+')',s)
 t=add(15,i,stem='Укажите все цифры, на месте которых пишется НН.\n\n'+stem,key=[key],exp='\n'.join(f'{j}. {e}' for j,e in enumerate(exps,1)),evidence={'correct_text':s.replace('[нн]','нн').replace('[н]','н'),'letters_by_slot':[m[1] for m in ms]});set_source(t,'E-NN')
for i,rows in enumerate(A.ONE_COMMA,1):
 rr=rows.copy();random.Random(81600+i).shuffle(rr);key=''.join(str(j) for j,(s,e) in enumerate(rr,1) if s.count(',')==1)
 t=add(16,i,stem='Расставьте знаки препинания. Укажите предложения, в которых нужно поставить ОДНУ запятую. Запишите номера этих предложений.',opts=[s.replace(',','') for s,_ in rr],key=[key],exp='\n'.join(f'{j}. Запятых: {s.count(",")}. {s} {e}' for j,(s,e) in enumerate(rr,1)),evidence={'punctuated_options':[s for s,_ in rr],'comma_count':[s.count(',') for s,_ in rr]});set_source(t,'E-HOM','E-ISOL')
for n,data in [(17,A.ISOLATED),(18,A.INTRO),(19,A.SUBORD),(20,A.MIXED)]:
 for i,(s,exp) in enumerate(data,1):
  flags=[int(x) for x in re.findall(r'\[([01])\]',s)];assert flags
  it=iter(range(1,len(flags)+1));body=re.sub(r'\[([01])\]',lambda m:'('+str(next(it))+')',s);key=''.join(str(j) for j,x in enumerate(flags,1) if x)
  full=s.replace('[1]',',').replace('[0]','');full=re.sub(r'\s+,',',',full);full=re.sub(' +',' ',full)
  t=add(n,i,stem='Расставьте знаки препинания. Укажите все цифры, на месте которых должны стоять запятые.\n\n'+body,key=[key],exp=' '.join(exp)+'\n\nПунктуационный эталон: '+full,evidence={'comma_by_slot':flags,'punctuated_text':full});set_source(t,'E-ISOL' if n==17 else 'E-INTRO' if n==18 else 'E-SUB')
LABEL={'part':'обособление причастного оборота после определяемого слова','ger':'обособление деепричастия или деепричастного оборота','intro':'выделение вводного слова или сочетания','coord':'разделение частей сложносочинённого предложения','sub':'отделение придаточной части от главной','hom':'разделение однородных членов','app':'обособление распространённого приложения','clarify':'обособление уточняющего обстоятельства места','appeal':'обособление обращения','asynd':'разделение частей бессоюзного сложного предложения при перечислении'}
for i,rows in enumerate(A.COMMA_GROUPS,1):
 counts=collections.Counter(tag for s,tag in rows);group=[g for g,c in counts.items() if c>1];assert len(group)==1 and counts[group[0]]==3
 rr=rows.copy();random.Random(82100+i).shuffle(rr);key=''.join(str(j) for j,(_,g) in enumerate(rr,1) if g==group[0])
 t=add(21,i,stem='Найдите предложения, в которых запятая (запятые) ставится в соответствии с одним и тем же правилом пунктуации. Запишите номера этих предложений.',opts=[s for s,_ in rr],key=[key],exp='\n'.join(f'{j}. {LABEL[g]}.' for j,(_,g) in enumerate(rr,1)),evidence={'rule_by_option':[g for _,g in rr],'shared_rule':group[0]});set_source(t,'E-ISOL','E-SUB','E-HOM')
TERMS=['антитеза','риторический вопрос','анафора','сравнение','гипербола','парцелляция','градация','эпифора','многосоюзие','бессоюзие','метонимия','риторическое обращение','метафора','олицетворение','эпитет','литота','инверсия','аллитерация']
for i,rows in enumerate(A.EXPRESSIVE,1):
 correct=[r[1] for r in rows];assert len(set(correct))==5
 allowed=[x for x in TERMS if x not in correct and not(x in ['метафора','эпитет'] and 'олицетворение' in correct) and not(x in ['олицетворение','эпитет'] and 'метафора' in correct)]
 # Отвлекающие не дублируют более широкую классификацию уже выбранного тропа; это не заменяет приёмку примеров.
 right=correct+random.Random(82200+i).sample(allowed,4);random.Random(82210+i).shuffle(right)
 key=''.join(str(right.index(term)+1) for term in correct)
 if key=='12345':right=right[1:]+right[:1];key=''.join(str(right.index(term)+1) for term in correct)
 t=add(22,i,stem='Установите соответствие между примерами и названиями средств выразительности. Для каждой позиции первого списка подберите соответствующую позицию из второго списка. Анализируйте выделенные фрагменты. Примеры авторские, не цитаты из литературных произведений.',left=[re.sub('</?b>','',r[0]) for r in rows],left_markup=[r[0] for r in rows],right=right,key=[key],exp='\n'.join(f'{chr(0x410+j) if j<3 else ["Г","Д"][j-3]}–{right.index(term)+1}: {term}. {e}' for j,(_,term,e) in enumerate(rows)),evidence={'term_by_left':correct,'review_risk':'Подтвердить нормативную классификацию и отсутствие допустимого второго соответствия.'});set_source(t,'E-TROPES')
assert len(NEW)==80 and len({t['id'] for t in NEW})==80
assert not {t['id'] for t in NEW}&{t['id'] for t in BASE}
# Поиск точных повторов содержательных условий, полных списков и отдельных примеров по всему восстановленному банку.
def examples(t):
 return [*t.get('opts',[]),*(t.get('right',[]) if t['line']==8 else []),*(t.get('left',[]) if t['line']==22 else [])]+([t['stem'].split('\n\n')[-1]] if t['line'] in [6,15,17,18,19,20] else [])
baseprints={norm(s):t['id'] for t in BASE for s in examples(t) if len(norm(s))>=25};seen={};collisions=[]
for t in NEW:
 for s in examples(t):
  f=norm(s)
  if len(f)<25:continue
  if f in baseprints:collisions.append({'new_id':t['id'],'existing':baseprints[f],'text':s})
  if f in seen and seen[f]!=t['id']:collisions.append({'new_id':t['id'],'new_duplicate':seen[f],'text':s})
  seen[f]=t['id']
assert not collisions,collisions
alltasks=BASE+NEW
for n in range(1,28):dump(OUT/f'bank/tasks/line-{n:02}.json',[t for t in alltasks if t['line']==n])
dump(OUT/'tasks.json',alltasks);dump(OUT/'new-tasks.json',NEW);dump(OUT/'sources.json',SOURCES);dump(OUT/'duplicate-checks.json',{'exact_example_collisions':collisions,'normalization':'буквы/цифры; без регистра, пунктуации и различия Ё/Е','limitation':'Лексически разные перефразировки не объявляются доказанно уникальными по языковому факту.'})
dump(OUT/'batch-summary.json',{'batch':'80E','date':'2026-11-10','recovered_bank':907,'new_tasks':80,'bank_after':len(alltasks),'per_new_line':dict(sorted(collections.Counter(t['line'] for t in NEW).items())),'new_full_variants':0,'new_texts':0,'independent_method_review':False,'status':'draft','note':'Не включает ранее описанную, но не присланную партию 80D: новые ID — 80E. Восстановленные 907 и новые 80 учитываются раздельно.'})
print(json.dumps({'new':len(NEW),'bank':len(alltasks),'exact_collisions':len(collisions),'keys':{str(n):[t['key'][0] for t in NEW if t['line']==n] for n in range(13,23)}},ensure_ascii=False))
