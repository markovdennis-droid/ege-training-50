from pathlib import Path
import re,json,hashlib,copy,collections
I=Path('work/pdf-import');O=Path('work/full-bank');O.mkdir(parents=True,exist_ok=True)
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def norm(s):return re.sub(r'\s+',' ',s.replace('\u00ad','')).strip()
def sections(name):
 pages=json.loads((I/(name+'-clean-pages.json')).read_text());text='';starts=[]
 for i,p in enumerate(pages,1):starts.append((len(text),i));text+=p+'\n'
 matches=list(re.finditer(r'^(rus-2027-[a-z0-9-]+)\s*$',text,re.M));out={}
 for j,m in enumerate(matches):
  end=matches[j+1].start() if j+1<len(matches) else len(text);raw=text[m.end():end];raw=re.sub(r'\nЛиния \d+ —[^\n]*(?:\n|$)','\n',raw)
  p1=max(p for x,p in starts if x<=m.start());p2=max(p for x,p in starts if x<end)
  out[m[1]]={'raw':raw.strip(),'pages':[p1,p2]}
 return out
q=sections('Банк_целиком_задания');k=sections('Банк_целиком_ключи_и_объяснения');assert len(q)==len(k)==907 and set(q)==set(k)
notes=[];tasks=[];tmap={};c80={t['id']:t for t in json.loads(Path('work/recovered-80c-sync/KEYS.json').read_text())['keys']}
for tid,x in q.items():
 ln=int(tid.split('-')[-2]);body=re.split(r'Ваш ответ:',x['raw'])[0].strip();body=re.sub(r'\nЛиния \d+ —[^\n]*','',body).strip()
 kb=k[tid]['raw'];mk=re.search(r'^Ответ:\s*\n?([^\n]+)',kb,re.M)
 if ln==27:keys=[];exp=kb
 else:
  assert mk,(tid,kb[:100]);ks=mk[1].strip();keys=[v.strip() for v in ks.split(',')] if ln in [1,5,6,7,25] else [norm(ks)]
  assert keys and all(keys),tid;exp=kb[mk.end():].strip()
 pending=re.search(r'\nНорма источником[^\n]*',exp)
 normnote=norm(exp[pending.start():]) if pending else None
 if pending:exp=exp[:pending.start()].strip()
 exp=norm(exp)
 typ='essay' if ln==27 else 'seq' if ln in [8,22] else 'word' if ln in [1,5,6,7,25] else 'digits'
 t={'id':tid,'line':ln,'year':2027,'version':None,'status':'draft','source':'recovered:bank-pdf-2026-11-10','family':'recovered-'+hashlib.sha256((str(ln)+'|'+norm(body)).encode()).hexdigest()[:20],'stem':None,'key':keys,'exp':exp,'answer_type':typ,'match':None if typ=='essay' else 'exact' if typ in ['word','seq'] or ln==26 else 'unordered','max_score':22 if ln==27 else 2 if ln in [8,22] else 1,'needs_source':True,'allowed_2027':None,'reviewer_id':None,'reviewed_at':None,'norm_basis':{'claim':normnote,'rule_source':None,'type_source':None,'confirmed':False},'source_refs':['INPUT-BANK-TASKS','INPUT-BANK-KEYS'],'recovery':{'question_pdf_pages':x['pages'],'key_pdf_pages':k[tid]['pages'],'original_version_unknown':True,'original_family_missing':True,'raw_statement':body,'raw_key_block':kb,'formatting_review':'PDF text extraction; original PDF retained'}}
 if typ=='seq':
  # Печатный список слева А–Д, справа 1–9.
  mm=list(re.finditer(r'^([АБВГД])\s+(.+?)(?=^[АБВГД]\s+|^\d{1,2}\s+|\Z)',body,re.M|re.S));nm=list(re.finditer(r'^(\d{1,2})\s+(.+?)(?=^\d{1,2}\s+|\Z)',body,re.M|re.S))
  assert len(mm)==5 and len(nm)==9,(tid,len(mm),len(nm),body)
  t['stem']=norm(body[:mm[0].start()]);t['left']=[norm(m[2]) for m in mm];t['right']=[norm(m[2]) for m in nm]
  if ln==22:t['recovery']['bold_highlights_not_reconstructed']=True
 else:
  mm=list(re.finditer(r'^(\d{1,2})\.\s+(.+?)(?=^\d{1,2}\.\s+|\Z)',body,re.M|re.S))
  if mm:
   assert [int(m[1]) for m in mm]==list(range(1,len(mm)+1)),tid;t['stem']=norm(body[:mm[0].start()]);t['opts']=[norm(m[2]) for m in mm]
  else:t['stem']=norm(body)
 if tid in c80:
  c=c80[tid]
  if c['key']==keys:t['version']=c['version'];t['recovery']['original_version_unknown']=False;t['recovery']['version_source']='80c-sync.zip/KEYS.json'
  else:notes.append({'id':tid,'conflict':'80C key sheet vs bank PDF','sheet':c['key'],'pdf':keys})
 tasks.append(t);tmap[tid]=t
# Применяем полные записи поздней R80-01; PDF-снимки сохраняются как история, а не теряются.
r80=json.loads(Path('work/recovered-r80/source/tasks.json').read_text());patches=[];history=[]
for r in r80:
 old=tmap[r['id']];history.append(copy.deepcopy(old));different=(old.get('opts')!=r.get('opts') or old['key']!=r['key'])
 rr=copy.deepcopy(r);rr['recovery']={'record_from':'russian-review-80-r1(1).html embedded tasks.json','original_full_metadata':True,'pdf_snapshot_question_pages':old['recovery']['question_pdf_pages'],'pdf_snapshot_key_pages':old['recovery']['key_pdf_pages'],'pdf_snapshot_different':different}
 tasks[tasks.index(old)]=rr;tmap[r['id']]=rr;patches.append({'id':r['id'],'pdf_content_differed':different,'version':r['version']})
# Исходные тексты из настоящего авторского варианта; демо-v1/v2 сохраняются PDF-снимками отдельно.
vtext=(I/'Билет_ru-2027-v001_задания-clean.txt').read_text();vtext=re.sub(r'(rus-2027-[a-z0-9-]*-)\n([a-z0-9-]+)(?=\n)',r'\1\2',vtext);shortblock=re.search(r'Текст к заданиям 1, 2, 3\n(.*?)\nЗадание 1 ·',vtext,re.S)[1]
mainblock=re.search(r'Текст к заданиям 23, 24, 25, 26, 27\n(.*?)\nЗадание 23 ·',vtext,re.S)
if not mainblock:
 matches=list(re.finditer(r'Текст к заданиям[^\n]*',vtext));print('TEXTHEADERS',[m[0] for m in matches]);raise ValueError('Main text header missing')
texts={}
for id,kind,b in [('ru-2027-A001','short',shortblock),('ru-2027-B001','main',mainblock[1])]:
 ss=list(re.finditer(r'\((\d+)\)\s*(.*?)(?=\(\d+\)|\Z)',b,re.S));assert ss
 sentences=[norm(m[2]) for m in ss]
 # Подпись источника после текста не является последним предложением.
 sentences[-1]=re.split(r'Авторский текст\.|Авторский учебный текст\.',sentences[-1])[0].strip()
 texts[id]={'id':id,'kind':kind,'caption':norm(b[:ss[0].start()]),'sentences':sentences,'status':'draft','version':None,'source':'recovered:Билет_ru-2027-v001_задания.pdf','source_refs':['INPUT-V001'],'allowed_2027':None}
for t in tasks:
 if t['line'] in [1,2,3]:t['text']='ru-2027-A001'
 if t['line'] in [23,24,25,26,27]:t['text']='ru-2027-B001'
# Проблема и позиция могут находиться в печатном задании; не изобретаем потерянные ориентиры.
ess=tmap['rus-2027-27-0001'];p=re.search(r'Проблема[^\n]*\n?(.*?)(?=Напишите|Ваш ответ)',vtext[vtext.rfind('Задание 27'):],re.S)
if p:ess['problem']=norm(p[1])
else:ess['problem']='В чём проявляется уважение к чужому труду?';ess['recovery']['problem_source']='Ранее зафиксирована в переписке; требует сверки с формулировкой PDF'
ess['author_position']='Уважение к чужому труду начинается с готовности разобраться в сделанном до тебя и учитывать чужую работу.';ess['recovery']['author_position_source']='Восстановленный ориентир по тексту, не оригинальное поле JSON'
# Нумерация строк заданий в архивном варианте задаёт список ID.
vids=re.findall(r'Задание\s+(\d+)\s*·[^\n]*?\b(rus-2027-[a-z0-9-]+)',vtext)
assert len(vids)==27,(len(vids),vids)
V={'id':'ru-2027-v001-recovered','title':'Вариант 001 · восстановленный; №9–12 сверены с R80-01','status':'draft','tasks':[],'texts':texts,'format':'ЕГЭ-2027','subject':'Русский язык','recovery':{'source_pdf':'Билет_ru-2027-v001_задания.pdf','source_variant_id':'ru-2027-v001','substitutions':[]}}
for n,tid in vids:
 if tid not in tmap:
  assert int(n)==12,(n,tid)
  replacement=next(r for r in r80 if r['line']==12);V['recovery']['substitutions'].append({'line':12,'old_id':tid,'selected_id':replacement['id'],'reason':'Вариантный ID отсутствует в PDF общего банка; исходное условие сохранено в PDF билета'})
  t=copy.deepcopy(tmap[replacement['id']])
 else:t=copy.deepcopy(tmap[tid])
 t['no']=int(n)
 # 9 и 11 в старом PDF остаются вне переработки R80: для проверки даём отдельную новую сборку из доступных исправленных записей.
 if t['line'] in [9,11] and t['id'] not in {x['id'] for x in r80}:
  r=next(x for x in r80 if x['line']==t['line']);V['recovery']['substitutions'].append({'line':t['line'],'old_id':tid,'selected_id':r['id']});t=copy.deepcopy(tmap[r['id']]);t['no']=int(n)
 V['tasks'].append(t)
for n in range(1,28):dump(O/f'bank/tasks/line-{n:02}.json',[t for t in tasks if t['line']==n])
for tid,T in texts.items():dump(O/f'bank/texts/{tid}.json',T)
dump(O/'bank/variants/ru-2027-v001-recovered.json',V)
dump(O/'bank/material/pdf-original-r80-records.json',history);dump(O/'bank/material/recovery-conflicts.json',notes);dump(O/'bank/material/r80-restoration.json',patches)
summary={'pdf_task_ids':len(q),'pdf_key_ids':len(k),'joined_tasks':len(tasks),'r80_full_records_applied':len(r80),'r80_different_from_pdf':sum(x['pdf_content_differed'] for x in patches),'version_known':sum(t['version'] is not None for t in tasks),'version_unknown':sum(t['version'] is None for t in tasks),'keys_80c_conflicts':notes,'per_line':dict(sorted(collections.Counter(t['line'] for t in tasks).items())),'recovered_texts':{k:len(v['sentences']) for k,v in texts.items()},'variant_tasks':len(V['tasks']),'variant_substitutions':V['recovery']['substitutions']}
dump(O/'RECOVERY.json',summary);dump(O/'tasks.json',tasks);dump(O/'texts.json',list(texts.values()));print(json.dumps(summary,ensure_ascii=False,indent=2))
