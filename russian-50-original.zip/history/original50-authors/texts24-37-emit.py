import json,re,hashlib,runpy
from pathlib import Path
D=runpy.run_path('work/original50/authors/texts24-37-build.py')['DATA']
P=Path('work/original50/authors')
plan=json.load(open(P/'texts24-37-plan.json'))['pairs']
topics={x['i']:x for x in plan}
texts=[];tasks=[];sources=[];checks=[]
for i,d in sorted(D.items()):
 a=f'ru-2027-O-A{i:03}';b=f'ru-2027-O-B{i:03}'
 for kind,tid,title,ss in [('short',a,topics[i]['short'],d['short']),('main',b,topics[i]['main'],d['main'])]:
  sid=f'AUTHOR-O-{i:03}-{kind}'
  texts.append({'id':tid,'kind':kind,'caption':title,'sentences':ss,'for':[1,2,3] if kind=='short' else [23,24,25,26,27],'year':2027,'base_year':2026,'version':1,'status':'draft','needs_source':True,'allowed_2027':None,'source':'Авторский учебный текст, созданный для данного комплекта; реальному писателю не приписывается.','source_refs':[sid]+([f'SCI-O-{i:03}'] if kind=='short' and 'sci' in d else []),'agent_review':{'state':'author_checked_draft','human_methodologist_accepted':False}})
  sources.append({'id':sid,'title':f'Авторский учебный текст {tid}','url':None,'locator':f'{tid}; предложения 1–{len(ss)}','role':'authored_text','text_id':tid})
 if 'sci' in d:
  title,url,loc=d['sci'];sources.append({'id':f'SCI-O-{i:03}','title':title,'url':url,'locator':loc,'role':'factual_primary_science','text_id':a})
 for line in [1,2,3,23,24,25,26,27]:
  tid=a if line<4 else b
  t={'id':f'rus-2027-orig-{line:02}-{i:04}','line':line,'year':2027,'base_year':2026,'version':1,'status':'draft','needs_source':True,'allowed_2027':None,'reviewer_id':None,'reviewed_at':None,'source':'Авторское задание к новому авторскому тексту','family':f'orig-o{i:03}-line{line:02}-independent','text':tid,'max_score':22 if line==27 else 1,'answer_type':'essay' if line==27 else 'word' if line in [1,25] else 'digits','match':None if line==27 else 'exact' if line in [1,25,26] else 'unordered','norm_basis':{'claim':'Авторское основание и самостоятельная проверка ключа; нормативный и форматный допуск требуют методической проверки.','rule_source':None,'type_source':None,'confirmed':False},'source_refs':[f'AUTHOR-O-{i:03}-'+('short' if line<4 else 'main'),'FORMAT-2027-PENDING'],'method_work_state':'draft_pending_review'}
  if line==1:
   stem,key,exp=d['q1'];t.update(stem=stem,key=[key],exp=exp,linguistic_fact='Контекстуальный выбор служебного или местоименного слова с заданным грамматическим ограничением.')
  elif line in [2,3,23,24]:
   opts,key,ex=d[f'q{line}'];stem={2:'В тексте прописными буквами выделены пять слов. Укажите варианты ответов, в которых толкование соответствует значению слова в данном тексте. Запишите номера ответов.',3:'Укажите верные характеристики текста. Запишите номера ответов.',23:'Какие высказывания соответствуют содержанию текста? Запишите номера ответов.',24:'Какие из утверждений о тексте верны? Запишите номера ответов.'}[line]
   t.update(stem=stem,opts=opts,key=[key],exp=' '.join(ex),linguistic_fact={2:'Различение контекстуальных значений многозначных слов.',3:'Стиль и языковые признаки конкретного научно-популярного текста.',23:'Проверка содержания и причинно-следственных отношений.',24:'Типы речи и смысловые отношения частей текста.'}[line])
  elif line==25:
   lo,hi,meaning,key,n=d['q25'];t.update(stem=f'Из предложений {lo}–{hi} выпишите фразеологизм со значением «{meaning}».',key=[key],exp=f'В предложении {n} употреблён фразеологизм «{key}» в значении «{meaning}». Выписывается в форме текста; зависимые слова, не входящие в устойчивый оборот, не добавляются.',linguistic_fact='Узнавание устойчивого сочетания в переносном значении.',evidence={'range':[lo,hi],'sentence':n,'accepted_boundaries':[key],'lexicographic_check':'pending_primary_dictionary'})
  elif line==26:
   lo,hi,n,means,ex=d['q26'];t.update(stem=f'Среди предложений {lo}–{hi} найдите такое, которое связано с предыдущим с помощью {means}. Запишите номер этого предложения.',key=[str(n)],exp=' '.join(ex)+' Требуется один номер; порядок цифр фиксирован.',linguistic_fact='Выявление двух конкретных средств связи с непосредственно предыдущим предложением.',evidence={'range':[lo,hi],'target':n,'all_candidates_reviewed':list(range(lo,hi+1)),'candidate_analysis':ex})
  else:
   t.update(stem='Напишите сочинение-рассуждение по проблеме: «'+d['problem']+'» Сформулируйте позицию автора (рассказчика). Прокомментируйте, как она раскрывается в тексте: включите два примера-иллюстрации, поясните каждый из них, укажите и объясните смысловую связь между ними. Выразите и обоснуйте своё отношение к позиции автора, приведя самостоятельный пример-аргумент из читательского, историко-культурного или жизненного опыта. Не используйте в качестве источников аргумента комикс, аниме, мангу, фанфик, графический роман, компьютерную игру и подобные виды представления информации. Объём — не менее 150 слов. Работа без опоры на данный текст или полностью воспроизводящая его без комментариев не оценивается.',key=[],exp='Открытая работа; автоматическая проверка не предусмотрена. Позиция и пары ниже — ориентиры для содержательной оценки, а не единственный допустимый комментарий.',problem=d['problem'],author_position=d['position'],essay_guide={'pairs':[{'examples':e,'relation':r,'comment':c,'limits':l} for e,r,c,l in d['pairs']],'limits':'Допустимы другие доказуемые примеры и формулировки; оценивается самостоятельный анализ, а не совпадение с ориентиром.','minimum_words':150,'automated_grading':False},linguistic_fact='Связное рассуждение об авторской позиции с текстовыми примерами и самостоятельным аргументом.')
  tasks.append(t)
 wc=lambda ss:sum(len(re.findall(r'[А-Яа-яЁёA-Za-z0-9]+(?:[-–][А-Яа-яЁёA-Za-z0-9]+)*',s)) for s in ss)
 checks.append({'pair':i,'short_words':wc(d['short']),'short_sentences':len(d['short']),'main_words':wc(d['main']),'main_sentences':len(d['main']),'source_text_original':True,'compared_to':'baseline-texts.json + texts10-23-plan.json','author_key_recheck':True,'line26_all_candidates_analyzed':True,'line27_two_pairs':True,'independent_review':False,'human_accepted':False,'remaining':['Проверка методистом','Словарное подтверждение фразеологизма','Подтверждение формата окончательным документом 2027']})
sources.append({'id':'FORMAT-2027-PENDING','title':'Формат ФИПИ 2027: требуется точное первичное подтверждение редакции','url':None,'locator':'pending; локальные документы проекта не выдаются за принятую норму','role':'format_pending'})
result={'tasks':tasks,'texts':texts,'sources':sources,'author_checks':checks}
filename=P/('texts24-37.json' if len(D)==14 else f'texts24-37-checkpoint-{max(D)}.json')
filename.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(filename,len(texts),len(tasks))
for c in checks: print(c['pair'],c['short_words'],c['short_sentences'],c['main_words'],c['main_sentences'])
