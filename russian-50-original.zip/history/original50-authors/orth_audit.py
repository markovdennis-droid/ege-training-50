import json,re,hashlib,difflib
from pathlib import Path
root=Path('work/original50');new=json.load(open(root/'authors/orth.json'));old=json.load(open(root/'input/orth-baseline.json'))
pat=r'(?:[А-ЯЁ]*\([А-ЯЁ]+\))+[А-ЯЁ]*'
def marks(s):return re.findall(pat,s)
def norm(s):return re.sub(r'[^а-яё0-9]','',s.lower()).replace('ё','е')
errors=[]
for t in new['tasks']:
 assert t['year']==2027 and t['base_year']==2026 and t['version']==1 and t['status']=='draft'
 assert t['needs_source'] is True and t['allowed_2027'] is None and t['norm_basis']['confirmed'] is False
 ev=t['evidence']
 if t['line'] in (13,14):
  flags=[]
  for n,(opt,fs) in enumerate(zip(t['opts'],ev['correct_spellings_by_option'])):
   ms=marks(opt)
   if len(ms)!=len(fs):errors.append([t['id'],n+1,'marker count',ms,fs])
   if [norm(m) for m in ms]!=[norm(f) for f in fs]:errors.append([t['id'],n+1,'reconstruction',ms,fs])
   joined=all(' ' not in f and '-' not in f for f in fs)
   if joined!=ev['joined_by_option'][n]:errors.append([t['id'],n+1,'join flags mismatch'])
   flags.append(joined)
  k=''.join(str(i+1) for i,x in enumerate(flags) if x)
 else:
  st=t['stem'].split('\n\n',1)[1]
  for i,(letters,word) in enumerate(zip(ev['letters_by_slot'],ev['words_by_slot']),1):
   m=re.search(r'[А-Яа-яЁё]*\('+str(i)+r'\)[А-Яа-яЁё]*',st)
   if not m or norm(m.group().replace(f'({i})',letters))!=norm(word):errors.append([t['id'],i,'slot reconstruction'])
  k=''.join(str(i+1) for i,x in enumerate(ev['letters_by_slot']) if x=='нн')
 if t['key']!=[k]:errors.append([t['id'],'key mismatch'])
 if len(k)<2 or len(k)>4:errors.append([t['id'],'unbalanced correct count',k])
 if 'CHECK' in json.dumps(t):errors.append([t['id'],'draft placeholder'])
ids=[t['id'] for t in new['tasks']];families=[t['family'] for t in new['tasks']]
assert len(ids)==len(set(ids))==57
assert not set(families)&{t['family'] for t in old}
old_sent={norm(o) for t in old for o in (t.get('opts') or [t['stem']])}
new_sent=[(t['id'],o) for t in new['tasks'] for o in (t.get('opts') or [t['stem']])]
assert len({norm(s) for _,s in new_sent})==len(new_sent)
assert not any(norm(s) in old_sent for _,s in new_sent)
# Набор всех проверяемых лексем целого задания не повторяет прежний набор.
def sig(t):
 if t['line']==15:
  return tuple(re.findall(r'[а-яё]+\(\d\)[а-яё]+',t['stem'].lower()))
 return tuple(sorted(norm(w) for o in t.get('opts',[]) for w in marks(o)))
old_sigs={sig(t) for t in old}
assert not any(sig(t) in old_sigs for t in new['tasks'])
newsigs=[sig(t) for t in new['tasks']];assert len(newsigs)==len(set(newsigs))
# Проверка повторов двухсловных рядов отдельно от полных наборов, для ручного просмотра.
oldpairs={tuple(sorted(norm(w) for w in marks(o))):t['id'] for t in old if t['line']==14 for o in t['opts']}
pair_collisions=[]
for t in new['tasks']:
 if t['line']==14:
  for j,o in enumerate(t['opts'],1):
   s=tuple(sorted(norm(w) for w in marks(o)))
   if s in oldpairs:pair_collisions.append([t['id'],j,oldpairs[s],s])
# Максимальное посимвольное совпадение полных фраз с исходной базой — диагностический список.
oldphrases=[o for t in old for o in (t.get('opts') or [t['stem']])]
nearest=[]
for id,s in new_sent:
 best=max((difflib.SequenceMatcher(None,norm(s),norm(o)).ratio(),o) for o in oldphrases)
 nearest.append({'id':id,'new':s,'similarity':round(best[0],3),'old':best[1]})
nearest.sort(key=lambda x:-x['similarity'])
report={'structural_errors':errors,'tasks':57,'line_counts':{str(l):sum(t['line']==l for t in new['tasks']) for l in (13,14,15)},'exact_sentence_duplicates':0,'exact_task_wordset_duplicates':0,'pair_collisions_for_review':pair_collisions,'nearest_phrases':nearest[:12],'note':'Механическая проверка не доказывает норму или оригинальность: содержательный авторский повторный проход описан отдельно.'}
(root/'authors/orth.audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('nearest_phrases',)},ensure_ascii=False,indent=2))
print(json.dumps(nearest[:6],ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
