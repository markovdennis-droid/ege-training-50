#!/usr/bin/env python3
"""R80-02 authoring and deterministic structural self-check for line 9.
Only writes line-09.json; input and shared bank remain unchanged.
"""
import collections, copy, hashlib, itertools, json, random, re
from pathlib import Path
BASE=Path('work/r80-02')
INPUT=json.loads((BASE/'input/line-09.json').read_text())
# Explicit author review: strengthen lexical context; preserve one actual gap.
CONTEXT={
0:'к..саться (важного вопроса)',1:'к..сательная (к окружности)',2:'прик..саться (к горячему утюгу)',
3:'соприк..саться (поверхностями)',4:'к..снуться (рукой стены)',5:'прик..сновение (руки)',
6:'соприк..сновение (двух поверхностей)',7:'прик..снуться (к руке)',8:'предл..гать (план действий)',
9:'изл..гать (свои доводы)',10:'прил..гать (усилия)',11:'пол..гать (что решение верно)',
12:'предл..жение (сотрудничать)',13:'изл..жение (содержания книги)',14:'прил..жение (к договору)',15:'пол..жение (предмета в пространстве)',
26:'заг..релый (после отпуска)',27:'заг..реть (на солнце)',28:'приг..реть (о пище на плите)',
29:'сг..рать (в огне)',30:'выг..реть (на солнце)',31:'оз..рение (внезапная догадка)',
32:'оз..рённый (солнцем)',33:'оз..рять (светом)',34:'з..рница (летняя)',35:'покл..ниться (зрителям)',
36:'накл..нение (оси)',37:'скл..ниться (над книгой)',38:'укл..няться (от ответа)',
39:'соб..рать (коллекцию марок)',40:'выб..рать (лучший вариант)',41:'проб..раться (сквозь чащу)',
42:'зад..рать (голову)',43:'уд..рать (от погони)',44:'зам..рать (от восторга)',45:'ум..рать (от голода)',
46:'зап..рать (дверь на ключ)',47:'отп..рать (дверь ключом)',48:'выт..рать (пыль)',49:'раст..рать (краски)',
50:'расст..лать (скатерть)',51:'заст..лать (постель)',52:'бл..стать (талантом)',53:'сж..гать (сухую листву)',
54:'выж..гать (узор на дереве)',55:'выч..тать (число из суммы)',56:'(я) соб..ру коллекцию',
57:'(я) выб..ру платье',58:'(я) проб..русь сквозь толпу',59:'(я) зад..ру голову',60:'(я) уд..ру от погони',
61:'зам..реть (от восторга)',62:'ум..реть (от болезни)',63:'зап..реть (дверь)',64:'отп..реть (замок)',
65:'выт..реть (стол)',66:'раст..реть (краски)',67:'расст..лить (скатерть)',68:'заст..лить (постель)',
69:'бл..стеть (на солнце)',70:'выж..гший (узор)',71:'выч..т (налоговый)',
73:'уд..ляться (от берега)',74:'тр..ва (луговая)',75:'ш..ги (пешехода)',79:'ч..стота (пульса)',80:'с..ды (плодовые)',
81:'в..да (питьевая)',82:'г..ра (высокая)',83:'м..рской (берег)',84:'тр..па (лесная)',89:'в..лна (морская)',92:'п..ро (птичье)',
95:'с..дой (старик)',96:'скр..пить (доски)',98:'осв..тить (комнату лампой)',99:'прим..рять (платье)',100:'л..са (рыжий зверь)',
105:'прим..рять (поссорившихся друзей)',142:'д..плом (об окончании вуза)',110:'к..мпания (избирательная)',120:'к..мпания (весёлых друзей)',
}
LEMMAS={19:'вырастить',23:'вырасти',32:'озарить',56:'собрать',57:'выбрать',58:'пробраться',59:'задрать',60:'удрать',70:'выжечь',75:'шаг',80:'сад'}
ROOTS={0:'кас',1:'кас',2:'кас',3:'кас',4:'кас',5:'кас',6:'кас',7:'кас',8:'лаг',9:'лаг',10:'лаг',11:'лаг',12:'лаг',13:'лаг',14:'лаг',15:'лаг',16:'раст',17:'раст',18:'раст',19:'раст',20:'раст',21:'раст',22:'раст',23:'раст',24:'раст',26:'гар',27:'гар',28:'гар',29:'гар',30:'гар',31:'зар',32:'зар',33:'зар',34:'зар',35:'клон',36:'клон',37:'клон',38:'клон',72:'дал',73:'дал',97:'свет',98:'свет',99:'мер',105:'мир'}
for ids,root in [([39,40,41,56,57,58],'бер'),([42,43,59,60],'дер'),([44,45,61,62],'мер'),([46,47,63,64],'пер'),([48,49,65,66],'тер'),([50,51,67,68],'стел'),([52,69],'блист'),([53,54,70],'жиг'),([55,71],'чет')]:
 for ix in ids: ROOTS[ix]=root
SOURCES=[
 {'id':'R2-09-ROOT34','title':'Правила русской орфографии и пунктуации. Полный академический справочник под ред. В. В. Лопатина','url':'https://orthographia.ru/orfografia.php?sid=31','locator':'§34: проверяемые безударные гласные; абзац о словарном порядке непроверяемых гласных','role':'language_norm'},
 {'id':'R2-09-AO','title':'ИРЯ РАН. Орфографическое комментирование русского словаря','url':'https://oross.ruslang.ru/paragraph/24','locator':'§24, пп.1–5 и 9: гар/гор, зар/зор, кас/кос, клан/клон, лаг/лож, раст/рос','role':'language_norm'},
 {'id':'R2-09-EI','title':'ИРЯ РАН. Орфографическое комментирование русского словаря','url':'https://oross.ruslang.ru/paragraph/27','locator':'§27, п.1: е/и в бер/бир, дер/дир, мер/мир, пер/пир, тер/тир, блест/блист, жег/жиг, стел/стил, чет/чит; примечание 2 об омонимичных корнях','role':'language_norm'},
 {'id':'R2-09-ROS','title':'Русский орфографический словарь. Нормативный словарь на портале Грамота.ру','url':'https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf','locator':'Алфавитные статьи; точная статья указана в source_locators каждого элемента','role':'spelling_dictionary'},
 {'id':'R2-09-ROS-ONLINE','title':'Русский орфографический словарь под ред. В. В. Лопатина и О. Е. Ивановой. Поиск по Грамоте','url':'https://gramota.ru/poisk?mode=slovari','locator':'Русский орфографический словарь; конкретная лемма и URL поиска указаны у элемента','role':'spelling_dictionary'},
 {'id':'R2-09-FORMAT','title':'ФИПИ. Проект демонстрационных материалов ЕГЭ 2027. Русский язык','url':'https://fipi.ru/ege/demoversii-specifikacii-kodifikatory','locator':'Задание 9; локальный файл work/b80g/authors/lex-work/fipi/РУ-11 ЕГЭ 2027 ДЕМО.txt','role':'format_only','note':'Не является подтверждением нормы авторских слов.'},
]
from urllib.parse import quote
POOL=[]
for ix,raw in enumerate(INPUT['inventory']):
 # Attack's second a is checked by ата́ка, not lexical. Заро́сший has a stressed target.
 if ix in (25,109): continue
 item=copy.deepcopy(raw)
 item.pop('dictionary_check',None)
 item['inventory_index']=ix
 item['template']=CONTEXT.get(ix,item['template'])
 item['word']=raw['word'].split(' (')[0]
 item['lemma']=LEMMAS.get(ix,raw['lemma'])
 item['lexeme']=item['lemma']
 item['root_family']=ROOTS.get(ix,item['lemma'])
 # Minimal, per-position explanation, independent of the old dictionary flags.
 group=item['group']
 rule_ref='R2-09-AO' if group=='alt_AO' else 'R2-09-EI' if group=='alt_EI' else 'R2-09-ROOT34'
 item['source_refs']=[rule_ref,'R2-09-ROS','R2-09-ROS-ONLINE']
 item['source_locators']=[{'source_id':rule_ref,'locator':next(s['locator'] for s in SOURCES if s['id']==rule_ref)},
  {'source_id':'R2-09-ROS','locator':'Статья «'+item['lemma']+'»; для производной формы также правило словоизменения'},
  {'source_id':'R2-09-ROS-ONLINE','locator':'Русский орфографический словарь: «'+item['lemma']+'»','url':'https://gramota.ru/poisk?mode=slovari&query='+quote(item['lemma'])}]
 item['alternative_check']='Контекст и значение учтены; другая гласная, сохраняющая указанное слово и контекст, автором не найдена.'
 POOL.append(item)
# Checkable ambiguous pairs explicitly distinguished by meaning.
GROUPS=list(dict.fromkeys(i['group'] for i in POOL))
BYGROUP={g:[i for i in POOL if i['group']==g] for g in GROUPS}
def core(s):
 gap=re.search(r'[а-яё]+\.\.[а-яё]*',s.lower())
 if gap:return gap.group(0)
 return re.sub(r'\([^)]*\)','',s).strip().lower()
def row_token(r): return tuple(sorted(core(i['template']) for i in r))
def row_words(r): return tuple(sorted(i['word'] for i in r))
OLD_TEMPLATES=set()
OLD_WORDS=set()
for t in INPUT['existing_tasks']:
 for opt in t.get('opts',[]): OLD_TEMPLATES.add(tuple(sorted(core(s) for s in opt.split(','))))
 if 'drill' in t:
  for row in t['drill']['rows']: OLD_WORDS.add(tuple(sorted(core(''.join(w)) for w in row)))
for p in INPUT['current_passports']:
 for row in p['rows']: OLD_WORDS.add(tuple(sorted(core(i['word']) for i in row['items'])))
# Seed and least-used preference make material selection reproducible, with no manual key.
for restart in range(100):
 rng=random.Random(902026+restart)
 counts=collections.Counter(); used_rows=set(); allrows=[]
 try:
  correctness=[1,2,3,4]*5
  rng.shuffle(correctness)
  omissions=(GROUPS*4)[:20]; rng.shuffle(omissions)
  for ti,target in enumerate(INPUT['targets']):
   groups=[g for g in GROUPS if g!=omissions[ti]];rng.shuffle(groups)
   good_positions=set(rng.sample(range(5),correctness[ti]))
   used_lemmas=set(); rows=[]
   for ri,g in enumerate(groups):
    candidates=[]
    letters=sorted({i['letter'] for i in BYGROUP[g]})
    for _ in range(600):
     major=rng.choice(letters);minor=rng.choice([a for a in letters if a!=major])
     need=[major]*3 if ri in good_positions else [major,major,minor]
     rng.shuffle(need)
     row=[];lemmas=set(used_lemmas);roots=set()
     for a in need:
      available=[i for i in BYGROUP[g] if i['letter']==a and counts[i['word']]<4 and i['lemma'] not in lemmas and i['root_family'] not in roots]
      if not available: break
      lowest=min(counts[i['word']] for i in available)
      available=[i for i in available if counts[i['word']]<=lowest+int(rng.random()<.08)]
      i=rng.choice(available);row.append(i);lemmas.add(i['lemma']);roots.add(i['root_family'])
     if len(row)!=3:continue
     tok=row_words(row)
     if tok in OLD_WORDS or row_token(row) in OLD_TEMPLATES or tok in used_rows:continue
     candidates.append((sum(counts[i['word']] for i in row),rng.random(),row))
    if not candidates:raise RuntimeError('capacity')
    row=min(candidates,key=lambda v:v[:2])[2]
    rows.append(row);used_rows.add(row_words(row));used_lemmas.update(i['lemma'] for i in row)
    counts.update(i['word'] for i in row)
   allrows.append(rows)
  break
 except RuntimeError:continue
else:raise RuntimeError('generation failed')
TASKS=[];PASSPORTS=[];CHECKS=[]
for target,rows in zip(INPUT['targets'],allrows):
 key=''.join(str(n) for n,row in enumerate(rows,1) if len({i['letter'] for i in row})==1)
 exps=[]; drills=[];passrows=[]
 for n,row in enumerate(rows,1):
  letters=' / '.join(i['letter'].upper() for i in row)
  exps.append(f"{n}) "+', '.join(i['template'].replace('..',i['letter']) for i in row)+f" — {letters}. "+' '.join(i['word']+': '+i['rule'] for i in row))
  drills.append([[*i['template'].split('..')[:1],i['letter'],i['template'].split('..')[1]] for i in row])
  passrows.append({'group':row[0]['group'],'topic':row[0]['topic'],'contrast':['а','о'] if row[0]['group'].endswith('AO') else ['е','и'],'items':row,'purpose':'Верный ряд: одна буква во всех трёх позициях.' if len(set(i['letter'] for i in row))==1 else 'Неверный ряд: две одинаковые буквы и одна отличающаяся в одной правиловой группе.','is_correct':str(n) in key})
 t={'id':target['id'],'line':9,'topic':'Правописание корней','subtopics':['проверяемые гласные','непроверяемые гласные','чередующиеся гласные'],
  'year':2027,'base_year':2026,'status':'draft','source':'authored:rule-blueprints-r80-02','stem':target['stem'],
  'opts':[', '.join(i['template'] for i in row) for row in rows],'key':[key],'exp':'\n\n'.join(exps)+f'\n\nОтвет: {key}.',
  'drill':{'kind':'letters','hint':'Вставьте пропущенные буквы. Каждая позиция проверяется отдельно.','rows':drills},
  'words':[i['word'] for row in rows for i in row],'answer_type':'digits','match':'unordered','max_score':1,'needs_source':True,'allowed_2027':None,
  'reviewer_id':None,'reviewed_at':None,'source_refs':[s['id'] for s in SOURCES],
  'norm_basis':{'claim':'Авторские основания по каждому пропуску приведены в паспорте; методическая приёмка ожидается.','rule_source':['R2-09-ROOT34','R2-09-AO','R2-09-EI','R2-09-ROS','R2-09-ROS-ONLINE'],'type_source':'R2-09-FORMAT','confirmed':False},
  'selection_blueprint':'r80-02:'+target['id'],'method_work_state':'draft_pending_review'}
 TASKS.append(t)
 PASSPORTS.append({'id':'r80-02:'+t['id'],'task_id':t['id'],'line':9,'rows':passrows,'review_status':'pending'})
 CHECKS.append({'task_id':t['id'],'author_resolved_again':True,'computed_key':key,'correct_rows_count':len(key),'structure':'5 рядов по 3 слова; все пропуски — гласные корня.','row_coherence':True,'wrong_rows_2_plus_1':True,'distinct_lemmas_within_task':True,'new_rows_vs_r80_01_and_input_bank':True,
 'alternative_reconstruction_review':{'performed':True,'method':'Повторное решение по значению, правилу и контексту; просмотр другой гласной а/о/е/и/я/у/ы/э/ю/ё; грамматические альтернативы форм на -еру устранены контекстом.',
 'controlled_cases':['касаться вопроса ≠ кусаться','замирать от восторга ≠ замарать','прилагать усилия ≠ прилегать','полагать, что решение верно ≠ полегать','(я) соберу коллекцию ≠ собору','(я) выберу платье ≠ выбору','(я) удеру от погони ≠ удару','кампания избирательная ≠ компания друзей','осветить комнату лампой ≠ освятить','примерять платье ≠ примирять друзей']},
 'norm_review':'Правила сверены по первичным академическим §34–35, ОРОСС §24 и §27; словарные локаторы указаны у каждой леммы. Старые dictionary_check не использованы как доказательство.','inventory_audit_followup':'Прочитан work/r80-02/reviews/inventory-09-10.json; все 11 находок линии 9 закрыты видимым контекстом (индексы 0,10,11,44,56,57,60,75,83,95,142). Слово параграф имеет ударение пара́граф; п..раграф — безударная первая А, сохранено как словарное.', 'independent_acceptance':False,'limitations':'Авторский повторный проход не является независимой методической приёмкой; статус draft сохранён.'})
# Independent structural recomputation from the deliverable's actual drill values.
assert len(TASKS)==len(PASSPORTS)==len(CHECKS)==20
assert [t['id'] for t in TASKS]==[t['id'] for t in INPUT['targets']]
seen=collections.Counter()
for t,p in zip(TASKS,PASSPORTS):
 assert len(t['opts'])==len(t['drill']['rows'])==len(p['rows'])==5
 result=''
 lemmas=[]
 for j,(dr,pr,opt) in enumerate(zip(t['drill']['rows'],p['rows'],t['opts']),1):
  assert len(dr)==len(pr['items'])==3
  assert opt==', '.join(i['template'] for i in pr['items'])
  letters=[cell[1] for cell in dr]
  assert all(a in 'аеёиоуыэюя' and len(a)==1 for a in letters)
  assert len(set(letters))==1 or sorted(collections.Counter(letters).values())==[1,2]
  assert len({i['group'] for i in pr['items']})==1
  for cell,i in zip(dr,pr['items']):
   assert cell[0]+'..'+cell[2]==i['template']
   assert ''.join(cell)==i['template'].replace('..',i['letter'])
   assert i['word'] in ''.join(cell)
   assert len(i['template'].split('..'))==2
   lemmas.append(i['lemma']);seen[i['word']]+=1
  if len(set(letters))==1:result+=str(j)
 assert t['key']==[result] and 1<=len(result)<=4
 assert len(lemmas)==len(set(lemmas))==15
 assert t['words']==[i['word'] for r in p['rows'] for i in r['items']]
 assert all(t[k]==v for k,v in {'status':'draft','needs_source':True,'allowed_2027':None}.items())
 assert t['norm_basis']['confirmed'] is False
assert max(seen.values())<=4
assert set(len(t['key'][0]) for t in TASKS)=={1,2,3,4}
used=[dict(i,uses=seen[i['word']]) for i in POOL if seen[i['word']]]
OUT={'tasks':TASKS,'passports':PASSPORTS,'sources':SOURCES,'author_checks':CHECKS,'inventory_used':used}
path=BASE/'authors/line-09.json'
path.write_text(json.dumps(OUT,ensure_ascii=False,indent=2)+'\n')
print('tasks',len(TASKS),'rows',100,'gaps',300,'forms',len(seen),'max_repeat',max(seen.values()),'key_counts',dict(collections.Counter(len(t['key'][0]) for t in TASKS)))
print('SHA256',hashlib.sha256(path.read_bytes()).hexdigest())
for t in TASKS:print(t['id'],t['key'][0])
