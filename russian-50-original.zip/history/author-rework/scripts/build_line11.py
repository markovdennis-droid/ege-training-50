#!/usr/bin/env python3
"""R80-02, line 11: reproducible authoring and structural self-checks."""
import collections
import copy
import hashlib
import itertools
import json
import random
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT/'input/line-11.json').read_text())
rng = random.Random(80211027)

def plain(s):
    return re.sub(r'\s*\([^)]*\)', '', s).strip().lower()

sources = [
    dict(id='R802-11-ADJ', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=34', locator='§46: -ев-, -ив-, -лив-, -чив-; различение относительных и качественных прилагательных.', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-NOUN', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=34', locator='§50: -ек/-ик; беглый и небеглый гласный при склонении.', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-INKA', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=34', locator='§51: -инка/-енка; образования от -ина, беглая гласная основы на -ня и суффикс названий лиц женского пола.', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-VERB', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orf.php?paragraph=pp61.php', locator='§61: -ыва-/-ова-; сопоставление с 1-м лицом единственного числа.', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-ADV', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=34', locator='§42: суффиксы наречий -о (в том числе в-, за-, на-) и -а (до-, из-, с-).', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-JOBS', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=43', locator='§42 (суффикс -щик-), §§86,88: -чик- после т, д, с, з, ж; §86 также оговаривает особые основы на -нт, -льт, -рт, -йт и т. п. Примеры выбранной партии к исключениям не относятся.', additional_url='https://www.orthographia.ru/orfografia.php?sid=34', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-KSK', title='Полный академический справочник под ред. В. В. Лопатина', url='https://www.orthographia.ru/orfografia.php?sid=43', locator='§85: сочетание цк (поглощение с суффикса -ск-) и сохранение дс; §89: зс; §90: жс; §95: сс на стыке основы и суффикса (матросский). Школьное сопоставление -к-/-ск-; без переноса этого упрощения на академическое морфемное описание.', role='norm', checked_at='2026-11-12'),
    dict(id='R802-11-FORMAT', title='ФИПИ: проект демоверсии ЕГЭ 2027 по русскому языку', url='https://fipi.ru/ege/demoversii-specifikacii-kodifikatory', local_source='work/b80g/authors/lex-work/fipi/РУ-11 ЕГЭ 2027 ДЕМО.txt', locator='Задание 11: два слова в каждом из пяти рядов; требуется одинаковая пропущенная буква.', role='format_only'),
]
refs = dict(adj_EI='R802-11-ADJ', noun_EI='R802-11-NOUN', inka='R802-11-INKA', verb_OY='R802-11-VERB', adv_AO='R802-11-ADV', jobs='R802-11-JOBS', k_sk='R802-11-KSK')
contrasts = dict(adj_EI=['е','и'], noun_EI=['е','и'], inka=['е','и'], verb_OY=['о','ы'], adv_AO=['а','о'], jobs=['ч','щ'], k_sk=['к','с'])
group_rules = {
 'adj_EI':'Различаются относительные прилагательные с -ев- и качественные с -ив-, -лив-, -чив-; нельзя считать любую последовательность ЛИВ суффиксом -лив-.',
 'noun_EI':'Выбор -ек-/-ик- определяется выпадением либо сохранением гласного при склонении.',
 'inka':'Сопоставляются образования на -инка/-енка: сохраняется -ин- исходного слова на -ина либо пишется Е (беглая гласная основы или суффикс лица женского пола).',
 'verb_OY':'Сопоставление -ова-/-ыва- по форме 1-го лица: -ую или сохраняющееся -ываю.',
 'adv_AO':'Для выбранных наречий, образованных приставочно-суффиксально от прилагательных, сопоставляются -а с из-/до-/с- и -о с в-/на-/за-.',
 'jobs':'Сопоставляются суффиксы существительных со значением лица -чик-/-щик-; проверяется конечный согласный производящей основы.',
 'k_sk':'Сопоставляются написания цк и ск в производных прилагательных; проверяется производящая основа и сохранение/поглощение С суффикса.'
}

inventory=[]
for index, original in enumerate(data['inventory']):
    if index in (9, 24, 46):  # Omit rare historical item, лучик/лучок, disputed segmentation of беженка.
        continue
    x=copy.deepcopy(original)
    x.pop('dictionary_check',None)
    x['inventory_index']=index
    x['word']=plain(x['word'])
    x['lemma']=x['lexeme']=x['word']
    g=x['group']; w=x['word']; letter=x['letter']
    x['source_refs']=[refs[g]]
    x['source_locator']={'adj_EI':'§46','noun_EI':'§50','inka':'§51','verb_OY':'§61','adv_AO':'§42','jobs':'§42, суффикс -щик-','k_sk':'§85'}[g]
    x['context_required']=False
    x['alternative_analysis']='Иной нормативной современной леммы при замене одной буквы в данном контексте не установлено.'
    if g=='adj_EI':
        if letter=='е':
            x['morpheme']='-ев-'
            x['rule']=f'{w}: относительное прилагательное, суффикс -ев-; пишется Е. Л/Н/Ш/Ц перед этим суффиксом не включаются в суффиксы -лив-/-чив-.'
        elif w=='милостивый':
            x['morpheme']='-ив-'
            x['rule']='Милостивый: качественное прилагательное с суффиксом -ив-, безударная И сохраняется; школьное исключение из упрощённого правила об ударении.'
        else:
            x['morpheme']='-чив-' if 'чивый' in w else '-лив-'
            x['rule']=f'{w}: в суффиксе {x["morpheme"]} пишется И независимо от ударения.'
    elif g=='noun_EI':
        x['morpheme']='-ек-' if letter=='е' else '-ик-'
        if w=='калачик':
            x['morpheme']='-ик-'
            x['rule']='Калач → калачик — калачика: Ч относится к основе калач-, И суффикса -ик- сохраняется при склонении.'
        if w=='столик':
            x['template']='стол..к (предмет мебели)'
            x['context_required']=True
            x['alternative_analysis']='Столок — нормативная форма прошедшего времени глагола столочь. Контекст предмета мебели исключает глагол.'
        x['dependent_condition']='Родительный падеж единственного числа, приведённый в правиле; пропуск находится перед конечной К.'
    elif g=='inka':
        if letter=='и':
            base={'соломинка':'соломина','горошинка':'горошина','жемчужинка':'жемчужина','изюминка':'изюмина','впадинка':'впадина','проталинка':'проталина'}[w]
            x['morpheme']='-ин- исходной основы перед уменьшительным -к-'
            x['rule']=f'{base} → {w}: при добавлении уменьшительного -к- сохраняется И суффикса -ин- производящей основы; не следует ошибочно выделять новый суффикс -енк-.'
        elif w in ('вишенка','песенка'):
            base,gen={'вишенка':('вишня','вишен'),'песенка':('песня','песен')}[w]
            x['morpheme']='беглая Е производящей основы перед -к-'
            x['rule']=f'{base} ({gen}) → {w}: Е — беглая гласная основы перед уменьшительным -к-, а не суффикс -инк-. Написание установлено §51.'
        elif w=='лесенка':
            x['morpheme']='Е в основе перед уменьшительным -к-'
            x['rule']='Лесенка: в §51 это слово специально отнесено к написаниям на -енка; пишется Е. Нельзя выводить И из несуществующей производящей формы на -ина.'
        else:
            x['morpheme']='-енк-'
            x['rule']=f'{w}: суффикс -енк- названия лица женского пола; перед Н без ударения пишется Е. Производящего существительного на -ина здесь нет.'
    elif g=='verb_OY':
        x['morpheme']='-ова-' if letter=='о' else '-ыва-'
        x['dependent_condition']='Форма 1-го лица единственного числа дана в правиле; для совершенного обрадовать это простое будущее, для остальных настоящее.'
        if w=='обрадовать':
            x['rule']='Обрадовать — обрадую (простое будущее, 1-е лицо ед. ч.): сочетание -ова- не сохраняется, пишется О в -ова-.'
        if w=='пробовать':
            x['template']='проб..вать (блюдо на вкус)'
            x['context_required']=True
            x['alternative_analysis']='Пробивать — иная нормативная лемма; контекст блюда на вкус исключает её.'
    elif g=='adv_AO':
        x['morpheme']='-'+letter
        bases={'издавна':'давний','досуха':'сухой','снова':'новый','справа':'правый','слева':'левый','дочиста':'чистый','изредка':'редкий','докрасна':'красный','сначала':'начало','вправо':'правый','влево':'левый','начисто':'чистый','засветло':'светлый','запросто':'простой','наглухо':'глухой','затемно':'тёмный','надолго':'долгий','заново':'новый'}
        # Сначала is derived from a noun: avoid imposing the adjective formation rule.
        if w=='сначала':
            continue
        pref=next(p for p in (['из','до','с'] if letter=='а' else ['в','на','за']) if w.startswith(p))
        x['rule']=f'{w}: наречие, образованное от «{bases[w]}» с приставкой {pref}- и суффиксом -{letter}; пишется {letter.upper()} (§42).'
        x['dependent_condition']='Проверяется именно приставочно-суффиксальное образование от указанного прилагательного; правило не распространяется на все наречия с тем же началом.'
        if w=='вправо':
            x['context_required']=True
            x['alternative_analysis']='Вправе — иная нормативная лемма («имеет право»); контекст направления исключает её.'
    elif g=='jobs':
        x['morpheme']='-чик-' if letter=='ч' else '-щик-'
        end=plain(x['template']).split('..')[0][-1]
        if letter=='ч':x['source_locator']='§86' if end in 'тд' else '§88'
        x['rule']=f'{w}: название лица; после {end.upper()} в производящей основе пишется {x["morpheme"]}, вставляется {letter.upper()}.'
        contexts={'заказчик':'клиент ателье','сборщик':'рабочий на сборке приборов','наборщик':'работник типографии','барабанщик':'музыкант в оркестре','каменщик':'строитель кирпичных стен'}
        if w in contexts:
            x['template']=plain(x['template'])+' ('+contexts[w]+')'
            x['context_required']=True
        if w=='заказчик':x['alternative_analysis']='Заказник — иная лемма (охраняемая территория); контекст «клиент ателье» исключает её.'
        if w=='сборщик':x['alternative_analysis']='Сборник — иная лемма (собрание текстов и т. п.); контекст рабочего исключает её.'
        if w=='наборщик':x['alternative_analysis']='Наборчик — уменьшительное от набор; контекст работника типографии исключает его.'
        if w=='барабанщик':x['alternative_analysis']='Барабанчик — уменьшительное название инструмента; контекст музыканта исключает его.'
    elif g=='k_sk':
        x['morpheme']='цк на стыке основы и суффикса' if letter=='к' else '-ск-'
        bases={'немецкий':'немец','ткацкий':'ткач','рыбацкий':'рыбак','казацкий':'казак','турецкий':'турок','бедняцкий':'бедняк','моряцкий':'моряк','бурлацкий':'бурлак','матросский':'матрос','французский':'француз','кавказский':'Кавказ','соседский':'сосед','городской':'город','заводской':'завод','парижский':'Париж','калужский':'Калуга'}
        if letter=='к':
            x['rule']=f'{bases[w]} → {w}: на письме ЦК; С суффикса поглощена предшествующим Ц (при необходимости с чередованием конечного согласного основы). Вставляется К; школьное название — суффикс -к-.'
        else:
            x['source_locator']='§95' if w=='матросский' else ('§89' if w in ('французский','кавказский') else ('§90' if w in ('парижский','калужский') else '§85'))
            x['rule']=f'{bases[w]} → {w}: сохраняется С суффикса -ск- после согласного основы; вставляется С.'
    a,b=x['template'].split('..')
    assert plain(a+x['letter']+b)==x['word'],x
    inventory.append(x)

# Check row identity after stripping context and independently by restored forms.
old_templates=set(); old_words=set()
for task in data['existing_tasks']:
    for opt in task.get('opts',[]):
        bits=opt.split(', ')
        if len(bits)==2: old_templates.add(tuple(sorted(plain(s) for s in bits)))
    for row in task.get('drill',{}).get('rows',[]):
        if len(row)==2: old_words.add(tuple(sorted(plain(''.join(z)) for z in row)))
for passport in data['current_passports']:
    for row in passport['rows']:
        old_templates.add(tuple(sorted(plain(x['template']) for x in row['items'])))
        old_words.add(tuple(sorted(plain(x['word']) for x in row['items'])))

groups=list(refs)
pool={g:[x for x in inventory if x['group']==g] for g in groups}
combinations=list(itertools.combinations(groups,5))
rng.shuffle(combinations)
combinations=combinations[:20]
desired=[1,2,3,4]*5
rng.shuffle(desired)
counts=collections.Counter(); used_rows=set(); tasks=[]; passports=[]; checks=[]
for ti,(target,gs,ntrue) in enumerate(zip(data['targets'],combinations,desired)):
    gs=list(gs);rng.shuffle(gs)
    true_positions=set(rng.sample(range(5),ntrue))
    rows=[]
    for ri,g in enumerate(gs):
        candidates=[]
        for a,b in itertools.combinations(pool[g],2):
            pair=tuple(sorted([a['word'],b['word']]))
            template_pair=tuple(sorted([plain(a['template']),plain(b['template'])]))
            if pair in used_rows or pair in old_words or template_pair in old_templates:continue
            if (a['letter']==b['letter'])!=(ri in true_positions):continue
            if max(counts[a['word']],counts[b['word']])>=4:continue
            score=(max(counts[a['word']],counts[b['word']]),counts[a['word']]+counts[b['word']],rng.random())
            candidates.append((score,a,b))
        assert candidates,(ti,ri,g)
        _,a,b=min(candidates,key=lambda x:x[0]); items=copy.deepcopy([a,b]);rng.shuffle(items)
        used_rows.add(tuple(sorted([a['word'],b['word']])))
        counts.update(x['word'] for x in items)
        rows.append(dict(group=g,topic=items[0]['topic'],contrast=contrasts[g],row_rule=group_rules[g],items=items,purpose='Совпадение букв после применения общего правила.' if ri in true_positions else 'Различие букв внутри одной диагностической группы.'))
    key=''.join(str(i+1) for i,r in enumerate(rows) if len({x['letter'] for x in r['items']})==1)
    tid=target['id']; exp=[]; drill=[]
    for i,r in enumerate(rows,1):
        its=r['items']
        exp.append(f'{i}) '+', '.join(x['word'] for x in its)+' — '+' / '.join(x['letter'].upper() for x in its)+'. '+r['row_rule']+' '+' '.join(x['rule'] for x in its))
        drill.append([[*x['template'].split('..')[:1],x['letter'],x['template'].split('..')[1]] for x in its])
    task=dict(id=tid,line=11,year=2027,base_year=2026,status='draft',source='authored:rule-blueprints-r80-02',stem=target['stem'],topic='Правописание суффиксов (кроме -Н-/-НН-)',subtopics=[r['topic'] for r in rows],opts=[', '.join(x['template'] for x in r['items']) for r in rows],key=[key],exp='\n\n'.join(exp)+f'\n\nОтвет: {key}.',drill=dict(kind='letters',hint='Вставьте пропущенные буквы. Каждая позиция проверяется отдельно.',rows=drill),words=[x['word'] for r in rows for x in r['items']],answer_type='digits',match='unordered',max_score=1,needs_source=True,allowed_2027=None,reviewer_id=None,reviewed_at=None,source_refs=['R802-11-FORMAT']+[refs[r['group']] for r in rows],norm_basis=dict(claim='Норма обоснована правилом и точным локатором в паспорте. Авторский повторный проход выполнен; независимая приёмка не проведена.',rule_source=[refs[r['group']] for r in rows],type_source='R802-11-FORMAT',confirmed=False),selection_blueprint='r80-02:'+tid,method_work_state='draft_pending_review')
    tasks.append(task)
    passports.append(dict(id='r80-02:'+tid,task_id=tid,line=11,rows=rows,review_status='pending',author_recheck='Второй авторский проход: морфемная граница, зависимые условия, альтернативная лемма и восстановление одной буквы; это не независимая приёмка.'))
    checks.append(dict(task_id=tid,structural_status='passed',author_norm_status='self_checked',independent_acceptance=False,key_recomputed=key,row_groups_homogeneous=True,single_letter_restoration=True,within_task_word_repetition=False,old_row_overlap=False,alternative_reconstruction_checked=True,morpheme_boundary_checked=True,dependent_conditions_checked=True,context_checks=[dict(word=x['word'],template=x['template'],finding=x['alternative_analysis']) for r in rows for x in r['items'] if x['context_required']]))

assert len(tasks)==len(passports)==len(checks)==20
assert {t['id'] for t in tasks}=={t['id'] for t in data['targets']}
assert len(used_rows)==100
assert max(counts.values())<=4
assert set(len(t['key'][0]) for t in tasks)=={1,2,3,4}
for t,p in zip(tasks,passports):
    assert len(t['opts'])==len(t['drill']['rows'])==len(p['rows'])==5
    assert len(t['words'])==len(set(t['words']))==10
    for opt,dr,row in zip(t['opts'],t['drill']['rows'],p['rows']):
        assert len(row['items'])==len(dr)==2
        assert len({x['group'] for x in row['items']})==1
        assert opt==', '.join(x['template'] for x in row['items'])
        for triple,x in zip(dr,row['items']):
            assert len(triple)==3 and len(triple[1])==1
            assert triple[0]+'..'+triple[2]==x['template']
            assert plain(''.join(triple))==x['word']
            assert x['rule'] in t['exp']
out=dict(tasks=tasks,passports=passports,sources=sources,author_checks=checks,inventory_used=[dict(x,count=counts[x['word']]) for x in inventory if counts[x['word']]])
path=ROOT/'authors/line-11.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(tasks=len(tasks),rows=len(used_rows),forms=len(counts),max_frequency=max(counts.values()),key_lengths=dict(collections.Counter(len(t['key'][0]) for t in tasks)),groups=dict(collections.Counter(r['group'] for p in passports for r in p['rows'])),sha256=hashlib.sha256(path.read_bytes()).hexdigest()),ensure_ascii=False))
