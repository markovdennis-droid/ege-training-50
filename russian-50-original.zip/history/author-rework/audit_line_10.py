import json,re,unicodedata,collections
from pathlib import Path
p=json.load(open('work/r80-02/authors/line-10.json'))
def norm(s):return ''.join(c for c in unicodedata.normalize('NFC',s) if c!='\u0301' and unicodedata.category(c)!='Co').lower()
lex=set()
for f in ['dict1.txt','dict2.txt']:
 lex.update(re.findall('[а-я]+',norm(Path('work/b80g/authors/lex-work',f).read_text())))
checks=[]
for x in p['inventory_used']:
 a,b=x['template'].split('..'); b=b.split(' (')[0]
 alts=[]
 for letter in 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя':
  cand=a+letter+b
  if cand!=x['word'] and norm(cand) in lex:alts.append(cand)
 checks.append({'word':x['word'],'template':x['template'],'dictionary_token_alternatives':alts})
Path('work/r80-02/authors/line-10-alternatives.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
for x in checks:
 if x['dictionary_token_alternatives']: print(x)
