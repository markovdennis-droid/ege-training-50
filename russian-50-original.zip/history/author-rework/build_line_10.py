import json,random,re,collections,copy,unicodedata,hashlib
from pathlib import Path
ROOT=Path('work/r80-02')
src=json.loads((ROOT/'input/line-10.json').read_text())
inv=copy.deepcopy(src['inventory'])
source_for={'pre_pri':'R80-02-PREFIX-PREPRI','zs':'R80-02-PREFIX-ZS','yi':'R80-02-PREFIX-IY','sign':'R80-02-PREFIX-SIGN','td':'R80-02-PREFIX-TD'}
loc_for={'pre_pri':'§39, включая примечания 1–2','zs':'§82','yi':'§11 п.4; §12 п.2; для меж- также §14','sign':'§27–28','td':'§79, абзац «Согласные в приставках»'}
context={
6:'пр..образовать (систему управления, коренным образом изменить)',
8:'пр..рвать (лекцию звонком)',
9:'пр..ступить (закон, нарушить его)',
10:'пр..творить (мечту в жизнь)',
12:'пр..дать (сведения огласке)',
13:'пр..емник (продолжатель дела)',
19:'пр..клеить (марку к конверту)',
24:'пр..ступить (к выполнению работы)',
25:'пр..творить (дверь, неплотно закрыть)',
27:'пр..дать (шару нужную форму)',
28:'пр..ёмник (радиоаппарат)',
92:'ин..екция (лекарства шприцем)',
102:'бар..ер (препятствие)',
117:'о..бросить (ненужные сомнения)',
118:'о..дать (книгу владельцу)',
119:'о..ступить (от прежнего решения)',
120:'о..крыть (дверь ключом)',
121:'о..пустить (пленного на свободу)',
122:'о..гадать (загадку)',
123:'о..считать (десять секунд до старта)',
124:'о..делить (желток от белка)',
125:'о..тянуть (заседание на час)',
126:'о..править (посылку адресату)'
}
excluded={11,26,81} # пребыть/пробыть: избегаем омонимичного шаблона; взимать: исключение вне основной пары.
# Отгадать/обгадать: второй глагол сочетается и с «загадкой» в переносном смысле; исключаем.
excluded.add(122)
for i,x in enumerate(inv):
 x.pop('dictionary_check',None); x.pop('normative_check',None)
 x['inventory_index']=i
 x['word']=x['word'].split(' (')[0]
 x['lexeme']=x['lemma']
 if i in context: x['template']=context[i]
 if x['word']=='изъян': x['rule']='Традиционное написание с Ъ; из- в современном слове не является приставкой (§27, примечание).'
 if x['group']=='pre_pri':
  if i==9: x['rule']='Преступить закон — нарушить его; это не приступить к чему-либо. Пишется Е.'
  if i==10: x['rule']='Претворить мечту в жизнь — осуществить её; в сочетании пишется Е.'
  if i==12: x['rule']='Предать сведения огласке — сделать их общеизвестными; пишется Е.'
  if i==13: x['rule']='Преемник — продолжатель дела; закреплённое написание Е, в отличие от приёмник.'
  if i==24: x['rule']='Приступить к выполнению работы — начать её; пишется И.'
  if i==25: x['rule']='Притворить дверь — неплотно закрыть её; пишется И.'
  if i==27: x['rule']='Придать шару нужную форму — наделить его определённой формой; пишется И.'
  if i==28: x['rule']='Приёмник — принимающий радиосигналы аппарат; закреплённое написание И.'
 if x['group']=='sign' and x['letter']=='ь':
  x['rule']='Разделительный Ь внутри слова перед йотированной гласной; стыка приставки на согласный с основой здесь нет (§28).'
  if i in [104,105,106]: x['rule']='В заимствованном слове перед О традиционно пишется разделительный Ь (§28, примечание).'
 if i in [91,92,93,94]: x['rule']='Традиционный Ъ в заимствованном слове с начальной частью, соответствующей приставке языка-источника (§27 п.1б).'
 if x['group']=='yi' and x['letter']=='и':
  if i in [71,72]: x['rule']='После русской приставки сверх- сохраняется начальное И основы (§11 п.4б).'
  elif i in [73,74]: x['rule']='После меж- сохраняется начальное И основы (§11 п.4б, примечание 1; §14).'
  else: x['rule']='После иноязычной приставки или начального элемента пан- сохраняется И (§11 п.4а).'
 x['source_refs']=[source_for[x['group']],'DICT25']
 x['source_locators']={source_for[x['group']]:loc_for[x['group']],'DICT25':'Словарная статья «'+x['lemma']+'»; источник написания, не источник формата.'}
 x['normative_review']='author_rule_check; independent_review_pending'
 # Single missing letter and context-independent reconstructed form.
 a,b=x['template'].split('..'); assert (a+x['letter']+b).split(' (')[0]==x['word'],x

# Detect row reuse by word sets, so changes in order/context cannot mask duplicates.
def row_sig(words): return tuple(sorted(w.split(' (')[0].lower().replace('ё','е') for w in words))
old=set()
for t in src['existing_tasks']:
 if t.get('drill',{}).get('rows'):
  for rr in t['drill']['rows']: old.add(row_sig([''.join(z) for z in rr]))
 else:
  for opt in t.get('opts',[]): old.add(tuple(sorted(z.strip() for z in opt.split(', '))))
for p in src['current_passports']:
 for rr in p['rows']: old.add(row_sig([z['word'] for z in rr['items']]))
keys=['1','24','135','1234','5','13','245','2345','3','15','124','1345','2','35','123','1245','4','25','345','1235']
groups=['pre_pri','zs','yi','sign','td']; contrasts={'pre_pri':['е','и'],'zs':['з','с'],'yi':['ы','и'],'sign':['ъ','ь'],'td':['д','т']}
rng=random.Random(1002027)
usage=collections.Counter(); new=set(); tasks=[]; passports=[]
for ti,(target,key) in enumerate(zip(src['targets'],keys)):
 order=groups[:]; rng.shuffle(order); rows=[]
 for ri,g in enumerate(order,1):
  correct=str(ri) in key
  for attempt in range(20000):
   main=rng.choice(contrasts[g]); other=next(z for z in contrasts[g] if z!=main)
   letters=[main]*3 if correct else [main,main,other]
   rng.shuffle(letters)
   chosen=[]
   for letter in letters:
    candidates=[j for j,x in enumerate(inv) if j not in excluded and x['group']==g and x['letter']==letter and usage[x['word']]<4 and j not in chosen]
    if not candidates: break
    # smallest usage first; random tie break provides distinct pedagogical combinations.
    m=min(usage[inv[j]['word']] for j in candidates)
    j=rng.choice([j for j in candidates if usage[inv[j]['word']]==m]); chosen.append(j)
   if len(chosen)!=3: continue
   sig=row_sig([inv[j]['word'] for j in chosen])
   if sig in old or sig in new: continue
   break
  else: raise RuntimeError((ti,g,dict(usage)))
  items=[copy.deepcopy(inv[j]) for j in chosen]
  for x in items: usage[x['word']]+=1
  new.add(sig)
  rows.append({'group':g,'topic':items[0]['topic'],'contrast':contrasts[g],'gap_class': 'vowel' if g in ['pre_pri','yi'] else 'separator' if g=='sign' else 'consonant','items':items,'purpose':'Совпадение трёх букв.' if correct else 'Контраст 2+1 внутри одной группы правил.'})
 key_calc=''.join(str(i+1) for i,r in enumerate(rows) if len({x['letter'] for x in r['items']})==1)
 assert key_calc==key
 opts=[', '.join(x['template'] for x in r['items']) for r in rows]
 drill=[[[*x['template'].split('..')[:1],x['letter'],x['template'].split('..')[1]] for x in r['items']] for r in rows]
 ex=[]
 for ri,r in enumerate(rows,1):
  letters=', '.join(x['letter'].upper() for x in r['items'])
  details='; '.join(x['word']+' — '+x['rule'] for x in r['items'])
  ex.append(f'{ri}) {letters}. '+('Верный ряд. ' if str(ri) in key else 'Неверный ряд. ')+details)
 task={'id':target['id'],'line':10,'topic':'Правописание приставок и разделительных знаков','subtopics':groups,'year':2027,'base_year':2026,'status':'draft','source':'author:r80-02:line-10','stem':target['stem'],'opts':opts,'key':[key_calc],'exp':'Ответ: '+key_calc+'.\n'+'\n'.join(ex),'drill':{'kind':'letters','hint':'Вставьте в каждую позицию одну букву.','rows':drill},'words':[x['word'] for r in rows for x in r['items']],'answer_type':'digits','match':'unordered','max_score':1,'needs_source':True,'allowed_2027':None,'reviewer_id':None,'reviewed_at':None,'source_refs':list(source_for.values())+['DICT25','FIPI27'],'norm_basis':{'claim':'Авторская сверка правил выполнена; независимая методическая и словарная приёмка не завершена.','rule_source':list(source_for.values()),'type_source':'FIPI27','confirmed':False},'selection_blueprint':{'group_quota':'Внутреннее решение этой партии: по одному ряду пяти групп; не квота ФИПИ.','correct_rows':len(key)}}
 tasks.append(task); passports.append({'id':'r80-02:'+task['id'],'task_id':task['id'],'line':10,'rows':rows,'review_status':'pending'})

sources=[]
for g,ref in source_for.items():
 sid={'pre_pri':33,'zs':43,'yi':13,'sign':24,'td':43}[g]
 sources.append({'id':ref,'title':'Полный академический справочник под редакцией В. В. Лопатина','url':f'https://www.orthographia.ru/orfografia.php?sid={sid}','locator':loc_for[g],'role':'Нормативное правило; проверено автором 2026-11-12.'})
base_sources=json.loads(Path('work/recovered-r80/source/sources.json').read_text())
for ref in ['DICT25','FIPI27']: sources.append({'id':ref,**base_sources[ref]})
result={'tasks':tasks,'passports':passports,'sources':sources,'author_checks':[],'inventory_used':[x for x in inv if usage[x['word']]]}
out=ROOT/'authors/line-10.json'; out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Wrote',out,'usage max',max(usage.values()),'unique words',len(usage),'rows',len(new),'key distribution',collections.Counter(map(len,keys)))
