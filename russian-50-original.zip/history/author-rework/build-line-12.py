#!/usr/bin/env python3
"""R80-02 line 12: reproducible authoring, structural and alternative-letter checks."""
import json,re,random,itertools,collections,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
x=json.loads((ROOT/'input/line-12.json').read_text())
# Variant paradigms and adjectival/nontransitive examples are deliberately omitted.
EXCLUDE={0,1,2,3,45,59,62,111,129,123,140}
PASS_CTX={39:'актёром текст',40:'учёными материал',41:'ветром тростник',42:'редактором текст',43:'оператором аппарат',44:'коллегами мастер',46:'художником портрет',47:'врачом образец',48:'учеником пример',49:'комиссией вопрос',50:'сторожем объект',51:'диспетчером поезд',52:'лесничим участок',53:'наблюдателем объект',54:'слушателями голос',55:'ветром лист',56:'архивом документ',57:'коллегами опыт',58:'читателями автор',60:'врагами герой',61:'учеником отрезок'}
TOPICS={'personal_EI':('личные окончания Е/И',['е','и']),'plural_UA':('личные окончания У/А',['у','а']),'plural_YUYA':('личные окончания Ю/Я',['ю','я']),'passive_EI':('страдательные причастия настоящего времени -ЕМ-/-ИМ-',['е','и']),'active_UA':('действительные причастия настоящего времени -УЩ-/-АЩ-',['у','а']),'active_YUYA':('действительные причастия настоящего времени -ЮЩ-/-ЯЩ-',['ю','я'])}
I_EXCEPT={'брить'}
II_EXCEPT={'видеть','слышать','дышать','держать','терпеть','вертеть','смотреть','обидеться','зависеть','ненавидеть','гнать','выдержать','вытерпеть'}
CONJ='R802-12-CONJ'; ACTIVE='R802-12-ACTIVE'; PASSIVE='R802-12-PASSIVE'; DICT='DICT25'
items=[]
for idx,raw in enumerate(x['inventory']):
 if idx in EXCLUDE: continue
 i={k:v for k,v in raw.items() if k not in ('dictionary_check','source_refs','rule','word')}
 i['inventory_index']=idx
 i['word']=raw['lexeme']
 i['lexeme']=raw['lexeme']
 if idx in PASS_CTX: i['template']=raw['template']+' '+PASS_CTX[idx]
 i['topic']=TOPICS[i['group']][0]
 c='II' if i['letter'] in ('и','а','я') else 'I'
 i['conjugation']=c
 i['infinitive']=i['lemma']
 if i['lemma'] in I_EXCEPT: reason='Исключение: несмотря на -ить, I спряжение.'
 elif i['lemma'] in II_EXCEPT:
  reason='Исключение II спряжения'+(' (сохраняется в производном глаголе).' if i['lemma'] in {'обидеться','выдержать','вытерпеть'} else '.')
 elif i['lemma'].endswith(('ить','иться')): reason='Глагол на -ить относится ко II спряжению.'
 else: reason='Глагол не входит в исключения II спряжения; I спряжение.'
 i['exception_note']=reason
 if i['group']=='personal_EI':
  ending='-ишь' if c=='II' else '-ешь'
  i['morphology']='2-е лицо, единственное число, изъявительное наклонение'
  rule=f'«{i["word"]}»: инфинитив «{i["lemma"]}», {c} спряжение. {reason} Во 2-м лице единственного числа окончание {ending}'+(' перед -ся.' if i['word'].endswith('ся') else '.')
  refs=[CONJ,DICT]
 elif i['group'].startswith('plural'):
  ending={'у':'-ут','а':'-ат','ю':'-ют','я':'-ят'}[i['letter']]
  i['morphology']='3-е лицо, множественное число, изъявительное наклонение'
  rule=f'«{i["word"]}»: инфинитив «{i["lemma"]}», {c} спряжение. {reason} В 3-м лице множественного числа окончание {ending}'+(' перед -ся.' if i['word'].endswith('ся') else '.')
  refs=[CONJ,DICT]
 else:
  suf={'е':'-ем-','и':'-им-','у':'-ущ-','а':'-ащ-','ю':'-ющ-','я':'-ящ-'}[i['letter']]
  passive=i['group']=='passive_EI'
  i['morphology']=('страдательное' if passive else 'действительное')+' причастие настоящего времени, именительный падеж, мужской род, единственное число'
  rule=f'«{i["word"]}»: образовано от инфинитива «{i["lemma"]}», {c} спряжение. {reason} Суффикс причастия {suf}.'
  refs=[PASSIVE if passive else ACTIVE,CONJ,DICT]
 i['rule']=rule
 i['source_refs']=refs
 i['source_locators']={DICT:f'Словарная статья «{i["lemma"]}»; нормативная парадигма, а не только совпадение строки.',CONJ:'§ 74: распределение безударных личных окончаний и исключения.'}
 if ACTIVE in refs:i['source_locators'][ACTIVE]='§ 58: гласные суффиксов действительных причастий настоящего времени.'
 if PASSIVE in refs:i['source_locators'][PASSIVE]='§ 59: -ем- и -им-; переходность и несовершенный вид учтены в контексте.'
 i['alternative_letter_check']={'contrast_letters':TOPICS[i['group']][1],'accepted':i['letter'],'other_letter_is_normative':False,'note':'Проверены точная словоформа, грамматическая характеристика и контекст; нормативной формы с другой буквой этого контраста нет.'}
 items.append(i)
# Compare actual restored word pairs, ignoring labels, order and added context.
def stripword(s):
 s=re.sub(r'\([^)]*\)','',s).strip()
 return re.findall('[а-яё]+',s.lower())[0] if re.findall('[а-яё]+',s.lower()) else s
oldpairs=set()
for t in x['existing_tasks']:
 if t.get('drill',{}).get('rows'):
  for row in t['drill']['rows']:
   if len(row)==2: oldpairs.add(tuple(sorted(stripword(''.join(a)) for a in row)))
# The recovered tasks without drill carry explicit restored words in the explanation.
# Their templates are also compared, independently of contexts and row order.
def normalize_template(s): return re.sub(r'\([^)]*\)','',s).strip().split()[0].replace('..','')
oldtemplates={tuple(sorted(normalize_template(s) for s in opt.split(','))) for t in x['existing_tasks'] for opt in t.get('opts',[]) if len(opt.split(','))==2}
def template_key(i):return re.sub(r'\([^)]*\)','',i['template']).strip().split()[0].replace('..','')
pools=collections.defaultdict(list)
for i in items:pools[i['group']].append(i)
pairs={}
for g,pool in pools.items():
 for same in (False,True):
  pairs[g,same]=[(a,b) for a,b in itertools.combinations(pool,2) if (a['letter']==b['letter'])==same and a['lemma']!=b['lemma'] and tuple(sorted((a['word'],b['word']))) not in oldpairs and tuple(sorted((template_key(a),template_key(b)))) not in oldtemplates]
# Aim for balanced coverage, exact answer-cardinality quota and all-new pairs.
result=None
for seed in range(20271112,20272112):
 rng=random.Random(seed); freq=collections.Counter(); usedpairs=set(); tasks=[]; passports=[]; checks=[]
 cardinalities=[1,2,3,4]*5; rng.shuffle(cardinalities)
 success=True
 for ti,target in enumerate(x['targets']):
  groups=list(TOPICS); groups.remove(groups[ti%len(groups)]); rng.shuffle(groups)
  valid=set(rng.sample(range(5),cardinalities[ti])); rows=[]; lemmas=set()
  for ri,g in enumerate(groups):
   candidates=[(a,b) for a,b in pairs[g,ri in valid] if a['lemma'] not in lemmas and b['lemma'] not in lemmas and max(freq[a['word']],freq[b['word']])<4 and tuple(sorted((a['word'],b['word']))) not in usedpairs]
   if not candidates: success=False;break
   rng.shuffle(candidates)
   a,b=min(candidates,key=lambda p:(freq[p[0]['word']]+freq[p[1]['word']],max(freq[p[0]['word']],freq[p[1]['word']])) )
   pair=[dict(a),dict(b)];rng.shuffle(pair)
   for i in pair:freq[i['word']]+=1;lemmas.add(i['lemma'])
   usedpairs.add(tuple(sorted((a['word'],b['word']))))
   rows.append({'group':g,'topic':TOPICS[g][0],'contrast':TOPICS[g][1],'items':pair,'purpose':'Верный ряд: одинаковые буквы.' if ri in valid else 'Неверный ряд: различаются буквы одного грамматического контраста.'})
  if not success:break
  key=''.join(str(j+1) for j,row in enumerate(rows) if len({i['letter'] for i in row['items']})==1)
  drill=[]
  for row in rows:
   drill.append([[i['template'].split('..')[0],i['letter'],i['template'].split('..')[1]] for i in row['items']])
  exp='\n\n'.join(f'{ri+1}) '+', '.join(i['template'].replace('..',i['letter']) for i in row['items'])+' — '+' / '.join(i['letter'].upper() for i in row['items'])+'. '+' '.join(i['rule'] for i in row['items']) for ri,row in enumerate(rows))+f'\n\nОтвет: {key}.'
  task={'id':target['id'],'line':12,'topic':'Правописание личных окончаний глаголов и суффиксов причастий','subtopics':[r['topic'] for r in rows],'year':2027,'base_year':2026,'version':None,'status':'draft','source':'authored:rule-blueprints-r80-02','stem':target['stem'],'opts':[', '.join(i['template'] for i in r['items']) for r in rows],'key':[key],'exp':exp,'drill':{'kind':'letters','hint':'Вставьте пропущенные буквы. Каждая позиция проверяется отдельно.','rows':drill},'words':[i['word'] for r in rows for i in r['items']],'answer_type':'digits','match':'unordered','max_score':1,'needs_source':True,'allowed_2027':None,'reviewer_id':None,'reviewed_at':None,'source_refs':['FIPI27',CONJ,ACTIVE,PASSIVE,DICT],'norm_basis':{'claim':'Написания обоснованы правилами и точными грамматическими характеристиками в авторском паспорте; независимая методическая приёмка не проведена.','rule_source':[CONJ,ACTIVE,PASSIVE,DICT],'type_source':'FIPI27: демоверсия 2027, задание 12; только формат.','confirmed':False},'selection_blueprint':'r80-02:'+target['id'],'method_review':{'status':'pending','author_checked_at':'2026-11-12','note':'Авторская повторная проверка нормы и альтернатив; независимой приёмкой не является.'},'method_work_state':'draft_pending_review'}
  tasks.append(task);passports.append({'id':'r80-02:'+target['id'],'task_id':target['id'],'line':12,'rows':rows,'review_status':'pending'})
  checks.append({'task_id':target['id'],'author':'line-12','self_review_only':True,'key_recomputed':key,'correct_row_count':len(key),'same_grammatical_contrast_each_row':True,'two_items_each_row':True,'explicit_person_number':True,'infinitive_absent_from_prompt':True,'distinct_lemmas_in_task':True,'personal_and_participle_same_lemma_absent':True,'single_character_gaps':True,'alternative_letters_reviewed':True,'new_pairs_vs_r80_01':True,'new_pairs_vs_existing_tasks':True,'independent_acceptance_claimed':False})
 if success:result=(tasks,passports,checks,freq,seed);break
assert result,'No feasible construction'
tasks,passports,checks,freq,seed=result
sources=[{'id':CONJ,'title':'Полный академический справочник под ред. В. В. Лопатина. Гласные в глагольных окончаниях','url':'https://orthographia.ru/orf.php?paragraph=pp74.php','locator':'§ 74: безударные личные окончания, I и II спряжения, исключения','role':'языковая норма'}, {'id':ACTIVE,'title':'Полный академический справочник под ред. В. В. Лопатина','url':'https://orthographia.ru/orf.php?paragraph=pp58.php','locator':'§ 58: -ущ-/-ющ- и -ащ-/-ящ-','role':'языковая норма'}, {'id':PASSIVE,'title':'Полный академический справочник под ред. В. В. Лопатина','url':'https://orthographia.ru/orf.php?paragraph=pp59.php','locator':'§ 59: -ем-/-им-','role':'языковая норма'}, {'id':DICT,'title':'Орфографический словарь русского языка как государственного языка РФ, 2025','url':'https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf','locator':'Статьи инфинитивов по lemma; словарная норма не равнозначна методической пригодности.','role':'словарная норма'}, {'id':'FIPI27','title':'ФИПИ. Проект демоверсии ЕГЭ по русскому языку 2027','url':'https://fipi.ru/ege/demoversii-specifikacii-kodifikatory','local_source':'work/b80g/authors/lex-work/fipi/РУ-11 ЕГЭ 2027 ДЕМО.txt','locator':'Задание 12; сверка структуры пяти рядов по два слова.','role':'только формат'}]
used=[dict(i,usage_count=freq[i['word']]) for i in items if freq[i['word']]]
out={'tasks':tasks,'passports':passports,'sources':sources,'author_checks':checks,'inventory_used':used}
# Final consistency checks, independent of generation's intended valid-position flags.
assert len(tasks)==len(passports)==len(checks)==20
assert {t['id'] for t in tasks}=={t['id'] for t in x['targets']}
assert max(freq.values())<=4
assert collections.Counter(len(t['key'][0]) for t in tasks)=={1:5,2:5,3:5,4:5}
for t,p in zip(tasks,passports):
 assert len(t['opts'])==len(p['rows'])==len(t['drill']['rows'])==5
 allitems=[i for r in p['rows'] for i in r['items']]
 assert len({i['lemma'] for i in allitems})==10
 assert t['words']==[i['word'] for i in allitems]
 for n,r in enumerate(p['rows']):
  assert len(r['items'])==2
  assert all(i['group']==r['group'] for i in r['items'])
  assert ', '.join(i['template'] for i in r['items'])==t['opts'][n]
  for i,tr in zip(r['items'],t['drill']['rows'][n]):
   assert i['template'].count('..')==1 and len(i['letter'])==1
   assert tr[0]+'..'+tr[2]==i['template'] and tr[1]==i['letter']
   assert i['word'] in ''.join(tr)
   assert i['lemma'] not in i['template']
   if i['group'].startswith(('personal','plural')):assert i['template'].startswith(('(ты)','(они)'))
  assert tuple(sorted(i['word'] for i in r['items'])) not in oldpairs
  assert tuple(sorted(template_key(i) for i in r['items'])) not in oldtemplates
 assert t['key']==[''.join(str(n+1) for n,r in enumerate(p['rows']) if len({i['letter'] for i in r['items']})==1)]
path=ROOT/'authors/line-12.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'tasks':len(tasks),'seed':seed,'unique_forms':len(freq),'max_form_frequency':max(freq.values()),'correct_row_counts':dict(collections.Counter(len(t['key'][0]) for t in tasks)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))
