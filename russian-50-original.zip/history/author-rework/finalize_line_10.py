import json,collections,re,hashlib
from pathlib import Path
root=Path('work/r80-02'); out=root/'authors/line-10.json'
p=json.loads(out.read_text()); inp=json.loads((root/'input/line-10.json').read_text())
audit=json.loads((root/'authors/line-10-alternatives.json').read_text()); ad={x['word']:x for x in audit}
manual={
'прервать':(['прорвать'],'Звонком прекращают лекцию; прорвать лекцию звонком невозможно.'),
'преступить':(['приступить','проступить'],'Нарушить закон: преступить закон; приступить требует к, проступить имеет другое значение.'),
'претворить':(['притворить'],'Мечту осуществляют, претворяют в жизнь; притворить означает неплотно закрыть.'),
'предать':(['придать','продать','прядать'],'Устойчивое сочетание предать сведения огласке; прочие глаголы не допускают данное сочетание дополнений.'),
'преемник':(['приемник','приёмник'],'Продолжатель дела — преемник; приёмник обозначает аппарат или место приёма.'),
'приклеить':(['проклеить'],'Присоединить марку к конверту: приклеить; проклеить не управляет сочетанием марку к конверту.'),
'приступить':(['преступить','проступить'],'Сочетание к выполнению работы требует приступить в значении начать; иные глаголы не подходят.'),
'притворить':(['претворить','протворить'],'Значение неплотно закрыть дверь прямо задано; это притворить.'),
'придать':(['предать','продать','прядать'],'Сочетание шару нужную форму: сообщить форму шару; другие глаголы этого сочетания не образуют.'),
'приёмник':(['преёмник','преемник'],'Радиоаппарат — приёмник. Преёмник не является нормативным написанием; преемник требует ещё и изменения Ё на Е.'),
'инъекция':(['инфекция'],'Введение лекарства шприцем — инъекция; инфекция не обозначает введение лекарства.'),
'барьер':(['бартер'],'Дано значение препятствие; бартер означает товарообмен.'),
'отбросить':(['оббросить'],'Ненужные сомнения отбрасывают; оббросить не имеет данного управления и значения.'),
'отдать':(['обдать'],'Вернуть книгу владельцу — отдать; обдать требует объекта и обозначения жидкости/воздуха, а не получателя книги.'),
'отступить':(['обступить'],'От прежнего решения можно отступить; обступить требует прямого дополнения и означает окружить.'),
'открыть':(['обкрыть'],'Дверь ключом открывают; иное восстановление не подходит к инструменту и действию.'),
'отпустить':(['обпустить'],'Освободить пленного — отпустить на свободу; альтернативная приставка не даёт этого сочетания.'),
'отсчитать':(['обсчитать'],'Отсчитать десять секунд до старта — выполнить обратный счёт времени; обсчитать означает ошибиться в расчёте либо обработать расчётами, что здесь не задано.'),
'отделить':(['обделить'],'Разъединить желток и белок — отделить желток от белка; обделить означает лишить кого-либо доли и не образует это сочетание.'),
'оттянуть':(['обтянуть'],'Перенести заседание на более поздний час — оттянуть; обтянуть означает покрыть/натянуть и несовместимо с заседанием.'),
'отправить':(['обправить'],'Посылку адресату отправляют; предполагаемый другой глагол не образует указанного сочетания.')
}
def sig(ws):return tuple(sorted(w.split(' (')[0].lower().replace('ё','е') for w in ws))
old=set()
for t in inp['existing_tasks']:
 for row in t.get('drill',{}).get('rows',[]):old.add(sig([''.join(x) for x in row]))
for x in inp['current_passports']:
 for row in x['rows']:old.add(sig([z['word'] for z in row['items']]))
used=collections.Counter(); seen=set(); checks=[]; by_id={z['task_id']:z for z in p['passports']}
changed=[]
for t in p['tasks']:
 pp=by_id[t['id']]; rows=pp['rows']; assert len(rows)==5 and len(t['opts'])==5
 assert set(z['group'] for z in rows)=={'pre_pri','zs','yi','sign','td'}
 assert len(t['words'])==len(set(t['words']))==15
 key=''; item_checks=[]
 for i,r in enumerate(rows):
  assert len(r['items'])==3 and len({z['group'] for z in r['items']})==1
  letters=[z['letter'] for z in r['items']]; c=collections.Counter(letters)
  assert sorted(c.values()) in [[3],[1,2]]
  if len(c)==1:key+=str(i+1)
  assert sig([z['word'] for z in r['items']]) not in old
  assert sig([z['word'] for z in r['items']]) not in seen
  seen.add(sig([z['word'] for z in r['items']]))
  assert t['opts'][i]==', '.join(z['template'] for z in r['items'])
  for j,z in enumerate(r['items']):
   assert z['template'].count('..')==1 and len(z['letter'])==1
   pre,suf=z['template'].split('..'); triplet=t['drill']['rows'][i][j]
   assert triplet==[pre,z['letter'],suf]
   assert (pre+z['letter']+suf).split(' (')[0]==z['word']
   assert z['word'] in t['exp'] and z['rule'] in t['exp']
   used[z['word']]+=1
   aa=ad[z['word']]['dictionary_token_alternatives']
   candidates,note=manual.get(z['word'],([], 'Повторно рассмотрены все 33 одиночные буквы; нормативного конкурирующего слова в данном шаблоне автор не выявил.'))
   item_checks.append({'row':i+1,'position':j+1,'template':z['template'],'word':z['word'],'letter':z['letter'],'alphabet_checked':'абвгдеёжзийклмнопрстуфхцчшщъыьэюя','local_dictionary_token_candidates':aa,'additional_candidates_considered':candidates,'decision':note,'status':'author_checked','limitation':'Поиск токенов в толковых словарях — вспомогательный; отсутствие токена не считается доказательством отсутствия слова.'})
 assert t['key']==[key] and 1<=len(key)<=4
 assert t['year']==2027 and t['base_year']==2026 and t['status']=='draft' and t['needs_source'] is True and t['allowed_2027'] is None and t['norm_basis']['confirmed'] is False
 if any(z['word'] in ['инъекция','барьер','отсчитать'] for r in rows for z in r['items']):changed.append(t['id'])
 checks.append({'task_id':t['id'],'status':'author_second_pass_complete','independent_review':'pending','checks':{'five_rows_three_words':True,'one_rule_group_per_row':True,'homogeneous_gap_classes':True,'false_rows_2_plus_1':True,'one_letter_per_gap':True,'opts_key_exp_drill_words_passport_agree':True,'no_word_repeat_in_task':True,'row_sets_not_in_existing_tasks_or_r80_01':True,'all_prefix_groups_present':True,'draft_flags_preserved':True},'computed_key':key,'item_checks':item_checks,'source_check':{'pre_pri':'Первичный текст sid=33: §39 «Приставки при- и пре-»; §38 относится к общему правилу безударных гласных приставок.','others':'sid=13 §11 п.4, §12 п.2; sid=24 §27–28; sid=43 §79 и §82.','format_separate':True},'changed_after_first_save':t['id'] in changed})
assert len(p['tasks'])==len(p['passports'])==len(checks)==20 and max(used.values())<=4
p['author_checks']=checks
for z in p['sources']:
 if z['id'].startswith('R80-02-'): z['accessed_at']='2026-11-12'
out.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
report={'status':'author_second_pass_complete','independent_review':'pending','counts':{'tasks':20,'passports':20,'author_checks':20,'rows':100,'gaps':300,'unique_forms':len(used),'max_form_use':max(used.values())},'correct_row_count_distribution':dict(collections.Counter(len(t['key'][0]) for t in p['tasks'])),'changed_after_first_save':changed,'changes':'Добавлены контексты инъекция/барьер; уточнён контекст отсчитать. Отдать/отступить/отделить/оттянуть имели исключающие контексты уже в первом сохранении. Исправлена lexeme соловьи на соловей (лемма была соловей); ответы и наборы рядов после первого сохранения не менялись.','sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(root/'authors/line-10-author-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
