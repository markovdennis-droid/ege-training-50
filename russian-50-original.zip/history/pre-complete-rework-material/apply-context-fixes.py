import collections, copy, hashlib, json
from pathlib import Path
src=Path('work/recovered-r80/source');out=Path('work/review-80ef/r80-fixed')
names=['tasks.json','row-passports.json','blueprints.json','word-inventory.json']
input_sha256={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in names}
original={n:json.loads((src/n).read_text()) for n in names};data=copy.deepcopy(original)
fixes={
 'вправ..':{'template':'вправ.. (в правую сторону)','word':'вправо (в правую сторону)'},
 'уд..ляться':{'template':'уд..ляться (от берега)','word':'удаляться (от берега)'},
 'пр..рвать':{'template':'пр..рвать (лекцию звонком)','word':'прервать (лекцию звонком)'},
 'пр..клеить':{'template':'пр..клеить (марку к конверту)','word':'приклеить (марку к конверту)'},
 'пр..шить':{'template':'пр..дорожный','word':'придорожный','lexeme':'придорожный','lemma':'придорожный','rule':'Близость к дороге. Пишется ПРИ-.','dictionary_check':{'exact_lemma_article':False,'exact_form_article':False,'morph_known':False},'normative_check':{'status':'rule_example_confirmed','source_url':'https://www.orthographia.ru/orfografia.php?sid=30','note':'Придорожный дан как пример ПРИ- со значением близости; словарные и морфологические машинные флаги не переиспользованы от пришить.'}},
 'пр..дать (форму)':{'template':'пр..дать (шару нужную форму)','word':'придать (шару нужную форму)'},
 'пр..дать (друга)':{'template':'пр..дать (огласке)','word':'предать (огласке)','rule':'Сделать общеизвестным; устойчивое сочетание «предать огласке». Пишется ПРЕ-.'}
}
counts=collections.defaultdict(collections.Counter)
def walk(value,filename):
 if isinstance(value,list):
  for x in value:walk(x,filename)
 elif isinstance(value,dict):
  old=value.get('template')
  if old in fixes:
   value.update(copy.deepcopy(fixes[old]));counts[filename][old]+=1
  for x in value.values():walk(x,filename)
for name in ['row-passports.json','blueprints.json','word-inventory.json']:walk(data[name],name)
pmap={x['task_id']:x for x in data['row-passports.json']};oldp={x['task_id']:x for x in original['row-passports.json']}
patches=[]
for t,old in zip(data['tasks.json'],original['tasks.json']):
 p=pmap[t['id']];oldpass=oldp[t['id']]
 assert old['words']==[i['lexeme'] for r in oldpass['rows'] for i in r['items']]
 if p==oldpass:continue
 affected=[]
 for n,(r,ro) in enumerate(zip(p['rows'],oldpass['rows']),1):
  for j,(i,io) in enumerate(zip(r['items'],ro['items']),1):
   if i!=io:affected.append({'row':n,'position':j,'old_template':io['template'],'new_template':i['template'],'old_word':io['word'],'new_word':i['word'],'letter':i['letter']})
 t['opts']=[', '.join(i['template'] for i in r['items']) for r in p['rows']]
 t['drill']['rows']=[[[*i['template'].split('..')[:1],i['letter'],i['template'].split('..')[1]] for i in r['items']] for r in p['rows']]
 t['words']=[i['lexeme'] for r in p['rows'] for i in r['items']]
 t['exp']='\n\n'.join(f"{n}) "+', '.join(i['word'] for i in r['items'])+' — '+' / '.join(i['letter'].upper() for i in r['items'])+'. '+' '.join(i['rule'] for i in r['items']) for n,r in enumerate(p['rows'],1))+'\n\nОтвет: '+t['key'][0]+'.'
 patches.append({'task_id':t['id'],'key_before':old['key'],'key_after':t['key'],'changes':affected})
for blueprint in data['blueprints.json']['blueprints']:
 blueprint['task']=copy.deepcopy(next(t for t in data['tasks.json'] if t['id']==blueprint['task_id']))
for name,value in data.items():(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
# Independent assertions across all copies.
errors=[];keys=0;positions=0;wrong_triples=0
inv={(i['line'],i['template']):i for i in data['word-inventory.json']};bp={p['task_id']:p for p in data['blueprints.json']['blueprints']}
for t,old in zip(data['tasks.json'],original['tasks.json']):
 p=pmap[t['id']];size=3 if t['line'] in [9,10] else 2
 assert len(t['opts'])==len(t['drill']['rows'])==len(p['rows'])==5
 assert p=={k:v for k,v in bp[t['id']].items() if k!='task'}
 assert t==bp[t['id']]['task']
 assert t['key']==old['key'] and t['version']==old['version'] and t['family']==old['family']
 assert t['words']==[i['lexeme'] for r in p['rows'] for i in r['items']]
 key=''
 for n,(opt,drill,row) in enumerate(zip(t['opts'],t['drill']['rows'],p['rows']),1):
  assert len(drill)==len(row['items'])==size
  ls=[x[1] for x in drill]
  if len(set(ls))==1:key+=str(n)
  elif size==3:assert sorted(collections.Counter(ls).values())==[1,2];wrong_triples+=1
  kind=lambda l:'vowel' if l in 'аоуыэяёюие' else 'sign' if l in 'ъь' else 'consonant'
  assert len({kind(l) for l in ls})==1
  assert opt==', '.join(i['template'] for i in row['items'])
  for d,i in zip(drill,row['items']):
   assert d[0]+'..'+d[2]==i['template'] and ''.join(d)==i['word']
   assert d[1]==i['letter'] and inv[(t['line'],i['template'])]==i
   positions+=1
  assert f"{n}) "+', '.join(i['word'] for i in row['items'])+' — '+' / '.join(ls).upper()+'. '+' '.join(i['rule'] for i in row['items']) in t['exp']
 assert t['key']==[key] and t['exp'].endswith('Ответ: '+key+'.');keys+=1
items=[i for p in data['row-passports.json'] for r in p['rows'] for i in r['items']]
for p in data['row-passports.json']:
 if p['line']!=12:continue
 its=[i for r in p['rows'] for i in r['items']];pers=[i for i in its if i['group'].startswith(('personal','plural'))];parts=[i for i in its if i['group'].startswith(('active','passive'))]
 assert not [(a,b) for a in pers for b in parts if a['lemma'].removesuffix('ся').removesuffix('сь')==b['lemma'].removesuffix('ся').removesuffix('сь')]
# Old template strings can be prefixes of new contexts; check exact item values and comma-separated option tokens.
old_remaining={}
for name,value in data.items():
 found=[]
 def find(v):
  if isinstance(v,list):
   for x in v:find(x)
  elif isinstance(v,dict):
   if v.get('template') in fixes:found.append(v['template'])
   for x in v.values():find(x)
 find(value)
 if name=='tasks.json':
  found += [s for t in value for row in t['opts'] for s in row.split(', ') if s in fixes]
 assert not found;old_remaining[name]=found
assert len(set(t['family'] for t in data['tasks.json']))==80
assert len({tuple(sorted(i['template'] for i in r['items'])) for p in data['row-passports.json'] for r in p['rows']})==400
log={'source_dir':str(src),'output_dir':str(out),'source_sha256':input_sha256,'fix_groups':fixes,'task_count_affected':len(patches),'affected_task_ids':[p['task_id'] for p in patches],'position_count_affected':sum(len(p['changes']) for p in patches),'item_updates_by_copy':{k:dict(v) for k,v in counts.items()},'patches':patches,'version_family_policy':'Все исходные версии и family сохранены.','normative_note':'Словарные/морфологические флаги придорожный обнулены, а не скопированы от пришить; первичное подтверждение правила записано отдельно.'}
(out/'patch-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
checks={'status':'pass','executed_at':'2026-11-10','task_count':len(data['tasks.json']),'line_counts':dict(collections.Counter(t['line'] for t in data['tasks.json'])),'rows':400,'positions':positions,'recomputed_keys':keys,'keys_unchanged':True,'versions_unchanged':True,'families_unchanged':True,'five_rows_each':True,'size_3_in_9_10_size_2_in_11_12':True,'wrong_triples_two_plus_one':True,'homogeneous_gap_classes':True,'tasks_passports_blueprints_inventory_consistent':True,'exp_and_words_consistent':True,'line12_source_verb_leaks':0,'duplicate_families':0,'duplicate_rows':0,'former_exact_templates_remaining':old_remaining,'affected_task_ids':log['affected_task_ids'],'limitations':['Структурный контроль не является полной словарной приёмкой535лексем.','Файлы с журналом исправлений и этот скрипт содержат старые шаблоны намеренно для воспроизводимости; проверка отсутствия выполнена по четырём файлам данных.','Повторная проверка контекстов отражена в work/agents/reviews/r80-context-recheck.json; из-за оговорки пришить заменён на придорожный.'],'data_sha256':{n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in names},'source_files_unchanged':{n:hashlib.sha256((src/n).read_bytes()).hexdigest()==log['source_sha256'][n] for n in names}}
assert all(checks['source_files_unchanged'].values())
(out/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'affected_task_ids':log['affected_task_ids'],'affected_tasks':len(patches),'changed_positions':log['position_count_affected'],'checks':'pass'},ensure_ascii=False,indent=2))
