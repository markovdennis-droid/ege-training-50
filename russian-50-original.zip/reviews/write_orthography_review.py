from pathlib import Path
import json,copy
P=Path('work/agents/reviews');I=Path('work/agents/input')
full=json.loads((I/'orthography-full.json').read_text());byid={x['id']:x for x in full}
find=[]
t=byid['rus-2027-b80e-13-0002'];exp=t['exp'].replace('Слово «рад» употребляется в краткой форме; отрицание пишется раздельно.','НЕ с прилагательным «рад», употребляющимся в данном значении только в краткой форме, пишется раздельно. Краткость формы сама по себе не является общим основанием раздельного написания НЕ.')
find.append({'id':t['id'],'severity':'minor','claim':'Объяснение к «не рад» называет краткую форму, но опускает существенное условие правила: слово в данном значении употребляется только в краткой форме. Без уточнения ученик может распространить вывод на любые краткие прилагательные.','evidence':'Ключ 245 верен. В академическом правиле отдельно названы прилагательные, употребляющиеся только в краткой форме: «не рад, не должен, не горазд». Это не общее правило раздельности НЕ со всеми краткими прилагательными.','source_urls':['https://www.orthographia.ru/orfograf_uk.php?oid=3824','https://gramota.ru/biblioteka/spravochniki/pravila-russkoy-orfografii-i-punktuatsii/razdelnoe-napisanie-ne'],'proposed_edit':{'exp':exp},'confidence':0.94})
t=byid['rus-2027-b80e-13-0003'];exp=t['exp'].replace('НЕ с деепричастием пишется раздельно.','Сочетание «не спеша» имеет закреплённое раздельное написание; здесь означает «неторопливо». Общее правило нельзя распространять на деепричастия, не употребляющиеся без НЕ, или образования с НЕДО-.')
find.append({'id':t['id'],'severity':'minor','claim':'Формулировка «НЕ с деепричастием пишется раздельно» дана без условий и исключений; она шире нормы. Для данного сочетания лучше дать конкретное словарное основание.','evidence':'Ключ 15 верен. Академос фиксирует «не спеша» раздельно. Деепричастия типа «недоумевая» и образования с НЕДО- не подчиняются безусловному утверждению о раздельности.','source_urls':['https://orfo.ruslang.ru/abc/part/en?end=88171&start=87871','https://www.orthographia.ru/orfografia.php?sid=63'],'proposed_edit':{'exp':exp},'confidence':0.97})
(P/'orthography-findings.json').write_text(json.dumps(find,ensure_ascii=False,indent=2)+'\n')
blind=json.loads((P/'orthography-blind-answers.json').read_text());own={x['id']:x for x in blind}
ledger=[]
for t in full:
 f=[x for x in find if x['id']==t['id']];reason='Собственное решение совпало с ключом; обязательного второго ключа и ошибок нормативного написания в заданном контексте не найдено.'
 if t['id']=='rus-2027-b80e-14-0001':reason+=' Первичное сомнение о «назначенную на утро» снято после сверки с oross.ruslang.ru: назначение на часть дня — сочетание предлога и существительного; на ключ35 это в любом случае не влияет из-за «на встречу».'
 ledger.append({'id':t['id'],'own_answer':own[t['id']]['own_answer'],'key_agrees':own[t['id']]['own_answer']==t['key'],'verdict':'minor_explanation_edit' if f else 'pass_in_review_scope','reason':reason,'finding_count':len(f),'independent_human_methodist_acceptance':False})
(P/'orthography-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
legacy=json.loads((I/'orthography-legacy-full.json').read_text());lb=json.loads((P/'orthography-legacy-blind-answers.json').read_text());own={x['id']:x for x in lb};lf=[];lm={x['id']:x for x in legacy}
t=lm['rus-2027-b80c-14-0001'];e=t['exp'].replace('по- видимому','по-видимому')
lf.append({'id':t['id'],'severity':'minor','claim':'В объяснении после дефиса в «по- видимому» остался пробел — вероятно, артефакт извлечения PDF.','evidence':'Нормативное дефисное написание «по-видимому». Ключ135 от этого не меняется.','source_urls':['https://gramota.ru/poisk?query=по-видимому&mode=slovari'],'proposed_edit':{'exp':e},'confidence':1.0})
t=lm['rus-2027-b80c-15-0001'];e=t['exp'].replace('безымянная — суффикс -ЯНН- в прилагательном от основы на -МЯ.','безымянная — прилагательное от существительного «имя» на -мя; в этом производном пишется НН.')
lf.append({'id':t['id'],'severity':'minor','claim':'Формулировка «от основы на -МЯ» терминологически неточна: на -мя оканчивается исходное существительное «имя», а не названная здесь основа. Без надобности не стоит привязывать орфографическое объяснение к спорному в разных описаниях морфемному разбору -ЯНН-.','evidence':'Ключ2345 верен. Грамота №324064 прямо относит безымянный к производным от слов на -мя и подтверждает НН. В академическом §53 различаются существительные на -мя и основы их косвенных падежей. Безопасное объяснение называет исходное существительное и сохраняет доказуемый орфографический вывод.','source_urls':['https://gramota.ru/spravka/vopros/324064','https://orthographia.ru/orfograf_uk.php?oid=6152'],'proposed_edit':{'exp':e},'confidence':0.96})
(P/'orthography-legacy-findings.json').write_text(json.dumps(lf,ensure_ascii=False,indent=2)+'\n')
ledger=[]
for t in legacy:
 f=[x for x in lf if x['id']==t['id']]
 ledger.append({'id':t['id'],'own_answer':own[t['id']]['own_answer'],'key_agrees':own[t['id']]['own_answer']==t['key'],'verdict':'minor_explanation_edit' if f else 'pass_in_review_scope','reason':'Собственный ключ совпал. Проверены слитность/раздельность и полные/краткие формы. '+('См. отдельное замечание к объяснению.' if f else 'Обязательной содержательной правки не найдено.'),'finding_count':len(f),'independent_human_methodist_acceptance':False})
(P/'orthography-legacy-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
print('80E:18 checked, all keys agree, minor findings2; legacy6 checked, all keys agree, minor findings2')
