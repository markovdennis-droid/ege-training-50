import json,collections,re,hashlib,copy
from pathlib import Path
root=Path('output/r80-02'); dest=Path('work/r80-02/reviews/postfix-11-12.json')
files={n:root/(n+'.json') for n in ['tasks','passports','inventory','revised-tasks']}
data={n:json.load(open(p)) for n,p in files.items()}
hashes={n:hashlib.sha256(open(p,'rb').read()).hexdigest() for n,p in files.items()}
ts={t['id']:t for t in data['tasks']};ps={p['task_id']:p for p in data['passports']};newids={t['id'] for t in data['revised-tasks']}
oldledgers={n:json.load(open(f'work/r80-02/reviews/line-{n}-ledger.json')) for n in [11,12]}
expected={t['task_id']:t for l in oldledgers.values() for t in l['tasks']}
planned=[t for t in data['revised-tasks'] if t['line'] in [11,12]]
results=[];risks=[];structural=[]
for t in planned:
 p=ps[t['id']];prior=expected[t['id']];rowout=[]
 own=''.join(str(ri+1) for ri,r in enumerate(prior['rows']) if len(set(r['own_letters']))==1)
 for ri,(row,oldrow) in enumerate(zip(p['rows'],prior['rows'])):
  items=[]
  rendered=[];drow=[]
  for ii,(it,oldit) in enumerate(zip(row['items'],oldrow['items'])):
   # All6 substantive replacements preserve the independently solved letter.
   assert it['letter']==oldit['own_letter']
   assert it['template'].count('..')==1
   pre,suf=it['template'].split('..');drow.append([pre,it['letter'],suf]);rendered.append(it['template'])
   assert it['word'] in it['template'].replace('..',it['letter'])
   rec={'item_index':ii,'template':it['template'],'restored_word':it['word'],'own_letter':oldit['own_letter'],'letter':it['letter'],'lemma':it['lemma'],'conjugation':it.get('conjugation'),'rule_checked':True,'morpheme':it.get('morpheme'),'source_refs':it['source_refs'],'alternative_letter_risk':False}
   if oldit['own_restoration']!=it['word']:rec['changed_from']=oldit['own_restoration']
   if it['word'] not in t['exp'] or it['rule'] not in t['exp']:structural.append({'task_id':t['id'],'row_index':ri,'item_index':ii,'issue':'word_or_rule_absent_from_exp'})
   items.append(rec)
  assert ', '.join(rendered)==t['opts'][ri]
  assert drow==t['drill']['rows'][ri]
  rowout.append({'row_index':ri,'own_letters':oldrow['own_letters'],'same_letter':len(set(oldrow['own_letters']))==1,'items':items})
 assert own==prior['own_answer_before_key']
 assert t['key']==[own]
 assert t['words']==[it['word'] for r in p['rows'] for it in r['items']]
 # The returned live bank and revised-tasks copy agree in user-visible fields.
 assert all(t[k]==ts[t['id']][k] for k in ['opts','key','exp','words','drill'])
 results.append({'task_id':t['id'],'own_key':own,'published_key':t['key'],'matches':True,'five_rows_ten_items_checked':True,'opts_drill_words_exp_passports_consistent':True,'rows':rowout})
# Expanded checks across all80 updated tasks of11/12, including the formerR80-01 party.
old_dangerous=[];banned=[];bare=[];family=[];oldkeys=[]
danger=['луч..к','стол..к','проб..вать','заказ..ик','сбор..ик','камен..ик','набор..ик','барабан..ик','вправ..','сначал..','завис..мый','терп..мый','уч..щийся','служ..щий']
for pid,p in ps.items():
 if p['line'] not in [11,12]:continue
 old=pid not in newids
 families=collections.defaultdict(set)
 rows=[]
 for ri,row in enumerate(p['rows']):
  letters=[]
  for ii,it in enumerate(row['items']):
   letters.append(it['letter']);g=it['group']
   families[it['lemma'].removesuffix('ся')].add('finite' if g.startswith(('personal','plural')) else 'derived')
   if it['word'] in ['учащийся','служащий','зависимый','терпимый','сначала']:banned.append({'task_id':pid,'row_index':ri,'item_index':ii,'word':it['word']})
   if g.startswith(('personal','plural')) and not re.match(r'^\((ты|они)\)',it['template']):bare.append({'task_id':pid,'row_index':ri,'item_index':ii,'template':it['template']})
   if old and any(s in it['template'] for s in danger):
    suitable={
      'лучик': 'солнечный' in it['template'],
      'столик':'предмет мебели' in it['template'],
      'пробовать':'на вкус' in it['template'],
      'заказчик':'клиент' in it['template'],
      'сборщик':'сборке приборов' in it['template'],
      'каменщик':'строитель кирпичных стен' in it['template'],
      'наборщик':'типографии' in it['template'],
      'барабанщик':'музыкант' in it['template'],
      'вправо':'в правую сторону' in it['template']
    }.get(it['word'],False)
    old_dangerous.append({'task_id':pid,'row_index':ri,'item_index':ii,'template':it['template'],'word':it['word'],'visible_context_disambiguates':suitable,'status':'pass' if suitable else 'risk'})
  rows.append(letters)
 for lemma,c in families.items():
  if len(c)>1:family.append({'task_id':pid,'lemma_family':lemma})
 calc=''.join(str(i+1) for i,letters in enumerate(rows) if len(set(letters))==1)
 assert ts[pid]['key']==[calc]
 if old:oldkeys.append({'task_id':pid,'key_from_verified_passport_letters':calc,'matches':True})
assert not structural and not banned and not bare and not family and all(r['visible_context_disambiguates'] for r in old_dangerous)
counts=[]
for n in [11,12]:
 for party in ['planned_R80_02','previous_R80_01']:
  sel=[p for pid,p in ps.items() if p['line']==n and (pid in newids)==(party=='planned_R80_02')]
  c=collections.Counter(i['word'] for p in sel for r in p['rows'] for i in r['items'])
  assert max(c.values())<=4
  counts.append({'line':n,'party':party,'tasks':len(sel),'max_wordform_frequency':max(c.values()),'over_limit':[]})
# An inherited auxiliary usage_count can survive while the actual per-party counter is valid.
for it in data['inventory']:
 if it.get('word')=='держащий' and 'usage_count' in it:
  count=sum(i['word']=='держащий' for pid,p in ps.items() if p['line']==12 and pid in newids for r in p['rows'] for i in r['items'])
  if it['usage_count']!=count:risks.append({'severity':'minor_metadata','item':'держащий','finding':f"inventory usage_count={it['usage_count']}, актуально в новой партии{count}; аналогичный наследованный счётчик в отдельных passport items.",'key_or_norm_impact':False,'suggested_patch':{'usage_count':count},'status':'does_not_block_keys_or_frequency_limit'})
special=[
 {'task_id':'rus-2027-11-0031','row_index':2,'item_index':1,'word':'стекольщик','status':'pass','finding':'Щ в -щик- верна; исправленное правило различает мягкийЛ и обозначающий его мягкостьЬ, совпадает в паспорте иexp. Ряд3 Щ/Щ верный; ключ345.'},
 {'task_id':'rus-2027-12-0024','row_index':2,'item_index':0,'word':'держащий','status':'pass','finding':'Производящий глагол держать, II спряжение, -ащ-, А. Ряд3 А/У неверный; ключ5. Других держ- в задании нет. Форма3 раза в новой партии; пара с пляшущий не дублирует0035 дышащий/пляшущий.'}
]
report={'phase':'postfix_read_only_review','scope':'40 плановых11/12 целиком; известные опасные шаблоны и подсказки в40 прежних обновлённых11/12. Остальная база не изменялась.','agent_review_not_human_acceptance':True,'source_hashes_sha256':hashes,'summary':{'planned_tasks':40,'planned_rows':200,'planned_items':400,'planned_keys_matched':40,'wrong_letters':0,'ambiguous_planned_keys':0,'known_dangerous_old_items_checked':len(old_dangerous),'old_items_without_needed_context':0,'old_forbidden_class_mixes_remaining':0,'same_root_finite_participle_collisions_across_updated80':0,'bare_finite_forms_across_updated80':0,'blocking_risks':0,'minor_metadata_risks':len(risks),'author_database_files_modified_by_reviewer':False},'special_checks':special,'planned_tasks':results,'old_dangerous_templates':old_dangerous,'old40_key_crosschecks':oldkeys,'party_frequency_checks':counts,'removed_sensitive_words_check':{'words':['учащийся','служащий','зависимый','терпимый','сначала'],'remaining_occurrences_in_updated80':[],'note':'Проверены действующие паспортные items, а не историческое recovery.'},'risks':risks,'limitations':['Проход является агентной проверкой, не человеческой методической приёмкой.','Ключи прежней партии сопоставлены с уже проверенными нормами инвентаря и паспортными буквами; первоначального слепого решения этих40 прежних задач в этом отчёте не заявляется.']}
# Ensure the report refers to one stable source snapshot.
assert hashes=={n:hashlib.sha256(open(p,'rb').read()).hexdigest() for n,p in files.items()}
json.dump(report,open(dest,'w'),ensure_ascii=False,indent=2)
print(dest,'planned40 keys matched; old dangerous',len(old_dangerous),'blocking0; metadata',len(risks))
