"""Independent review of combinations; does not import or reproduce bulk_rework selection logic.
Run from repository root: python work/r80-02/reviews/check_bulk_09_10.py
Reads outputs and previous reviews; writes only reviews/bulk-09-10.json.
"""
import collections, hashlib, json, re
from pathlib import Path
BASE=Path('output/r80-02');REV=Path('work/r80-02/reviews')
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sig(i):return tuple(i.get(k) for k in ('line','group','template','word','lemma','letter','rule'))
def bare_word_and_letter(template,word):
    # Find the one Cyrillic token containing the gap, ignoring contextual labels.
    matches=list(re.finditer(r'([А-Яа-яЁё]*)\.\.([А-Яа-яЁё]*)',template))
    if len(matches)!=1 or template.count('..')!=1:raise ValueError('exactly one letter gap required')
    a,b=matches[0].groups()
    if not re.fullmatch('[А-Яа-яЁё]+',word):raise ValueError('word must contain one word without contextual labels')
    if len(word)!=len(a)+len(b)+1 or not word.startswith(a) or not word.endswith(b):raise ValueError('word does not match template with exactly one inserted letter')
    return word[len(a)].lower()
def char_class(c):return 'vowel' if c in 'аеёиоуыэюя' else 'sign' if c in 'ъь' else 'consonant' if c in 'бвгджзйклмнпрстфхцчшщ' else 'invalid'
alltasks=read(BASE/'tasks.json');passports=read(BASE/'passports.json');inventory=read(BASE/'inventory.json');sources=read(BASE/'sources.json');bulk_report=read(BASE/'bulk-report.json')
tasks={t['id']:t for t in alltasks};ps={p['task_id']:p for p in passports};new=[t for t in alltasks if t['line'] in (9,10) and t.get('assembly_origin')];newids={t['id'] for t in new}
prior=[p for p in passports if p['line'] in (9,10) and p['task_id'] not in newids]
audit=read(REV/'inventory-09-10.json');checked_keys={(x['line'],x['group'],x['word'],x['letter']) for x in audit['checked_items']}
oldpool={sig(i) for p in prior for row in p['rows'] for i in row['items']};canonical={sig(i) for i in inventory if i['line'] in (9,10)}
canonical_lexical={v[:6] for v in canonical}; approved_rules=collections.defaultdict(set)
for v in oldpool:approved_rules[v[:6]].add(v[6])
rule_variants=collections.Counter()
errors=[]
def fail(kind,**kw):errors.append({'status':'draft','kind':kind,**kw})
reported_bulk_ids={tid for cohort in bulk_report['cohorts'] if cohort['line'] in (9,10) for tid in cohort['tasks']}
original_ids=set()
for ln in (9,10):
    original=read(Path(f'work/r80-02/input/line-{ln:02d}.json'))
    for field in ('targets','existing_tasks'):original_ids.update(t['id'] for t in original.get(field,[]))
if newids!=reported_bulk_ids:fail('bulk_scope_id_mismatch',missing=sorted(reported_bulk_ids-newids),unexpected=sorted(newids-reported_bulk_ids))
if newids-original_ids:fail('new_task_ids_not_in_original_bank',ids=sorted(newids-original_ids))
for s in canonical:
    line,group,template,word,lemma,letter,rule=s
    if (line,group,word,letter) not in checked_keys:fail('new_lexical_element',signature=s)
    if s not in oldpool:fail('new_signature_not_present_in_prior_updated_tasks',signature=s)
# The exact context and rule signatures are preserved as an auditable manifest, rather than relying on dictionary_check.
manifest=[dict(zip(('line','group','template','word','lemma','letter','rule'),s)) for s in sorted(canonical)]
manifest_digest=hashlib.sha256(json.dumps(manifest,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
known_bare={'к..саться','прил..гать','пол..гать','зам..рать','соб..ру','выб..ру','уд..ру','ш..ги','м..рской','с..дой','д..плом','к..ртина','о..дать','о..ступить','о..считать','о..делить','о..тянуть','ин..екция','бар..ер','уд..ляться','пр..рвать','пр..клеить','пр..дать','пр..бывать','пр..ступить','пр..творить','пр..шить','вправ..'}
records=[];cohorts=collections.defaultdict(collections.Counter);letter_checks=0
for t in new:
    tid=t['id'];p=ps[tid];rows=[];correct_numbers=[];words=[];rkeys=[];issues_before=len(errors)
    if len(t.get('opts',[]))!=5 or len(p['rows'])!=5:fail('row_count',task_id=tid)
    for ri,row in enumerate(p['rows']):
        actual=[];irs=[]
        if len(row['items'])!=3:fail('item_count',task_id=tid,row_index=ri)
        expected_option=', '.join(i['template'] for i in row['items'])
        if t['opts'][ri]!=expected_option:fail('display_template_mismatch',task_id=tid,row_index=ri)
        for ii,i in enumerate(row['items']):
            try:derived=bare_word_and_letter(i['template'],i['word'])
            except ValueError as e:derived='?';fail('gap_reconstruction',task_id=tid,row_index=ri,item_index=ii,reason=str(e))
            letter_checks+=1;actual.append(derived);words.append(i['word'])
            inpool=sig(i)[:6] in canonical_lexical
            if sig(i) not in canonical:rule_variants[sig(i)]+=1
            if i['rule'] not in approved_rules.get(sig(i)[:6],set()):fail('rule_not_present_in_previously_reviewed_passports',task_id=tid,row_index=ri,item_index=ii,rule=i['rule'])
            if not inpool:fail('item_outside_audited_pool',task_id=tid,row_index=ri,item_index=ii,signature=sig(i))
            if derived!=i['letter']:fail('declared_letter_differs_from_word',task_id=tid,row_index=ri,item_index=ii,derived=derived,declared=i['letter'])
            if i['group']!=row['group']:fail('inconsistent_rule_group',task_id=tid,row_index=ri,item_index=ii)
            if i['template'] in known_bare:fail('known_ambiguity_without_context',task_id=tid,row_index=ri,item_index=ii)
            a,b=i['template'].split('..')
            if t['drill']['rows'][ri][ii]!=[a,derived,b]:fail('drill_template_mismatch',task_id=tid,row_index=ri,item_index=ii)
            filled=a+derived+b
            if filled not in t['exp'] or i['rule'] not in t['exp']:fail('explanation_missing_context_or_rule',task_id=tid,row_index=ri,item_index=ii)
            if 'ве́сны' in i['rule']:fail('old_incorrect_check_word',task_id=tid,row_index=ri,item_index=ii)
            if i['lemma'] in ('объём','объектив') and i['rule'].startswith('После приставки'):fail('old_inaccurate_morphemic_rule',task_id=tid,row_index=ri,item_index=ii)
            for sid in i.get('source_refs',[]):
                if sid not in sources:fail('source_ref_unresolved',task_id=tid,row_index=ri,item_index=ii,source_id=sid)
            irs.append({'status':'draft','item_index':ii,'template':i['template'],'word':i['word'],'derived_letter':derived,'audited_signature_match':inpool,'rule_matches_previously_reviewed_passports':i['rule'] in approved_rules.get(sig(i)[:6],set())})
        counts=collections.Counter(actual);same=len(counts)==1
        if same:correct_numbers.append(str(ri+1))
        elif sorted(counts.values())!=[1,2]:fail('false_row_not_2plus1',task_id=tid,row_index=ri,letters=actual)
        if len({char_class(c) for c in actual})!=1 or any(char_class(c)=='invalid' for c in actual):fail('mixed_gap_class',task_id=tid,row_index=ri,letters=actual)
        if len(set(i['word'] for i in row['items']))!=3:fail('word_repeat_in_row',task_id=tid,row_index=ri)
        rkeys.append(tuple(sorted(i['word'] for i in row['items'])))
        rows.append({'status':'draft','row_index':ri,'letters_from_restored_words':actual,'correct':same,'items':irs})
    key=''.join(correct_numbers);stored=''.join(t['key']) if isinstance(t['key'],list) else str(t['key'])
    if stored!=key:fail('independently_recomputed_key_mismatch',task_id=tid,derived=key,stored=stored)
    if not 1<=len(key)<=4:fail('true_rows_outside_internal_quota',task_id=tid,key=key)
    if t['words']!=words:fail('display_words_list_mismatch',task_id=tid)
    if len(set(words))!=15:fail('word_repeat_inside_task',task_id=tid)
    if t.get('status')!='draft' or t.get('allowed_2027') is not None or t.get('norm_basis',{}).get('confirmed') is not False:fail('unsupported_norm_acceptance',task_id=tid)
    if t['assembly_origin'].get('individually_blind_solved') is not False:fail('individual_solution_overclaim',task_id=tid)
    cohorts[(t['line'],t['assembly_origin']['cohort'])].update(words)
    records.append({'status':'draft','task_id':tid,'line':t['line'],'cohort':t['assembly_origin']['cohort'],'recomputed_key':key,'stored_key':stored,'key_matches':key==stored,'individually_blind_solved':False,'rows':rows,'checks_passed':issues_before==len(errors)})
# Compare unordered word triples throughout all280 updated tasks9/10, not just within the new200.
seenrows=collections.defaultdict(list);seenfamilies=collections.defaultdict(list)
for p in passports:
    if p['line'] not in (9,10):continue
    allwords=[]
    for ri,row in enumerate(p['rows']):
        words=tuple(sorted(i['word'] for i in row['items']));seenrows[(p['line'],words)].append({'task_id':p['task_id'],'row_index':ri});allwords.extend(words)
    seenfamilies[(p['line'],tuple(sorted(allwords)))].append(p['task_id'])
dups=[{'line':k[0],'words':list(k[1]),'occurrences':v} for k,v in seenrows.items() if len(v)>1];fdups=[{'line':k[0],'task_ids':v} for k,v in seenfamilies.items() if len(v)>1]
if dups:fail('duplicate_unordered_rows',duplicates=dups)
if fdups:fail('duplicate_word_families',duplicates=fdups)
cohort_records=[]
for (line,cid),freq in sorted(cohorts.items()):
    excess={w:n for w,n in freq.items() if n>4};ids=[t['id'] for t in new if t['line']==line and t['assembly_origin']['cohort']==cid]
    if excess:fail('cohort_word_frequency_over4',line=line,cohort=cid,excess=excess)
    cohort_records.append({'status':'draft','line':line,'cohort':cid,'task_count':len(ids),'maximum_word_repetitions':max(freq.values()),'excess':excess})
# Hand-read samples are explicitly delimited and do not stand for200 individual solutions.
manual_edges={'rus-2027-09-0041':'245','rus-2027-09-0152':'14','rus-2027-10-0041':'5','rus-2027-10-0128':'134'}
for tid,key in manual_edges.items():
    actual=next(x['recomputed_key'] for x in records if x['task_id']==tid)
    if actual!=key:fail('manual_edge_key_disagreement',task_id=tid,manual=key,computed=actual)
risky_words={'картина','касаться','прилагать','полагать','замирать','соберу','выберу','удеру','шаги','морской','седой','диплом','отдать','отступить','отсчитать','отделить','оттянуть','инъекция','барьер','прервать','приклеить','предать','придать','объём','объектив','весна'}
manual_context=[];seen=set()
for t in new:
    for ri,row in enumerate(ps[t['id']]['rows']):
        for ii,i in enumerate(row['items']):
            if i['word'] in risky_words and i['word'] not in seen:
                seen.add(i['word']);manual_context.append({'status':'draft','task_id':t['id'],'row_index':ri,'item_index':ii,'word':i['word'],'template':i['template'],'rule':i['rule'],'result':'Перечитано вручную; ранее известная альтернатива не подходит к сохранённому контексту, прежнее замечание к правилу устранено.'})
report={'status':'draft','scope':{'status':'draft','project_initial_manual_tasks':80,'this_reviewer_prior_blind_tasks':40,'prior_context_scanned_tasks_09_10':80,'new_automatically_checked_tasks':len(new),'new_tasks_by_line':dict(collections.Counter(str(x['line']) for x in new)),'new_tasks_individually_blind_solved':False,'matches_bulk_report_scope':newids==reported_bulk_ids,'all_ids_preexisted':newids<=original_ids,'description':'Первые80 проекта (20 каждой линии9–12) прошли индивидуальную проверку. Этот проверяющий ранее решил вслепую40 из них (линии9/10) и проверил контексты80 обновлённых задач9/10. Сейчас все новые200 комбинаций проверены автоматически; вручную перечитаны только4 крайних задания и26 контекстных/правиловых примеров.'},'inputs_sha256':{f:sha(BASE/f) for f in ['tasks.json','passports.json','inventory.json','bulk-report.json','sources.json']},'independent_implementation':'Скрипт не импортирует bulk_rework.py и не использует готовые ключи или item.letter для решения. Буква вычисляется как единственный символ восстановленного word между неизменными кириллическими частями шаблона. После этого вычисляются истинность рядов и ключ. Готовые letter/key используются только для сверки.','audited_pool':{'status':'draft','signature_fields':['line','group','template','word','lemma','letter','rule'],'lexical_comparison_fields':['line','group','template','word','lemma','letter'],'rule_comparison':'Отдельно, точное совпадение с ранее проверенными паспортами; формы и однокоренные слова не смешиваются.','signature_count':len(canonical),'manifest_sha256':manifest_digest,'no_new_lexical_key_outside_original279':all((s[0],s[1],s[3],s[5]) in checked_keys for s in canonical),'same_signatures_present_in_prior80_updated_tasks':canonical<=oldpool,'manifest':manifest,'limitations':'Словарные статьи заново для каждой комбинации не проверялись. Контроль новых альтернатив основан на полном совпадении шаблона, контекста, слова и правила с ранее аудированным пулом плюс ручном перечитывании26 рискованных случаев. Не объявляется доказательство отсутствия всех мыслимых словарных альтернатив.'},'inventory_rule_variant_notes':{'status':'draft','occurrences':sum(rule_variants.values()),'distinct_signatures':len(rule_variants),'note':'В inventory слово заменило форма даже у действительных форм. Паспортные проверки правильны и дословно присутствуют в ранее проверенных паспортах. Это терминологическое расхождение реестра, не209 ошибок заданий. Для весна в реестре предпочтительно восстановить форма множественного числа.','variants':[{'status':'draft','signature':list(k),'occurrences':v} for k,v in sorted(rule_variants.items())]},'tasks':records,'cohort_checks':cohort_records,'duplicate_check':{'status':'draft','scope_updated_tasks_09_10':len(prior)+len(new),'rows_checked':sum(len(p['rows']) for p in passports if p['line'] in (9,10)),'unordered_row_duplicates':dups,'family_duplicates':fdups},'manual_samples':{'status':'draft','edge_tasks_and_independent_keys':manual_edges,'context_examples':manual_context,'individually_solved_entire_bulk':False},'summary':{'status':'draft','new_tasks':len(new),'displayed_rows':sum(len(r['rows']) for r in records),'displayed_gaps_checked':letter_checks,'keys_match':sum(r['key_matches'] for r in records),'all_item_signatures_match_audited_pool':all(i['audited_signature_match'] for t in records for row in t['rows'] for i in row['items']),'duplicate_rows':len(dups),'duplicate_families':len(fdups),'known_new_alternative_risks':0,'findings_count':len(errors),'result':'checks_passed' if not errors else 'requires_revision'},'findings':errors,'format_and_acceptance':{'status':'draft','format':'Пять рядов по три слова; класс пропуска однородный, неверные ряды2+1. Квоты1–4 верных рядов и частотность≤4 внутри партии до20 — требования проекта, не квоты ФИПИ.','human_methodologist_approval':False,'allowed_2027':None,'norm_basis_confirmed':False,'note':'Не заявляются индивидуальное слепое решение200 задач или человеческий допуск. НовыеID не создавались этой проверкой;50 смешанных вариантов ещё не являются предметом этого отчёта.'}}
json.dump(report,open(REV/'bulk-09-10.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(report['summary'],ensure_ascii=False));print(json.dumps(errors[:5],ensure_ascii=False));print('manual context samples',len(manual_context))
