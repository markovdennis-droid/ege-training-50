import json,re,collections
from pathlib import Path
out=Path('work/r80-02/reviews/inventory-11-12.json')
r=json.load(open(out))
r['phase']='inventory_complete_and_blind_tasks_reviewed'
r['checked_at']='2026-11-12'
r['method']=['Просмотрены все264 элемента, а не только dictionary_check=false.','Каждый пропуск восстановлен вручную и проверен по морфологическому классу; отдельно искались другие однобуквенные восстановления.','Кандидаты других букв сверены с локальными первичными БТС2025; автоматическое совпадение строки не принято за словарную норму. Например, лечёшь в статье облечь — усечённое описание парадигмы, а не самостоятельная форма.','Словарные пометы разг. и отсутствие отдельной статьи словоформы сами по себе не признаны ошибкой.','Норма групп сверена с академическим справочником; спорные классификации — с Грамотой. Уровень проверки: агентная проверка, не человеческая методическая приёмка.']
r['sources']=[
 {'id':'AK42','url':'https://orthographia.ru/orfografia.php?sid=34','locator':'§42: гласные суффиксов, включая наречные -а/-о'},
 {'id':'AK46','url':'https://orthographia.ru/orfografia.php?sid=34','locator':'§46: -ев-/-ив-/-лив-/-чив-'},
 {'id':'AK50','url':'https://orthographia.ru/orfografia.php?sid=34','locator':'§50: -ек/-ик и беглость гласного'},
 {'id':'AK51','url':'https://orthographia.ru/orfografia.php?sid=34','locator':'§51: -инка/-енка; морфемные различия, отдельно лесенка'},
 {'id':'AK61','url':'https://orthographia.ru/orf.php?paragraph=pp61.php','locator':'§61: -ова-/-ыва- по форме1-го лица'},
 {'id':'AK85_88','url':'https://orthographia.ru/orfografia.php?sid=46','locator':'§§85,86,88: -цкий, -тчик/-дчик, -счик/-зчик/-жчик'},
 {'id':'AK74','url':'https://orthographia.ru/orf.php?paragraph=pp74.php','locator':'§74: спряжение, личные окончания, производные с приставками и -ся'},
 {'id':'AK58','url':'https://orthographia.ru/orf.php?paragraph=pp58.php','locator':'§58: действительные причастия настоящего времени'},
 {'id':'AK59','url':'https://orthographia.ru/orf.php?paragraph=pp59.php','locator':'§59: страдательные причастия и соотносительные прилагательные на -ем-/-им-'},
 {'id':'GRAM_DEP','url':'https://gramota.ru/spravka/vopros/290697','locator':'Ответ: зависимый — прилагательное'},
 {'id':'OROSS32','url':'https://oross.ruslang.ru/paragraph/32','locator':'§32 п.14: слова на -инка/-енка; беженка, нищенка названы словарными случаями'},
 {'id':'ROS2025','url':'https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf','locator':'Статьи пробивать(ся), столочь(ся). Получены поисковые фрагменты первичного словаря; прямое открытие PDF вернуло403.'},
 {'id':'BTS25','local_files':['work/b80g/authors/lex-work/dict1.txt','work/b80g/authors/lex-work/dict2.txt'],'locator':'Первичные толковые словари2025 из входов проекта; конкретные статьи/строки приведены в findings.'}
]
r['findings'].append({'id':'11-26','severity':'critical','template':'стол..к','finding':'Столик (И) и столок (О, прошедшее м.р. от столочь) дают две допустимые буквы. Разговорная помета не равна ошибочности. Неподсказанный ученику noun_EI не исключает глагольное чтение.','proposed_edit':{'template':'журнальный стол..к','word':'столик'},'sources':['ROS2025, столочь(ся), парадигма прош. -лок, -лкла','https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf'],'affected_tasks':['rus-2027-11-0022 row4 word1','rus-2027-11-0031 row4 word2'],'key_impact':'0031 допускает35 или345; в0022 ложность ряда4 сохраняется.'})
r['findings'].extend([
 {'id':'11-80','severity':'medium','template':'сначал..','finding':'Сначала — отыменное наречие от начало. Нельзя включать его без оговорки в объяснение приставочно-суффиксальных образований от прилагательных по модели справа/слева. БукваА верна.','proposed_edit':{'rule':'Сначала: наречие от существительного начало, конечнаяА; написание словарное/исторически падежное, не модель с- + прилагательное + -а.'},'sources':['https://gramota.ru/biblioteka/spravochniki/narechie','https://oross.ruslang.ru/paragraph/52'],'used_in_final_line11':False},
 {'id':'11-44-48','severity':'minor','templates':['виш..нка','пес..нка','беж..нка','нищ..нка','лес..нка'],'finding':'Общее правило входа упоминает -еньк-, которого в этих пяти словах нет, и не различает беглоеЕ основы (вишенка/песенка), женский -енк- (нищенка), производное беженец и специально оговорённую лесенку. НаписанияЕ верны.','proposed_edit':'Вишенка: вишня — вишен, Е основы перед -к-. Песенка: песня — песен. Нищенка: -енк- названия лица женского пола (§51). Беженка: соотнести с беженец, Е в производящей основе; при необходимости словарное написание. Лесенка: специальная оговорка §51. Не выделять -еньк-.','sources':['AK51','OROSS32'],'author_line11_status':'В выбранных словах правила уже уточнены; беженка не использована.'},
 {'id':'inventory-word-context','severity':'minor','finding':'Во входном inventory word ряда элементов включает контекст или местоимение, хотя CONTRACT требует word без контекстаподписи. Восстановление буквы не страдает.','proposed_edit':'Оставить контекст только в template; word/lexeme — чистая словоформа. В authors/line11 и12 чистые word проверены.'},
 {'id':'12-substantivation','severity':'minor','templates':['служ..щий','уч..щийся'],'finding':'Без зависимых слов допустимы и причастное, и субстантивированное чтение; писать о единственном причастном морфологическом разборе без оговорки слишком категорично. На буквуА это не влияет.','proposed_edit':'служ..щий в армии боец; уч..щийся в школе ребёнок либо оговорить субстантивацию.','sources':['BTS25 dict2.txt:24387–24389, статьи СЛУЖАЩИЙ'],'affected_tasks':['rus-2027-12-0021','rus-2027-12-0024','rus-2027-12-0030','rus-2027-12-0034','rus-2027-12-0036']},
 {'id':'12-cognate-hint','severity':'medium','finding':'В0024 учат и учащийся, в0034 учишь и учащийся. Учить/учиться — разные леммы, поэтому буквального запрета на одну лемму нет, но сохраняется подсказка однокоренными формами.','proposed_edit':'Заменить одну из двух форм на другую основу с той же буквой и заново проверить частоты.','affected_tasks':['rus-2027-12-0024','rus-2027-12-0034']},
 {'id':'11-glass-rule','severity':'minor','finding':'В готовом0031 объяснение стекольщик говорит «после Ь» при заявленной проверке конечного согласного. Ь — буква, не согласный звук.','proposed_edit':'Стекольщик: перед -щик- мягкийЛ основы; Ь обозначает мягкостьЛ. Пишется суффикс -щик-, вставляетсяЩ.','affected_tasks':['rus-2027-11-0031'],'sources':['AK42','AK85_88']}
])
by_id={f['id']:f for f in r['findings']}
inka_bases={38:'соломина',39:'горошина',40:'жемчужина',41:'изюмина',42:'впадина',43:'проталина'}
IIs={'видеть','слышать','дышать','держать','терпеть','вертеть','смотреть','обидеться','зависеть','ненавидеть','гнать','выдержать','вытерпеть','кричать'}
for line in [11,12]:
 for idx,x in enumerate(json.load(open(f'work/r80-02/input/line-{line}.json'))['inventory']):
  word=x['lexeme'];g=x['group'];lemma=x['lemma']
  e={'line':line,'inventory_index':idx,'template':x['template'],'expected_word':word,'letter':x['letter'],'lemma':lemma,'checks':{'single_letter_reconstruction':True,'spelling':'correct','alternative_letter_checked':True,'dictionary_check_used_as_proof':False},'findings':[],'proposed_edits':[]}
  fid=f'{line}-{idx}'
  if fid in by_id:e['findings'].append(fid);e['proposed_edits'].append(by_id[fid]['proposed_edit'])
  if line==11:
   if g=='adj_EI':e.update(morpheme='-чив-' if idx<6 else '-лив-' if idx<8 else '-ив-' if idx<10 else '-ев-',part_of_speech='прилагательное',rule_verdict='correct; для -ев- предпочтительно различать относительные/качественные прилагательные, не полагаться только на ударение',source_refs=['AK46'])
   elif g=='noun_EI':e.update(morpheme='-ик-' if x['letter']=='и' else '-ек-',part_of_speech='существительное',rule_verdict='correct: сохранение/выпадение гласного при склонении',source_refs=['AK50'])
   elif g=='inka':
    mor='-ин- производящей основы + -к-' if idx in inka_bases else 'Е беглой основы + -к-' if idx in [44,45] else '-ен- производящей основы + -к-' if idx==46 else '-енк-' if idx==47 else 'словарная модель -енка, специально §51'
    e.update(morpheme=mor,part_of_speech='существительное',rule_verdict='spelling correct; уточнить морфемную формулировку' if idx>=44 else 'correct',source_refs=['AK51','OROSS32'])
    if idx in inka_bases:e['derivational_base']=inka_bases[idx]
    if idx>=44:e['findings'].append('11-44-48')
   elif g=='verb_OY':e.update(morpheme='-ова-' if x['letter']=='о' else '-ыва-',part_of_speech='глагол, инфинитив',rule_verdict='correct',first_person_verification=x['rule'],source_refs=['AK61'])
   elif g=='adv_AO':e.update(morpheme='-а' if x['letter']=='а' else '-о',part_of_speech='наречие',rule_verdict='correct for this word' if idx!=80 else 'correct spelling, revise derivational rule',source_refs=['AK42'])
   elif g=='jobs':e.update(morpheme='-чик-' if x['letter']=='ч' else '-щик-',part_of_speech='существительное со значением лица',rule_verdict='correct for selected base; general statement needs exceptions for нт/льт/рт/йт',source_refs=['AK42','AK85_88'])
   elif g=='k_sk':e.update(morpheme='школьное -к-; академически поглощение С в стыке с -ск-' if x['letter']=='к' else '-ск-',part_of_speech='прилагательное',rule_verdict='correct; разные уровни морфемного описания не смешивать',source_refs=['AK85_88'])
  else:
   conj='II' if lemma.endswith('ить') and lemma!='брить' or lemma in IIs else 'I'
   e['source_verb']=lemma;e['conjugation']=conj
   if g.startswith('personal'):e.update(part_of_speech='личная форма глагола',person=2,number='единственное',morpheme='окончание -ешь' if x['letter']=='е' else 'окончание -ишь',source_refs=['AK74'])
   elif g.startswith('plural'):e.update(part_of_speech='личная форма глагола',person=3,number='множественное',morpheme='окончание -'+x['letter']+'т',source_refs=['AK74'])
   elif g.startswith('active'):e.update(part_of_speech='действительное причастие настоящего времени',morpheme='-'+x['letter']+'щ-',person=None,number='единственное',gender='мужской',case='именительный',source_refs=['AK58','AK74'])
   else:e.update(part_of_speech='отглагольное прилагательное' if idx==59 else 'страдательное причастие настоящего времени либо соотносительное прилагательное',morpheme='-'+x['letter']+'м-',person=None,number='единственное',gender='мужской',case='именительный',source_refs=['AK59','AK74'])
   e['rule_verdict']='correct spelling and conjugation; revise category' if idx==59 else 'correct'
   if lemma=='зреть': e['lemma_sense']='зреть = созревать, I спряжение; различать омоним зреть = видеть (II), который не подходит к данной буквенной основе'
   if lemma=='кричать':e['rule_note']='II спряжение определяется ударными окончаниями кричишь/кричат; не называть одним из11 исключений для безударных окончаний.'
   if lemma=='организовать':e['rule_note']='Для организуемый реализуется несовершенное значение двувидового организовать; написание -ем- прямо подтверждено §59.'
   if word in ['учащийся','служащий']:e['findings'].append('12-substantivation')
  if re.search(r'[ ()]',x['word']):e['findings'].append('inventory-word-context');e['proposed_edits'].append({'word':word})
  if line==11 and idx==81:e['context_verdict']='Контекст «в правую сторону» исключает вправе (Е), достаточен; сохранять.'
  if line==11 and idx in [102,104]:e['context_verdict']='Профессиональное пояснение исключает наборник/барабанник; сохранять.'
  e['status']='revise' if e['findings'] else 'pass'
  r['checked_items'].append(e)
r['summary']={'line11_checked':123,'line12_checked':141,'total_checked':len(r['checked_items']),'wrong_expected_letters':0,'critical_ambiguous_templates':5,'blind_task_reports':['work/r80-02/reviews/blind-11-own.json','work/r80-02/reviews/blind-12-own.json'],'final_tasks_intended_keys_matched':'40/40','final_tasks_key_uniqueness_issue':'rus-2027-11-0031:35/345 until столик context fixed','database_modified':False,'author_files_modified':False}
json.dump(r,open(out,'w'),ensure_ascii=False,indent=2)
print('SAVED',out,len(r['checked_items']))
