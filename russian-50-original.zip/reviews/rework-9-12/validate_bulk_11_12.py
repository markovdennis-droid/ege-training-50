#!/usr/bin/env python3
"""Independent combination audit for231 bulk tasks11/12.
Does NOT import, execute or copy the generator. Reads its report only to identify
cohort membership. Norm evidence comes from the already completed264-item audit,
not from the generator's correct-letter flag. Missing letters are re-derived by
aligning each gap token against the independently audited complete word.
This is automated combination validation, NOT231 individually blind-solved tasks,
NOT a new complete dictionary audit, and NOT human methodologist acceptance.
"""
import collections,hashlib,json,re
from pathlib import Path
OUTPUT=Path('output/r80-02'); REVIEW=Path('work/r80-02/reviews')
paths={n:OUTPUT/(n+'.json') for n in ['tasks','passports','inventory','bulk-report']}
raw={n:p.read_bytes() for n,p in paths.items()}
data={n:json.loads(v) for n,v in raw.items()}
sha={n:hashlib.sha256(v).hexdigest() for n,v in raw.items()}
tasks={t['id']:t for t in data['tasks']}
passports={p['task_id']:p for p in data['passports']}
cohorts=[c for c in data['bulk-report']['cohorts'] if c['line'] in [11,12]]
ids=[tid for c in cohorts for tid in c['tasks']]; target=set(ids)
# The normative ledger was produced before bulk generation.
prior=json.loads((REVIEW/'inventory-11-12.json').read_text())
audit={(x['line'],x['expected_word'],x['lemma']):x for x in prior['checked_items']}
original={n:json.load(open(f'work/r80-02/input/line-{n}.json'))['inventory'] for n in [11,12]}
groups={(n,i['lexeme'],i['lemma']):i['group'] for n,ls in original.items() for i in ls}
curated={(i['line'],i['group'],i['word'],i['lemma']):i for i in data['inventory'] if i['line'] in [11,12]}
errors=[];task_rows=[];unique={};contexts=collections.defaultdict(list)
checks=collections.Counter(); all_expected_keys={}
def error(code,tid=None,ri=None,ii=None,**more):
 errors.append({'code':code,**({'task_id':tid} if tid else {}),**({'row_index':ri} if ri is not None else {}),**({'item_index':ii} if ii is not None else {}),**more})
def need(ok,code,tid=None,ri=None,ii=None,**more):
 checks[code]+=1
 if not ok:error(code,tid,ri,ii,**more)
 return ok
def lemma_base(s):
 # Exact lemma plus the reflexive/nonreflexive family, not a broad stemmer.
 return re.sub(r'(ся|сь)$','',s)
def derive(template,word):
 tokens=re.findall(r'[А-Яа-яЁё]*\.\.[А-Яа-яЁё]*',template)
 if len(tokens)!=1 or template.count('..')!=1:return None
 p,s=tokens[0].split('..')
 if len(word)!=len(p)+len(s)+1 or not word.startswith(p) or s and not word.endswith(s):return None
 return word[len(p)]
if len(ids)!=231 or len(target)!=231:error('scope_expected231',actual=len(ids),unique=len(target))
for tid in ids:
 if tid not in tasks or tid not in passports:error('missing_task_or_passport',tid);continue
 t=tasks[tid];p=passports[tid];line=t['line'];recomputed=[];perrow=[];words=[];lemmas=[]
 need(p['line']==line,'line_consistency',tid)
 need(len(t.get('opts',[]))==5 and len(p['rows'])==5,'five_rows',tid)
 for ri,row in enumerate(p['rows']):
  need(len(row['items'])==2,'two_items',tid,ri)
  letters=[];itemled=[];opt=[];drill=[]
  for ii,item in enumerate(row['items']):
   word=item['word'];lemma=item['lemma'];g=item['group'];template=item['template'];k=(line,word,lemma);ci=curated.get((line,g,word,lemma));a=audit.get(k)
   need(a is not None,'previous_independent_word_audit_membership',tid,ri,ii,word=word,lemma=lemma)
   if a:
    need(a['checks']['spelling']=='correct','audited_word_spelling',tid,ri,ii)
    need(groups.get(k)==g,'audited_group_consistency',tid,ri,ii)
   need(ci is not None,'curated_inventory_membership',tid,ri,ii)
   if ci:
    for field in ['template','word','lemma','lexeme','group','rule','source_refs']:
     need(item.get(field)==ci.get(field),'curated_'+field,tid,ri,ii)
   # Derive from the audited full spelling. Never use row/item letter as input.
   own=derive(template,a['expected_word'] if a else word)
   need(own is not None,'one_letter_alignment',tid,ri,ii,template=template,word=word)
   if own is None:own='?'
   need(own==item['letter'],'independently_derived_letter',tid,ri,ii,derived=own,stored=item['letter'])
   if a:need(own==a['letter'],'matches_prebulk_norm_letter',tid,ri,ii)
   need(g==row['group'],'row_group_homogeneity',tid,ri,ii)
   need(own in row['contrast'],'letter_in_declared_contrast',tid,ri,ii)
   need(not re.search(r'[\s()]',word),'clean_word_field',tid,ri,ii)
   need(word==item['lexeme'],'word_lexeme_consistency',tid,ri,ii)
   need(word not in ['учащийся','служащий','зависимый','терпимый','сначала'],'excluded_borderline_forms_absent',tid,ri,ii)
   if line==12:
    finite=g.startswith(('personal','plural'))
    if finite:need(bool(re.match(r'^\((ты|они)\)',template)),'visible_person_number_context',tid,ri,ii)
    need(lemma not in t['stem']+' '+', '.join(t['opts']),'no_visible_source_infinitive',tid,ri,ii)
    if a and item.get('conjugation') is not None:need(item['conjugation']==a['conjugation'],'audited_conjugation',tid,ri,ii)
    if item.get('infinitive') is not None:need(item['infinitive']==lemma,'infinitive_lemma_match',tid,ri,ii)
   need(word in t['exp'] and item['rule'] in t['exp'],'word_and_rule_in_explanation',tid,ri,ii)
   if template.count('..')==1:
    pre,suf=template.split('..');drill.append([pre,own,suf])
   letters.append(own);words.append(word);lemmas.append(lemma_base(lemma));opt.append(template)
   itemled.append({'item_index':ii,'template':template,'word':word,'lemma':lemma,'group':g,'derived_letter':own,'stored_letter':item['letter'],'independent_inventory_audit_index':a['inventory_index'] if a else None})
   unique[(line,g,word,lemma,template)]=itemled[-1]
   if '(' in template and not g.startswith(('personal','plural')) or ' ' in template or word=='стекольщик':contexts[(line,word,template)].append({'task_id':tid,'row_index':ri,'item_index':ii})
  need(', '.join(opt)==t['opts'][ri],'opts_passport_match',tid,ri)
  need(drill==t['drill']['rows'][ri],'drill_alignment_match',tid,ri)
  correct=len(set(letters))==1
  if correct:recomputed.append(str(ri+1))
  perrow.append({'row_index':ri,'letters':letters,'same_letter':correct,'items':itemled})
 key=''.join(recomputed);all_expected_keys[tid]=key
 need(t['key']==[key],'key_recalculated_from_spelling',tid,recalculated=key,stored=t['key'])
 need(1<=len(recomputed)<=4,'one_to_four_correct_rows',tid)
 need(t['words']==words,'words_passport_match',tid)
 need(len(set(words))==len(words),'no_repeated_word_inside_task',tid)
 need(len(set(lemmas))==len(lemmas),'no_repeated_lemma_or_reflexive_family',tid,normalized_lemmas=lemmas)
 task_rows.append({'task_id':tid,'line':line,'recomputed_key':key,'stored_key':t['key'],'matches':t['key']==[key],'rows':perrow})
# Detect repeats regardless of row order, word order, group name or gloss wording.
row_locations=collections.defaultdict(list)
for tid,p in passports.items():
 if p['line'] not in [11,12]:continue
 for ri,r in enumerate(p['rows']):row_locations[(p['line'],tuple(sorted(i['word'] for i in r['items'])))].append({'task_id':tid,'row_index':ri})
repeats=[]
for signature,locs in row_locations.items():
 if len(locs)>1 and any(v['task_id'] in target for v in locs):
  repeats.append({'line':signature[0],'words':list(signature[1]),'locations':locs});error('repeated_row_against_all_updated11_12',locations=locs)
cohort_checks=[]
for cohort in cohorts:
 c=collections.Counter(i['word'] for tid in cohort['tasks'] for r in passports[tid]['rows'] for i in r['items'])
 maximum=max(c.values())
 need(maximum<=4,'cohort_frequency_at_most4',cohort=cohort['id'],max_frequency=maximum)
 cohort_checks.append({'cohort':cohort['id'],'line':cohort['line'],'tasks':len(cohort['tasks']),'maximum_wordform_frequency':maximum,'over4':{w:n for w,n in c.items() if n>4}})
# Manual rereading is limited to these types. Every generated occurrence is
# checked by the exact curated-template comparisons above, not claimed manual.
notes={
 'наборщик':'Пояснение работник типографии задаёт название лица на -щик-.',
 'заказчик':'Клиент ателье исключает заказник; Ч послеЗ.',
 'сборщик':'Рабочий на сборке приборов исключает сборник; -щик-.',
 'столик':'Предмет мебели исключает глагольную форму столок; И сохраняется в столика.',
 'барабанщик':'Музыкант в оркестре исключает иные предметные названия; -щик-.',
 'пробовать':'Блюдо на вкус фиксирует пробовать и исключает пробивать; пробую → -ова-.',
 'каменщик':'Строитель кирпичных стен исключает иные названия на камен-; -щик-.',
 'вправо':'В правую сторону исключает вправе; суффикс -о.',
 'колющий':'Колоть, I спряжение, колют → колющий; предметное пояснение сохранено.',
 'стекольщик':'Щ в -щик-; правило правильно различает мягкийЛ и обозначающую мягкостьЬ.'}
manual=[]
for (line,word,temp),locs in sorted(contexts.items()):
 if word in notes:
  manual.append({'line':line,'word':word,'template':temp,'manual_rereading':'pass','note':notes[word],'generated_occurrences':len(locs),'sample_location':locs[0]})
# Passive contexts were also read as21 unique types, not all their occurrences.
passive=[{'word':v['word'],'template':v['template'],'lemma':v['lemma'],'manual_rereading':'pass','note':'Творительный действующего лица/источника и определяемое существительное допускают причастное чтение; написание соответствует проверенному спряжению.'} for k,v in unique.items() if k[1]=='passive_EI']
report={
 'review_type':'Independent automated combination validation after inventory norm audit',
 'individually_blind_solved':False,'human_methodologist_accepted':False,
 'limitations':['231 задача не решалась вручную вслепую. Скрипт проверяет все комбинации после независимого аудита слов.','Словарная норма244 уникальных форм опирается на предыдущий аудит264 элементов; новая полная словарная проверка не заявляется.','Вручную перечитаны10 типов пограничных шаблонов и21 тип контекстных страдательных причастий; не заявляется ручная проверка каждого повторного вхождения.','Проверка lemma/base-ся объединяет точные инфинитивы с/без -ся/-сь; она не заменяет исследование всех этимологически родственных основ.','Отсутствие повторов рядов проверено среди всех обновлённых паспортов11/12. Это не утверждение об уникальности каждой части50 будущих смешанных вариантов.','Устаревшие служебные usage_count не используются как доказательство частоты; реальные частоты пересчитаны по каждому cohort.'],
 'script':'work/r80-02/reviews/validate_bulk_11_12.py',
 'generator_imported_or_used_for_validation_logic':False,
 'source_files_sha256':sha,
 'norm_audit':'work/r80-02/reviews/inventory-11-12.json',
 'primary_norm_sources':['https://orthographia.ru/orfografia.php?sid=34','https://orthographia.ru/orfografia.php?sid=46','https://orthographia.ru/orf.php?paragraph=pp61.php','https://orthographia.ru/orf.php?paragraph=pp74.php','https://orthographia.ru/orf.php?paragraph=pp58.php','https://orthographia.ru/orf.php?paragraph=pp59.php'],
 'summary':{'additional_tasks':len(ids),'line11_tasks':sum(tasks[i]['line']==11 for i in ids),'line12_tasks':sum(tasks[i]['line']==12 for i in ids),'rows':sum(len(t['rows']) for t in task_rows),'positions':sum(len(r['items']) for t in task_rows for r in t['rows']),'unique_audited_forms_templates':len(unique),'keys_matched':sum(t['matches'] for t in task_rows),'errors':len(errors),'duplicate_rows_involving_bulk':len(repeats),'manual_borderline_types':len(manual),'manual_passive_context_types':len(passive)},
 'check_invocation_counts':dict(checks),'errors':errors,'task_ledgers':task_rows,'cohort_frequency_checks':cohort_checks,'repeated_rows':repeats,'manual_borderline_rereading':manual,'manual_passive_context_rereading':passive,
 'read_only_validation':True
}
# Fail explicitly if a concurrent build changed the source snapshot.
if sha!={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()}:error('source_changed_during_validation');report['summary']['errors']=len(errors)
(REVIEW/'bulk-11-12.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report['summary'],ensure_ascii=False))
if errors:
 print(json.dumps(errors[:30],ensure_ascii=False,indent=2))
 raise SystemExit(1)
