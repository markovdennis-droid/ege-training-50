import json,re,hashlib,collections
from pathlib import Path
base=Path('work/r80-02'); path=base/'reviews/inventory-09-10.json';r=json.load(open(path))
S=r['sources'];S.extend([
 {'id':'ACADEMIC-CONS','url':'https://www.orthographia.ru/orfografia.php?sid=43','locator':'§79: неизменяемые приставки; §82: приставки на З/С'},
 {'id':'ACADEMIC-YI','url':'https://www.orthographia.ru/orfografia.php?sid=13','locator':'§12: И/Ы после приставок'},
 {'id':'NTS25-1','url':'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast1_A-N.pdf','local_file':'work/b80g/authors/lex-work/dict1.pdf','text_file':'work/b80g/authors/lex-work/dict1.txt','locator':'Нормативный толковый словарь2025, том А–Н; статьи по леммам. Не отождествляется с орфографическим словарём DICT25.'},
 {'id':'NTS25-2','url':'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast2_O-Ja.pdf','local_file':'work/b80g/authors/lex-work/dict2.pdf','text_file':'work/b80g/authors/lex-work/dict2.txt','locator':'Нормативный толковый словарь2025, том О–Я; статьи по леммам. Не отождествляется с орфографическим словарём DICT25.'},
 {'id':'GRAMOTA-PRILEGAT','url':'https://gramota.ru/meta/prilegat','locator':'прилегать: орфография и значения; непереходность'},
 {'id':'GRAMOTA-ZAPACHKAT','url':'https://gramota.ru/poisk?mode=slovari&query=запа́чкать+и+испа́чкать.&simple=0','locator':'БТС: запачкать = загрязнить, замарать; существование альтернативы замарать'},
 {'id':'GRAMOTA-MIRSKOY','url':'https://gramota.ru/poisk?mode=all&query=Миусков','locator':'РОС и БТС, статья мирской'},
 {'id':'GRAMOTA-OB','url':'https://gramota.ru/poisk?mode=slovari&query=об+ее&simple=0','locator':'БТС, приставка ОБ...; прямо приведены обсчитать, обделить'},
 {'id':'GRAMOTA-HIST-OB','url':'https://gramota.ru/spravka/vopros/314761','locator':'Сращение исторической приставки об(ъ)- с корнем в объём; осторожность синхронного разбора'},
 {'id':'GRAMOTA-ORTH2025','url':'https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf','locator':'Статьи обступить, обдать, обтянуть, куртина; поисковая выдача первичного PDF. Прямое открытие PDF вернуло403, это ограничение не скрыто.'},
 {'id':'GRAMOTA-KURTINA','url':'https://gramota.ru/poisk?mode=slovari&page=2&query=плетёная+корзина&simple=0','locator':'РОС: куртина, -ы; отдельная словарная статья'},
 {'id':'GRAMOTA-KHVALIT','url':'https://gramota.ru/meta/khvalit','locator':'Таблица: хва́лит. Проверочное слово инвентаря корректно; предположение о хвали́т отклонено.'},
 {'id':'GRAMOTA-VESNA','url':'https://gramota.ru/poisk?mode=slovari&query=весен','locator':'Орфоэпический словарь: весна́, весны́, мн. вёсны, вёсен, вёснам. Для объяснения нужна Ё.'}
])
# Словарные свидетельства проверяются заново по доступному тексту, флаги dictionary_check не читаются.
dicts=[]
for n in [1,2]:
 p=Path(f'work/b80g/authors/lex-work/dict{n}.txt');s=re.sub('[\u0300-\u036f\ue000-\uf8ff]','',p.read_text());dicts.append((f'NTS25-{n}',s,s.lower()))
def ev(lemma):
 out=[]
 for sid,s,low in dicts:
  m=re.search(r'(?<![а-яё])'+re.escape(lemma.lower())+r'(?![а-яё])',low)
  if m:
   out.append({'source_ref':sid,'locator':f'Текст PDF, страница по разделителю form-feed {s.count(chr(12),0,m.start())+1}; вхождение «{lemma}»','kind':'text_attestation_not_automatic_exact_article_claim'})
 return out
# Нормативные альтернативы и форма восстановленного слова.
source_map={
 'кусаться':['NTS25-1'],'прилегать':['GRAMOTA-PRILEGAT'],'полегать':['OROSS-LEG'],'замарать':['GRAMOTA-ZAPACHKAT'],
 'собору':['NTS25-2'],'выбору':['NTS25-1'],'удару':['NTS25-2'],'шуги':['GRAMOTA-SHUGA'],
 'мирской':['GRAMOTA-MIRSKOY'],'содой':['NTS25-2'],'дуплом':['NTS25-1'],
 'обдать':['GRAMOTA-ORTH2025'],'обступить':['GRAMOTA-ORTH2025'],'обсчитать':['OROSS-OBSCHITAT'],'обделить':['GRAMOTA-OB'],'обтянуть':['NTS25-2','GRAMOTA-ORTH2025'],
 'инфекция':['NTS25-1'],'бартер':['NTS25-1']}
for f in r['findings']:
 f['sources']=source_map[f['alternative']];f['evidence_status']='primary_source_attestation_reviewed';f['required_action']='Уточнить шаблон или исключить из новых рядов до уточнения.'
 f['proposed_word']=next(x['lexeme'] for x in json.load(open(base/f"input/line-{int(f['id'].split('-')[1]):02d}.json"))['inventory'] if x['template']==f['template'])
 f['alternative_basis']={'собору':'Дательный ед. существительного собор.','выбору':'Дательный ед. существительного выбор.','удару':'Дательный ед. существительного удар.','шуги':'Родительный ед. существительного шуга.','содой':'Творительный ед. существительного сода.','дуплом':'Творительный ед. существительного дупло.'}.get(f['alternative'],'Отдельная словарно засвидетельствованная лексема.')
 if f['template'] in ['ин..екция','бар..ер']:
  f['issue']='Шаблон без контекста допускает другую лексему при замене одной буквы. Группа sign в паспорте ученику не сообщена и сама не ограничивает множество восстановлений Ъ/Ь.'
# Дополнительная подтверждённая неоднозначность.
i=json.load(open(base/'input/line-09.json'))['inventory'][114]
r['findings'].append({'id':'INV-9-114','status':'draft','severity':'critical','template':i['template'],'lemma':i['lemma'],'issue':'Картина и куртина восстанавливаются одной буквой в одном шаблоне.','alternative':'куртина','alternative_basis':'Куртина — самостоятельное нормативное существительное.','proposed_template':'к..ртина (написанная художником)','proposed_word':'картина','evidence_status':'primary_source_attestation_reviewed','sources':['GRAMOTA-KURTINA','GRAMOTA-ORTH2025'],'required_action':'Добавить исключающий контекст.'})
# Ошибки и улучшения объяснений.
r['findings'].extend([
 {'id':'INV-9-094-RULE','status':'draft','severity':'high','template':'в..сна','lemma':'весна','issue':'В проверочном слове инвентаря стоит «ве́сны», что неверно передаёт ударный гласный и создаёт ложную произносительную модель.','proposed_rule':'Безударную Е в корне проверяет форма множественного числа «вёсны» (Е без ударения соответствует Ё под ударением).','sources':['GRAMOTA-VESNA','NTS25-1','ACADEMIC-ROOT']},
 {'id':'INV-10-093-RULE','status':'draft','severity':'high','template':'об..ектив','lemma':'объектив','issue':'Объяснение через обычную современную русскую приставку ОБ- подменяет историческую структуру заимствования. §27 п.1б отдельно рассматривает такие слова.','proposed_rule':'В заимствованном слове «объектив» пишется разделительный Ъ после исторической начальной части об- перед Е; написание закреплено словарём (§27 п.1б).','sources':['ACADEMIC-SIGN']},
 {'id':'INV-10-086-RULE','status':'draft','severity':'medium','template':'об..ём','lemma':'объём','issue':'Безоговорочное выделение в слове современной приставки ОБ- методически спорно: Грамота объясняет сохранённый Ъ исторической приставкой и её сращением с корнем.','proposed_rule':'В слове «объём» сохраняется словарно закреплённый разделительный Ъ; написание исторически связано с приставкой об(ъ)-.','sources':['GRAMOTA-HIST-OB']},
 {'id':'INV-09-CHECKED-TERMINOLOGY','status':'draft','severity':'low','scope':'checked_AO и checked_EI, где проверка дана другим однокоренным словом','issue':'Формулировка «проверяет форма» применяется и к другому слову: далёкий — даль, морской — море, сожалеть — жалость и др. Это не грамматические формы одного слова.','proposed_rule_pattern':'Безударную гласную в корне проверяет слово «…». Для действительной формы того же слова допустимо: «проверяет форма …».','sources':['ACADEMIC-ROOT']},
 {'id':'INV-10-SIGN-O-EXPLANATION','status':'draft','severity':'low','templates':['павил..он','медал..он','бул..он'],'issue':'Общее объяснение разделительного Ь желательно уточнить для позиции перед О: это словарные иноязычные случаи, а не обычная позиция перед Е/Ё/Ю/Я/И.','proposed_rule':'В этом заимствованном слове перед О пишется разделительный Ь; словарное написание (§28, примечание).','sources':['ACADEMIC-SIGN']},
 {'id':'INV-SOURCE-LOCATORS','status':'draft','severity':'medium','scope':'Ссылка PREFIX и связанный реестр источников','issue':'URL sid=43 содержит согласные; сам по себе не доставляет §12, §§27–28 и §39. Также локальные dict1/dict2 являются толковыми томами2025, а не тем PDF, на который указывает DICT25. Машинное совпадение с ними не удостоверяет проверку статьи орфографического словаря.','proposed_source_mapping':{'И/Ы':'ACADEMIC-YI, §12','Ъ/Ь':'ACADEMIC-SIGN, §§27–28','ПРЕ/ПРИ':'ACADEMIC-ROOT, §39','З/С':'ACADEMIC-CONS, §82','ПОД-/НАД-/ПРЕД-/ОТ-':'ACADEMIC-CONS, §79','локальные толковые статьи':'NTS25-1 / NTS25-2','орфографические статьи':'GRAMOTA-ORTH2025 или конкретная статья РОС Грамоты'},'sources':['ACADEMIC-YI','ACADEMIC-SIGN','ACADEMIC-ROOT','ACADEMIC-CONS','NTS25-1','NTS25-2']}
])
# Новые контексты R80-01 специально не снимаются и не заменяются прежними шаблонами.
prior={'уд..ляться (от берега)':'Контекст задаёт удаление от объекта, а не распределение внимания.','пр..рвать (лекцию звонком)':'Вмешательство звонка прерывает лекцию; прорвать с таким дополнением не подходит.','пр..клеить (марку к конверту)':'Дательный с К задаёт присоединение; проклеить требует иного объекта/управления.','пр..дать (шару нужную форму)':'Дательный адресата и винительный формы исключают предать/продать.','пр..дать (огласке)':'Устойчивое управление исключает придать/продать.','пр..дорожный':'Без прежней неоднозначности пришить/прошить; пример прямо есть в §39.'}
# Формальные нарушения word/context перечисляются отдельно от языковой нормы.
ctx_words=[];items=[]
for line in [9,10]:
 inv=json.load(open(base/f'input/line-{line:02d}.json'))['inventory']
 for k,i in enumerate(inv):
  fs=[f['id'] for f in r['findings'] if f.get('template')==i['template'] and (f['id'].startswith(f'INV-{line}-'))]
  risks=[]
  if fs:risks+=fs
  if line==9 and i['group'].startswith('checked_') and k in [72,73,77,78,79,83,85,86,87,88,90,91,96,97,98,99,103,105,106,107,108]:risks.append('INV-09-CHECKED-TERMINOLOGY')
  if i['template'] in ['павил..он','медал..он','бул..он']:risks.append('INV-10-SIGN-O-EXPLANATION')
  if '(' in i['word']:ctx_words.append({'line':line,'inventory_index':k,'template':i['template'],'current_word':i['word'],'proposed_word':i['word'].split(' (')[0]})
  grp=i['group'];refs=['ACADEMIC-ROOT'] if line==9 or grp=='pre_pri' else ['ACADEMIC-YI'] if grp=='yi' else ['ACADEMIC-SIGN'] if grp=='sign' else ['ACADEMIC-CONS']
  loc='§35: чередование '+('А/О' if grp=='alt_AO' else 'Е/И') if grp.startswith('alt_') else '§34: проверяемая гласная' if grp.startswith('checked_') else 'Словарное написание' if grp.startswith('dict_') else '§39: ПРЕ/ПРИ' if grp=='pre_pri' else '§12: И/Ы после приставок' if grp=='yi' else '§§27–28: разделительные знаки' if grp=='sign' else '§82: З/С' if grp=='zs' else '§79: неизменяемые согласные приставок'
  found=ev(i['lemma']);row={'id':f'ITEM-{line}-{k:03d}','status':'draft','line':line,'inventory_index':k,'template':i['template'],'word':i['word'].split(' (')[0],'lemma':i['lemma'],'group':grp,'letter':i['letter'],'result':'requires_revision' if risks else 'no_defect_detected','risk_refs':risks,'rule_review':'Просмотрены правило, морфемная позиция и пригодность проверки; замечания только в risk_refs.','rule_source_refs':refs,'rule_locator':loc,'alternative_review':'Проверены другие гласные/согласные/знаки; помимо ручного прохода использован поиск словарных кандидатов по всем буквам. Отсутствие найденной альтернативы не объявляется доказательством её невозможности.','dictionary_evidence':found,'dictionary_check_trusted':False}
  if i['template'] in prior:row['r80_01_context_recheck']={'result':'sufficient_for_target_lexeme','note':prior[i['template']]}
  if i['template']=='хв..лить':row['extra_note']='Правильный шаблон в инвентаре х..лить? Проверить индекс.'
  if i['lemma']=='хвалить':row['extra_note']='Хва́лит как проверочная форма подтверждено Грамотой; замена не требуется.';row['rule_source_refs']+=['GRAMOTA-KHVALIT']
  items.append(row)
r['checked_items']=items
r['field_contract_findings']=[{'status':'draft','severity':'medium','issue':'В inventory.word включены контекстные скобки. По CONTRACT новый паспорт должен держать контекст только в template, word — одна восстановленная словоформа.','proposed_changes':ctx_words,'note':'Это отдельная структурная правка; не ошибка языковой нормы. Авторы могут уже нормализовать поле при сборке.'}]
r['method']={'status':'draft','scope':'Все151 элемента №9 и все128 элементов №10. Инвентарь прочитан целиком; dictionary_check не использован как основание.','checks':['одна буква в шаблоне','нормативное восстановление','альтернативная буква и другое слово/словоформа','достаточность контекста','корень/приставка/исторический элемент','проверочное слово и ударение','источник правила отдельно от источника формата'],'limits':'Это критический аудит, а не допуск/приёмка материала. Первичные правила и словарные свидетельства указаны; полная повторная орфографическая словарная статья по каждому из279 слов отдельно не заявляется. Текстовые вхождения локальных словарей отражены честно, без копирования старых exact_lemma_article.'}
r['format_check']={'status':'draft','source':'ФИПИ2027, локальная ДЕМО.txt, строки214–243: задания9/10 по5 рядов, по3 слова, одна буква; КОДИФ.txt, раздел3.7','note':'Сверено отдельно от нормы. Внутренние квоты1–4 верных рядов и однородность групп заданы CONTRACT; не объявляются цитатой или квотой ФИПИ.','approved_for_2027':None}
r['r80_01_seven_fixes']={'status':'draft','preserved':True,'in_scope_templates':prior,'outside_scope':['вправо/вправе отсутствует в инвентаре9/10'],'note':'Ни один прежний неоднозначный шаблон не возвращён; пришить/прошить не восстанавливается. Контексты удаляться, прервать, приклеить, придать, предать и замена на придорожный достаточны для целевых лексем.'}
r['summary']={'status':'draft','checked_count':len(items),'by_line':dict(collections.Counter(str(x['line']) for x in items)),'critical_findings':sum(f['severity']=='critical' for f in r['findings']),'other_findings':sum(f['severity']!='critical' for f in r['findings']),'no_defect_detected':sum(x['result']=='no_defect_detected' for x in items),'requires_revision':sum(x['result']=='requires_revision' for x in items)}
json.dump(r,open(path,'w'),ensure_ascii=False,indent=2)
print(r['summary'])
