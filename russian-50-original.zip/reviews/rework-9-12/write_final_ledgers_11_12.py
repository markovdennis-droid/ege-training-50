import json,copy,collections,hashlib,re
from pathlib import Path
base=Path('work/r80-02/reviews')
def save(name,x):json.dump(x,open(base/name,'w'),ensure_ascii=False,indent=2)
authors={n:json.load(open(f'work/r80-02/authors/line-{n}.json')) for n in [11,12]}
patches=[]
repls=[('rus-2027-12-0024',2,0,'дышащий'),('rus-2027-12-0034',4,1,'значащий'),('rus-2027-12-0021',0,0,'лечащий'),('rus-2027-12-0030',1,0,'тащащий'),('rus-2027-12-0036',4,0,'дышащий')]
inv={i['word']:i for i in authors[12]['inventory_used']}
ps={p['task_id']:p for p in authors[12]['passports']}
proposed=copy.deepcopy(authors[12]['passports'])
prps={p['task_id']:p for p in proposed}
for taskid,ri,ii,w in repls:
 old=ps[taskid]['rows'][ri]['items'][ii]
 new=copy.deepcopy(inv[w]);new.pop('usage_count',None)
 assert new['letter']==old['letter'] and new['group']==old['group']
 others=[it for r in ps[taskid]['rows'] for it in r['items'] if it is not old]
 assert all(it['lemma'].removesuffix('ся')!=new['lemma'].removesuffix('ся') for it in others)
 patches.append({'task_id':taskid,'row_index':ri,'item_index':ii,'severity':'medium','status':'confirmed','finding':'Устранение подсказки учить/учиться и/или субстантивированного чтения учащийся/служащий при безусловном причастном паспорте. БукваА не меняется.','old_word':old['word'],'patch':{'replacement_item':new},'sources':['https://orthographia.ru/orf.php?paragraph=pp58.php','https://orthographia.ru/orf.php?paragraph=pp74.php'],'changes_key':False})
 prps[taskid]['rows'][ri]['items'][ii]=new
freq=collections.Counter(it['word'] for p in proposed for r in p['rows'] for it in r['items'])
assert max(freq.values())<=4
for p in proposed:
 it=[i for r in p['rows'] for i in r['items']]
 assert len({i['word'] for i in it})==10
 # All roots of added replacement are absent elsewhere, including reflexive cognates.
for p in patches:p['frequency_after_all_patches']=freq[p['patch']['replacement_item']['word']]
patches.append({'task_id':'rus-2027-11-0031','row_index':2,'item_index':1,'severity':'minor','status':'confirmed','finding':'В авторском правиле сказано «после Ь» при проверке конечного согласного основы. Ь — буква, не согласный звук; формулировку стоит уточнить.','old_word':'стекольщик','patch':{'rule':'Стекольщик: перед суффиксом -щик- в основе мягкий Л; Ь обозначает мягкость Л. Пишется -щик-, вставляется Щ.'},'sources':['https://orthographia.ru/orfografia.php?sid=34'],'changes_key':False})
for n in [11,12]:
 a=authors[n]
 b=json.load(open(base/f'blind-{n}-own.json'))
 pp={p['task_id']:p for p in a['passports']}
 tasks=[]
 for t,own in zip(a['tasks'],b['rows']):
  assert t['id']==own['id']
  ledger=[]
  for ri,(opt,letters,prow) in enumerate(zip(t['opts'],own['letters'],pp[t['id']]['rows'])):
   items=[]
   for ii,(let,actual) in enumerate(zip(letters,prow['items'])):
    assert let==actual['letter']
    item={'item_index':ii,'template':actual['template'],'own_restoration':actual['word'],'own_letter':let,'author_letter':actual['letter'],'letter_matches':True,'lemma':actual['lemma'],'group':actual['group'],'morpheme':actual.get('morpheme') or ('окончание' if actual['group'].startswith(('personal','plural')) else 'суффикс'),'morphology':actual.get('morphology'),'conjugation':actual.get('conjugation'),'rule_checked':True,'source_refs':actual['source_refs'],'alternative_letter_verdict':'Иная нормативная буква в данном видимом контексте не установлена.'}
    if actual['word']=='столик':item['alternative_letter_verdict']='Столок исключён видимым пояснением «предмет мебели»; неоднозначность предыдущей редакции устранена.'
    if actual['word'] in ['учащийся','служащий']:item['class_note']='Возможна субстантивация; букваА едина. Точная замена приведена в final-findings-11-12.json.'
    items.append(item)
   ledger.append({'row_index':ri,'option':opt,'own_letters':list(letters),'own_row_is_correct':len(set(letters))==1,'items':items})
  calc=''.join(str(i+1) for i,v in enumerate(own['letters']) if len(set(v))==1)
  assert calc==own['own_answer'] and t['key']==[calc]
  tasks.append({'task_id':t['id'],'own_answer_before_key':own['own_answer'],'author_key':t['key'],'key_matches':True,'rows':ledger,'explanation_all_items_checked':True,'stem_infinitive_hint':False,'exact_personal_participle_same_lemma':False})
 report={'line':n,'author_file':f'work/r80-02/authors/line-{n}.json','author_sha256':hashlib.sha256(open(f'work/r80-02/authors/line-{n}.json','rb').read()).hexdigest(),'method':'Первичный проход только stem/opts, собственные буквы и ответы сохранены в blind-NN-own.json до открытия key/exp. Затем проверены все объяснения и паспорта. Финальная11 повторно проверена после добавления предмет мебели.','agent_review_not_human_acceptance':True,'summary':{'tasks_checked':20,'rows_checked':100,'items_checked':200,'intended_keys_matched':20,'wrong_expected_letters':0,'ambiguous_keys_in_frozen_version':0,'max_surface_word_frequency':max(collections.Counter(it['word'] for p in a['passports'] for r in p['rows'] for it in r['items']).values())},'tasks':tasks,'findings_ref':'work/r80-02/reviews/final-findings-11-12.json'}
 save(f'line-{n}-ledger.json',report)
final={'scope':'Зафиксированные40 заданий линий11/12. Индексы0-based. Проверка агентная; человеческая методическая приёмка не проводилась.','reviewed_sha256':{str(n):hashlib.sha256(open(f'work/r80-02/authors/line-{n}.json','rb').read()).hexdigest() for n in [11,12]},'summary':{'tasks':40,'rows':200,'items':400,'intended_keys_matched':40,'wrong_letters':0,'ambiguous_keys':0,'patches':6,'required_replacements_line12':5,'word_frequency_after_five_replacements_max':max(freq.values()),'all_replacements_same_letter_and_group':True,'all_replacements_from_inventory_used':True,'new_same_root_collisions':False},'item_patches':patches,'resolved_findings':[{'task_id':'rus-2027-11-0022','row_index':3,'item_index':0,'old_issue':'столик/столок','resolution':'Авторский контекст (предмет мебели) уже есть; сохранить.'},{'task_id':'rus-2027-11-0031','row_index':3,'item_index':1,'old_issue':'Ключ35/345 при столок/столик','resolution':'Авторский контекст (предмет мебели) уже есть; единственный ключ345.'},{'issue':'Пробовать/пробивать; заказчик/заказник; сборщик/сборник','resolution':'В финальных шаблонах даны достаточные контексты.'},{'issue':'Зависимый как причастие','resolution':'В финальную12 не включён.'}],'frequency_after_five_replacements':dict(sorted(freq.items())),'uncertain_findings':[],'database_or_author_files_modified':False,'rebuild_note':'Root должен заменить item целиком, затем заново собрать opts/words/drill/exp/key/passports/inventory_used counts; старые учиться/служить/морфология/источники не должны сохраниться на заменённых позициях.'}
save('final-findings-11-12.json',final)
# Finish audit264, preserving distinctions between rule-based confirmation and direct lexicographic evidence.
r=json.load(open(base/'inventory-11-12.json'))
for e in r['checked_items']:
 if e['line']==12 and e['lemma']=='учиться':e['conjugation']='II'
 e['confidence']='confirmed_rule_based'
 e['evidence_scope']='Применение проверенного академического правила к вручную проверенной форме; отдельная словарная статья каждой словоформы не заявляется.'
 if f"{e['line']}-{e['inventory_index']}" in ['11-24','11-26','11-49','11-95','11-103','12-59']:e['confidence']='confirmed_primary_lexicographic_or_gramota_evidence'
r['uncertain_candidates']=[{'template':'обрад..вать','candidate':'обрадывать','status':'not_established_as_current_standard_alternative','evidence':'Исторический словарь Даля фиксирует обрадывать; современное первичное подтверждение допустимости этой формы для текущего ЕГЭ не установлено. Не объявлено ошибкой из-за стилистической пометы и не использовано как основание блокировки финальных заданий.','action':'При расширении исторической лексики пересмотреть отдельно.'}]
r['summary']['final_tasks_key_uniqueness_issue']='В зафиксированной редакции нет: столик уточнён видимым контекстом (предмет мебели).'
r['summary']['final_tasks_reports']=['work/r80-02/reviews/line-11-ledger.json','work/r80-02/reviews/line-12-ledger.json','work/r80-02/reviews/final-findings-11-12.json']
for f in r['findings']:
 f['verification_status']='confirmed' if f['id'] not in ['12-cognate-hint','12-substantivation','11-glass-rule'] else 'confirmed_observation_editorial_action'
 if f['id']=='11-26':f['final_author_status']='Устранено контекстом (предмет мебели) в обеих финальных позициях.'
 if f['id']=='12-cognate-hint':f['final_patch_ref']='final-findings-11-12.json; replacements0024/0034'
 if f['id']=='12-substantivation':f['final_patch_ref']='final-findings-11-12.json; полные replacement_item вместо всех5 учащийся/служащий'
save('inventory-11-12.json',r)
print('Wrote three final files; audit items',len(r['checked_items']),'patches',len(patches),'frequencies',[(w,freq[w]) for w in ['дышащий','лечащий','значащий','тащащий']])
