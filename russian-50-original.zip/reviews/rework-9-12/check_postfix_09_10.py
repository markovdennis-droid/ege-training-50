import json,re,hashlib,collections
from pathlib import Path
B=Path('output/r80-02'); R=Path('work/r80-02/reviews')
load=lambda p:json.load(open(p))
alltasks=load(B/'tasks.json'); revised=load(B/'revised-tasks.json'); passports=load(B/'passports.json'); inventory=load(B/'inventory.json'); sources=load(B/'sources.json');previous=load(R/'final-findings-09-10.json')
targets=[t for t in revised if t['line'] in [9,10]];pm={p['task_id']:p for p in passports};tm={t['id']:t for t in alltasks}
own={}
for l in [9,10]:
 for x in load(R/f'line-{l:02d}-ledger.json')['tasks']:own[x['task_id']]=x
findings=[];task_results=[]
def issue(kind,**kw):findings.append({'status':'draft','kind':kind,**kw})
for t in targets:
 p=pm[t['id']];rs=[];own_answer=own[t['id']]['own_answer'];key=''.join(t['key'])
 if key!=own_answer:issue('key_mismatch',task_id=t['id'],expected=own_answer,actual=key)
 if tm[t['id']]!=t:issue('revised_vs_database_payload_mismatch',task_id=t['id'])
 words=[]
 for ri,row in enumerate(p['rows']):
  items=row['items'];letters=''.join(x['letter'] for x in items);oldletters=own[t['id']]['rows'][ri]['own_letters'];constructed=', '.join(x['template'] for x in items);expected_drill=[[*x['template'].split('..',1)[:1],x['letter'],x['template'].split('..',1)[1]] for x in items]
  # Формат drill: prefix, letter, suffix.
  expected_drill=[[x['template'].split('..',1)[0],x['letter'],x['template'].split('..',1)[1]] for x in items]
  problems=[]
  if letters!=oldletters:problems.append('letters differ from independent blind solution')
  if t['opts'][ri]!=constructed:problems.append('opts differ from passport templates')
  if t['drill']['rows'][ri]!=expected_drill:problems.append('drill differs from passport templates and letters')
  for ii,i in enumerate(items):
   words.append(i['word']);filled=i['template'].replace('..',i['letter'])
   if i['template'].count('..')!=1 or len(i['letter'])!=1:problems.append(f'item {ii}: not exactly one gap/letter')
   if filled not in t['exp']:problems.append(f'item {ii}: filled context missing from exp')
   if i['rule'] not in t['exp']:problems.append(f'item {ii}: rule missing from exp')
   for ref in i.get('source_refs',[]):
    if ref not in sources:problems.append(f'item {ii}: missing source {ref}')
  counts=collections.Counter(letters)
  if len(counts)>1 and sorted(counts.values())!=[1,2]:problems.append('false row is not 2+1')
  if problems:issue('row_integrity',task_id=t['id'],row_index=ri,details=problems)
  rs.append({'status':'draft','row_index':ri,'letters':letters,'independent_letters_match':letters==oldletters,'correct':len(counts)==1,'integrity_ok':not problems})
 if t['words']!=words:issue('words_list_mismatch',task_id=t['id'])
 if t['status']!='draft' or t.get('allowed_2027') is not None or t['norm_basis'].get('confirmed') is not False:issue('norm_acceptance_overclaim',task_id=t['id'])
 if 'ве́сны' in t['exp']:issue('unfixed_vesny',task_id=t['id'])
 task_results.append({'status':'draft','task_id':t['id'],'line':t['line'],'final_key':key,'independent_key':own_answer,'matches':key==own_answer,'rows':rs,'new_risks':[]})
patch_results=[]
for f in previous['findings']+previous['optional_findings']:
 i=pm[f['task_id']]['rows'][f['row_index']]['items'][f['item_index']];matches=all(i.get(k)==v for k,v in f['patch'].items());patch_results.append({'status':'draft','id':f['id'],'task_id':f['task_id'],'row_index':f['row_index'],'item_index':f['item_index'],'applied':matches})
 if not matches:issue('unapplied_patch',id=f['id'],expected=f['patch'],actual={k:i.get(k) for k in f['patch']})
# Точный поиск известных голых шаблонов, а также прежних удалённых неоднозначностей.
bare={'к..саться','прил..гать','пол..гать','зам..рать','соб..ру','выб..ру','уд..ру','ш..ги','м..рской','с..дой','д..плом','к..ртина','о..дать','о..ступить','о..считать','о..делить','о..тянуть','ин..екция','бар..ер','уд..ляться','пр..рвать','пр..клеить','пр..дать','пр..бывать','пр..ступить','пр..творить','пр..шить','вправ..'}
occ=[];scanned=[]
for p in passports:
 if p['line'] not in [9,10]:continue
 scanned.append(p['task_id'])
 t=tm[p['task_id']]
 for ri,row in enumerate(p['rows']):
  for ii,i in enumerate(row['items']):
   if i['template'] in bare:occ.append({'task_id':p['task_id'],'row_index':ri,'item_index':ii,'template':i['template']})
   if 'ве́сны' in i['rule'] or (i['lemma'] in ['объём','объектив'] and i['rule'].startswith('После приставки')):issue('old_inaccurate_rule',task_id=p['task_id'],row_index=ri,item_index=ii,rule=i['rule'])
   if i['template'] not in t['opts'][ri]:issue('older_task_template_not_propagated',task_id=p['task_id'],row_index=ri,item_index=ii)
   if i['rule'] not in t['exp']:issue('older_task_rule_not_propagated',task_id=p['task_id'],row_index=ri,item_index=ii)
for n,i in enumerate(inventory):
 if i['line'] in [9,10] and i['template'] in bare:occ.append({'inventory_index':n,'line':i['line'],'template':i['template']})
if occ:issue('known_bare_templates_remaining',occurrences=occ)
inv_rule_bad=[{'inventory_index':n,'template':i['template'],'rule':i['rule']} for n,i in enumerate(inventory) if i['line'] in [9,10] and ('ве́сны' in i['rule'] or (i['lemma'] in ['объём','объектив'] and i['rule'].startswith('После приставки')))]
if inv_rule_bad:issue('old_inventory_rules',items=inv_rule_bad)
report={'status':'draft','scope':'Финальные40 плановых заданий №9/10 просмотрены целиком: opts, exp, drill, words и паспорт; ключи сопоставлены с зафиксированным независимым слепым решением. Дополнительно все обновлённые №9/10 проверены на известные голые неоднозначные шаблоны и неточные правила.','inputs_sha256':{f:hashlib.sha256((B/f).read_bytes()).hexdigest() for f in ['revised-tasks.json','tasks.json','passports.json','inventory.json','sources.json']},'tasks':task_results,'patch_verification':patch_results,'known_ambiguity_scan':{'status':'draft','scanned_updated_task_count':len(scanned),'scanned_task_ids':scanned,'bare_template_set':sorted(bare),'remaining_occurrences':occ,'inventory_entries_scanned':sum(i['line'] in [9,10] for i in inventory)},'findings':findings,'summary':{'status':'draft','planned_tasks':len(targets),'keys_match_independent_blind_solutions':sum(x['matches'] for x in task_results),'planned_rows':sum(len(x['rows']) for x in task_results),'planned_gaps':sum(len(row['items']) for t in targets for row in pm[t['id']]['rows']),'verified_patches':len(patch_results),'patches_applied':sum(x['applied'] for x in patch_results),'remaining_known_bare_templates':len(occ),'new_findings':len(findings),'result':'no_remaining_known_defect_detected' if not findings else 'requires_revision'},'limits':'После исправлений новая полная словарная экспертиза не заявляется. Достаточность исправленных контекстов и объяснений сверена с первичными основаниями прошлого аудита. ФИПИ подтверждает формат отдельно от нормы; статусы draft, allowed_2027=null, norm_basis.confirmed=false сохранены. База и выходные сборочные файлы не изменялись.'}
json.dump(report,open(R/'postfix-09-10.json','w'),ensure_ascii=False,indent=2)
print(report['summary']);print(findings[:20])
