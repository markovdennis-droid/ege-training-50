import json,hashlib,collections,re
from pathlib import Path
B=Path('work/r80-02');R=B/'reviews'
# Финальные контексты №10 изменились после первого слепого решения; буквы и ответы перепроверены по blind-final-10.
own10=json.load(open(R/'own-answers-10.json'));b10=json.load(open(R/'blind-final-10.json'))
for x in own10['solutions']:x['risks']=[]
own10['author_file_sha256']=b10['author_file_sha256'];own10['method']='Первый проход был слепым по id/stem/opts. Финальная версия повторно просмотрена через blind-final-10.json: добавленные контексты барьер/инъекция и уточнение отсчитать достаточны; собственные буквы и ответы сохраняются. Новые key/exp до фиксации финального решения не читались.'
json.dump(own10,open(R/'own-answers-final-10.json','w'),ensure_ascii=False,indent=2)
find=[];optional=[];ledgers=[]
newrule={'весна':'Безударную Е в корне проверяет форма множественного числа «вёсны» (Е без ударения соответствует Ё под ударением).','объём':'В слове «объём» сохраняется словарно закреплённый разделительный Ъ; написание исторически связано с приставкой об(ъ)-.'}
forms={'перо','седой','сад','лиса','вода','письмо','шаг','гора','волна','весна','тропа','трава','земля','хвалить'}
for line,ownfile in [(9,'own-answers-09.json'),(10,'own-answers-final-10.json')]:
 p=B/f'authors/line-{line:02d}.json';d=json.load(open(p));sha=hashlib.sha256(p.read_bytes()).hexdigest();own={x['id']:x for x in json.load(open(R/ownfile))['solutions']};passports={x['task_id']:x for x in d['passports']}
 tasks=[];freq=collections.Counter();patterns=[]
 for t in d['tasks']:
  oid=t['id'];s=own[oid];ps=passports[oid];key=''.join(t['key']) if isinstance(t['key'],list) else str(t['key']);rows=[];task_words=[]
  for ri,row in enumerate(ps['rows']):
   pletters=''.join(i['letter'] for i in row['items']);words=[i['word'] for i in row['items']];task_words+=words;freq.update(words)
   templates=[i['template'] for i in row['items']];rowissues=[]
   for ii,i in enumerate(row['items']):
    common={'status':'draft','task_id':oid,'row_index':ri,'item_index':ii,'lemma':i['lemma'],'before':{'template':i['template'],'rule':i['rule']}}
    if i['lemma']=='картина' and i['template']=='к..ртина':
     f=common|{'id':f'{oid}:{ri}:{ii}:context','severity':'critical','issue':'Шаблон допускает куртина (У), самостоятельное нормативное слово.','patch':{'template':'к..ртина (написанная художником)'},'source_refs':['GRAMOTA-KURTINA','GRAMOTA-ORTH2025'],'effect':'Буква целевой лексемы и целевой ключ после уточнения контекста сохраняются.'};find.append(f);rowissues.append(f['id'])
    if i['lemma']=='весна' and 'ве́сны' in i['rule']:
     f=common|{'id':f'{oid}:{ri}:{ii}:rule','severity':'high','issue':'Неверная передача ударного гласного в проверочном слове: нормативно вёсны.','patch':{'rule':newrule['весна']},'source_refs':['GRAMOTA-VESNA','NTS25-1','ACADEMIC-ROOT']};find.append(f);rowissues.append(f['id'])
    if i['lemma']=='объём' and 'После приставки' in i['rule']:
     f=common|{'id':f'{oid}:{ri}:{ii}:rule','severity':'medium','issue':'Историческая приставка и современная морфемная граница смешаны. Для ключа это безвредно, для объяснения нужна оговорка.','patch':{'rule':newrule['объём']},'source_refs':['GRAMOTA-HIST-OB']};find.append(f);rowissues.append(f['id'])
    if line==9 and i['group'].startswith('checked_') and i['lemma'] not in forms and i['lemma']!='весна':
     opt=common|{'id':f'{oid}:{ri}:{ii}:terminology','severity':'low','issue':'Проверка данным однокоренным словом ошибочно названа проверкой формой того же слова. Само проверочное слово пригодно.','patch':{'rule':i['rule'].replace('Гласную проверяет форма','Гласную в корне проверяет слово')},'source_refs':['ACADEMIC-ROOT']};optional.append(opt)
   counts=collections.Counter(pletters);rows.append({'status':'draft','row_index':ri,'own_letters':s['own_row_letters'][ri],'passport_letters':pletters,'letters_match':s['own_row_letters'][ri]==pletters,'words':words,'templates':templates,'correct_by_target_lexemes':len(counts)==1,'false_row_has_2plus1':len(counts)==1 or sorted(counts.values())==[1,2],'pending_patch_ids':rowissues})
  tasks.append({'status':'draft','task_id':oid,'own_answer':s['own_answer'],'author_key':key,'matches':s['own_answer']==key,'rows':rows,'no_repeated_word_within_task':len(task_words)==len(set(task_words))})
  patterns.append(s['own_answer'])
 report={'status':'draft','line':line,'author_file':str(p),'author_sha256':sha,'blind_file':str(R/f'blind-final-{line:02d}.json'),'own_answers_file':str(R/ownfile),'tasks':tasks,'summary':{'status':'draft','task_count':len(tasks),'matches':sum(x['matches'] for x in tasks),'row_letter_matches':sum(z['letters_match'] for x in tasks for z in x['rows']),'all_false_rows_2plus1':all(z['false_row_has_2plus1'] for x in tasks for z in x['rows']),'all_tasks_without_internal_word_repeat':all(x['no_repeated_word_within_task'] for x in tasks),'maximum_word_frequency':max(freq.values()),'words_over4':{k:v for k,v in freq.items() if v>4},'true_row_counts':dict(collections.Counter(len(x) for x in patterns))},'norm_acceptance':{'status':'draft','confirmed':False,'allowed_2027':None,'note':'Совпадение целевых ключей не отменяет замечаний к контекстам/объяснениям. ФИПИ — источник формата отдельно от нормы.'}}
 json.dump(report,open(R/f'line-{line:02d}-ledger.json','w'),ensure_ascii=False,indent=2);ledgers.append(report)
inv=json.load(open(R/'inventory-09-10.json'))
final={'status':'draft','scope':'Независимый слепой проход по40 финальным заданиям9/10; авторские файлы не изменены.','author_sha256':{str(x['line']):x['author_sha256'] for x in ledgers},'summary':{'status':'draft','target_answer_matches':sum(x['summary']['matches'] for x in ledgers),'task_count':40,'required_or_recommended_item_patches':len(find),'critical_context_patches':sum(x['severity']=='critical' for x in find),'optional_terminology_patches':len(optional)},'findings':find,'optional_findings':optional,'resolved_in_authors':[{'status':'draft','line':10,'items':'барьер, инъекция, отсчитать, объектив, бульон/медальон/павильон','result':'Финальные контексты и объяснения просмотрены, прежние замечания сняты для финальных авторских заданий.'},{'status':'draft','line':9,'items':'касаться, прилагать, полагать, замирать, соберу, выберу, удеру, шаги, морской, седой, диплом','result':'Финальные контексты достаточны; прежние неоднозначные шаблоны не возвращать.'}], 'not_errors':[{'status':'draft','item':'хв..лить — хва́лит','reason':'Проверочная форма хва́лит подтверждена Грамотой; ошибочная правка на основании хвали́т не требуется.','source_refs':['GRAMOTA-KHVALIT']},{'status':'draft','item':'ПЕ/ПИ и корни с чередованием','reason':'Ряд не обязан сводиться к одной паре корней; контраст внутри общей орфограммы допустим. Только однородность класса пропуска и 2+1 для неверного ряда проверены как требования CONTRACT.'}], 'sources':inv['sources'],'patch_application':'Применить patch к указанному passport.rows[row_index].items[item_index], после чего централизованно пересобрать opts/exp/drill/words. Все индексы0-based. Ключи целевых лексем после правок не меняются.','format_vs_norm':{'status':'draft','format':'Локальный ФИПИ2027: по5 рядов и3 слова, одна и та же буква. Вариативность1–4 верных рядов — квота проекта.','language_norm':'Подтверждается источниками в findings; ни совпадение ключа, ни ФИПИ не являются допуском отдельной лексемы.','approved_for_2027':None}}
json.dump(final,open(R/'final-findings-09-10.json','w'),ensure_ascii=False,indent=2)
print(final['summary'])
for x in ledgers:print(x['line'],x['summary'])
for x in find:print(x['task_id'],x['row_index'],x['item_index'],x['patch'])
