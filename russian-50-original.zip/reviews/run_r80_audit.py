import json, collections, hashlib, pathlib
base=pathlib.Path('work/recovered-r80/source')
T=json.loads((base/'tasks.json').read_text());P=json.loads((base/'row-passports.json').read_text());I=json.loads((base/'word-inventory.json').read_text())
errors=collections.defaultdict(list);used=collections.Counter();pmap={p['task_id']:p for p in P};imap={(i['line'],i['template']):i for i in I};leaks=[];rowsets=collections.defaultdict(list);lemreps=[]
for t in T:
 p=pmap[t['id']];size=3 if t['line'] in [9,10] else 2
 if len(t['opts'])!=5 or len(t['drill']['rows'])!=5 or len(p['rows'])!=5:errors['five_rows'].append(t['id'])
 key=''
 for n,(opt,drill,row) in enumerate(zip(t['opts'],t['drill']['rows'],p['rows']),1):
  items=row['items'];letters=[d[1] for d in drill]
  if len(drill)!=size or len(items)!=size:errors['row_size'].append([t['id'],n])
  if letters!=[i['letter'] for i in items]:errors['passport_letters'].append([t['id'],n])
  if len(set(letters))==1:key+=str(n)
  elif size==3 and sorted(collections.Counter(letters).values())!=[1,2]:errors['wrong_triple_shape'].append([t['id'],n])
  cls=lambda x:'vowel' if x in 'аоуыэяёюие' else 'sign' if x in 'ъь' else 'consonant'
  if len(set(map(cls,letters)))!=1:errors['mixed_gap_classes'].append([t['id'],n])
  if opt!=', '.join(i['template'] for i in items):errors['opt_passport'].append([t['id'],n])
  ex=f"{n}) "+', '.join(i['word'] for i in items)+' — '+' / '.join(letters).upper()+'. '+' '.join(i['rule'] for i in items)
  if ex not in t['exp']:errors['exp_passport'].append([t['id'],n])
  rowsets[tuple(sorted(i['template'] for i in items))].append([t['id'],n])
  for j,(d,i) in enumerate(zip(drill,items),1):
   used[(t['line'],i['template'])]+=1
   if d[0]+'..'+d[2]!=i['template'] or ''.join(d)!=i['word']:errors['drill_passport'].append([t['id'],n,j])
   if imap.get((t['line'],i['template']))!=i:errors['inventory_passport'].append([t['id'],n,j])
 if t['key']!=[key] or not key:errors['key'].append([t['id'],key,t['key']])
 if not t['exp'].endswith(f'Ответ: {key}.'):errors['explanation_key'].append(t['id'])
 items=[i for r in p['rows'] for i in r['items']]
 for l,c in collections.Counter(i['lemma'] for i in items).items():
  if c>1:lemreps.append([t['id'],l,c])
 if t['line']==12:
  personal=[i for i in items if i['group'].startswith(('personal','plural'))]
  parts=[i for i in items if i['group'].startswith(('active','passive'))]
  for a in personal:
   for b in parts:
    if a['lemma'].removesuffix('ся').removesuffix('сь')==b['lemma'].removesuffix('ся').removesuffix('сь'):leaks.append([t['id'],a['word'],b['word']])

def positions(temp):
 return [{'task_id':t['id'],'row':n,'row_text':o,'key':t['key'][0]} for t in T for n,o in enumerate(t['opts'],1) if temp in o.split(', ')]
issues=[]
def add(id,severity,claim,temp,urls,edit,extra=None):
 e={'template':temp,'occurrences':positions(temp)}
 if extra:e.update(extra)
 issues.append(dict(id=id,severity=severity,claim=claim,evidence=e,source_urls=urls,proposed_edit=edit))
pdf='https://gramota.ru/storage/public/normdicts/orfograficheskij_slovar.pdf'
add('R80-AUD-01','high','Пропуск вправ.. без контекста допускает нормативные вправо и вправе. В 11-0021 ряд2 может оказаться верным либо неверным; авторский ключ24 не единственен (альтернатива4).','вправ..',[pdf,'https://gramota.ru/poisk?mode=slovari&query=%D0%B2%D0%BF%D1%80%D0%B0%D0%B2%D0%BE'],'Добавить семантический контекст: вправ.. (повернуть). Синхронно обновить opts/drill/items/exp во всех вхождениях; выбранная О и ключ сохранятся.',{'alternative_letters':['о','е'],'key_impact':{'rus-2027-11-0021':['24','4'],'rus-2027-11-0004':'ключ2345 сохраняется, но поэлементная буква неоднозначна'}})
add('R80-AUD-02','high','Уд..ляться без контекста допускает удаляться и уделяться. В 09-0021 ряд2 и ключ24 становятся неоднозначными (альтернатива4).','уд..ляться',['https://gramota.ru/poisk?mode=slovari&query=%D1%83%D0%B4%D0%B5%CC%81%D0%BB%D0%B0%D1%82%D1%8C+%D0%B8+%D1%83%D0%B4%D0%B5%CC%81%D0%BB%D0%B0%D1%82%D1%8C%D1%81%D1%8F.)'],'Уточнить: уд..ляться (от берега). Синхронно перенести контекст в паспорт, drill и объяснение; выбранная А и ключи сохранятся.',{'alternative_letters':['а','е'],'source_evidence':'Русский орфографический словарь на Грамоте: уделять(ся), -яю, -яет(ся). Проверено независимо от dictionary_check.'})
add('R80-AUD-03','high','Пр..рвать допускает прервать и прорвать. Оба вхождения стоят в авторских верных рядах; нормативная О разрушает равенство букв.','пр..рвать',[pdf,'https://www.orthographia.ru/orfografia.php?sid=0'],'Уточнить: пр..рвать (молчание). Обновить все представления; выбранная Е и ключи сохранятся.',{'alternative_letters':['е','о'],'key_impact':{'rus-2027-10-0006':['1235','125'],'rus-2027-10-0009':['245','25']}})
add('R80-AUD-04','high','Пр..клеить допускает приклеить и проклеить. В обоих вхождениях верный ряд можно сделать неверным нормативной О.','пр..клеить',['https://oross.ruslang.ru/article/link/prokleit'],'Уточнить значение присоединения: пр..клеить (марку к конверту). Обновить все представления; выбранная И и ключи сохранятся.',{'alternative_letters':['и','о'],'key_impact':{'rus-2027-10-0001':['1345','134'],'rus-2027-10-0014':['24','4']},'source_evidence':'ОРОСС ИРЯ РАН даёт проклеить и его формы: проклею, проклеишь, проклеит.'})
add('R80-AUD-05','medium','Пр..шить допускает пришить и прошить. Ряды остаются неверными при обеих буквах, однако поэлементный тренажёр отклоняет нормативную альтернативу.','пр..шить',[pdf],'Уточнить: пр..шить (пуговицу к пальто). Синхронно обновить все представления.',{'alternative_letters':['и','о'],'key_impact':'12 у10-0007 и3 у10-0020 остаются теми же.'})
# These readings are ordinary lexical alternatives but interpretation of abbreviated context requires a methodologist.
add('R80-AUD-06','medium','Контекст (форму) не исключает нормативное продать форму (комплект одежды), тогда как паспорт выбирает придать форму (очертания). Неоднозначность особенно существенна в верном ряду10-0003/2.','пр..дать (форму)',[pdf],'Уточнить: пр..дать (шару нужную форму), либо пр..дать (форму шару). В паспорт перенести ту же фразу; сохранить И.',{'alternative_letters':['и','о'],'key_impact':{'rus-2027-10-0003':['125','15'],'rus-2027-10-0016':'ряд1 остаётся неверным'},'interpretation_note':'Это семантический вывод аудитора на основе двух обычных нормативных глаголов; отдельную фразу продать форму словарь не обязан перечислять.'})
add('R80-AUD-07','medium','Контекст (друга) допускает предать друга и продать друга в словарно зафиксированном разговорном значении совершить предательство. В двух вхождениях авторские верные ряды становятся неоднозначными.','пр..дать (друга)',[pdf,'https://gramota.ru/poisk?dicts%5B0%5D=48&mode=slovari&query=%D0%BF%D1%80%D0%BE%D0%B4%D0%B0%D0%B6%D0%B0&simple=0'],'Заменить контекст на пр..дать (огласке). Сохранить Е и синхронно обновить все представления.',{'alternative_letters':['е','о'],'key_impact':{'rus-2027-10-0009':['245','25'],'rus-2027-10-0012':['3','пустой ключ при чтении продать'],'rus-2027-10-0018':'ряд4 остаётся неверным'},'source_evidence':'Большой универсальный словарь на Грамоте: продать, значение2.0, разговорное, синоним предать; пример П. товарища. Разговорная помета снижает экзаменационную пригодность альтернативы, но не делает слово орфографической ошибкой.'})
rows=sum(len(t['opts']) for t in T);tokens=sum(len(r) for t in T for r in t['drill']['rows'])
allitems=[i for p in P for r in p['rows'] for i in r['items']]
report={
 'structural_checks':{'executed_at':'2026-11-10','method':'Новый независимый проход по JSON; checks.json не читался и не использовался. Воспроизводимый код: work/agents/reviews/run_r80_audit.py.','input_sha256':{f:hashlib.sha256((base/f).read_bytes()).hexdigest() for f in ['tasks.json','row-passports.json','word-inventory.json']},'tasks':len(T),'tasks_by_line':dict(collections.Counter(t['line'] for t in T)),'rows':rows,'positions':tokens,'inventory_records':len(I),'used_unique_templates':len(used),'used_unique_lexemes':len(set(i['lexeme'] for i in allitems)),'tests':{x:('pass' if not errors.get(x) else 'fail') for x in ['five_rows','row_size','wrong_triple_shape','mixed_gap_classes','passport_letters','opt_passport','exp_passport','drill_passport','inventory_passport','key','explanation_key']},'failures':dict(errors),'line12_same_source_verb_leaks':leaks,'within_task_repeated_lemmas':lemreps,'duplicate_family_ids':[k for k,v in collections.Counter(t['family'] for t in T).items() if v>1],'duplicate_rows_ignoring_word_order':[v for v in rowsets.values() if len(v)>1],'template_reuse_histogram':dict(collections.Counter(used.values())),'max_template_reuse':max(used.values()),'inventory_unused':[i['template'] for i in I if (i['line'],i['template']) not in used]},
 'issues':issues,
 'normative_scope':{'status':'targeted_not_full_acceptance','description':'Прочитаны тексты шаблонов и правил всего инвентаря; машинно сопоставлены все1000позиций. Внешняя первичная проверка была выборочной и касалась обнаруженных альтернатив: вправе/вправо, уделяться, прорвать, прошить, проклеить, продать/придать. Дополнительно проверено объяснение объектив по ОРОСС: исторически выделяемая приставка допустима, поэтому это не включено в ошибки. Полная нормативная приёмка535использованных лексем не заявляется.','dictionary_flags_policy':'dictionary_check рассматривался только как авторское поле, не как доказательство нормы. Все структурные pass условны относительно авторских букв и не снимают обнаруженную лексическую неоднозначность.','sources_checked':[pdf,'https://oross.ruslang.ru/article/link/prokleit','https://oross.ruslang.ru/abc/part/o?end=9341&start=9291','https://www.orthographia.ru/orfografia.php?sid=0']},
 'limitations':['Сравнение exp с паспортом доказывает синхронизацию, а не истинность каждого объяснения.','Утечки исходного глагола проверены по lemma с удалением -ся/-сь; полное семантическое установление всех однокоренных семейств не автоматизировалось.','80 family идентификаторов уникальны;400рядов уникальны как наборы шаблонов. Это не доказывает отсутствие методически близких задач или достаточную сложность.','Грамота ограничивала часть прямых открытий403; подтверждения нормативного PDF для вправе/вправо, прорвать и прошить получены через индексированные фрагменты первоисточника; статья ОРОСС проклеить открыта полностью.','Не выполнены пилотирование, оценка трудности и психометрическая приёмка. Банк и три входных файла не изменялись.']}
path=pathlib.Path('work/agents/reviews/r80-audit.json');path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':str(path),'issue_count':len(issues),'failures':dict(errors),'used_unique_lexemes':report['structural_checks']['used_unique_lexemes']},ensure_ascii=False))
