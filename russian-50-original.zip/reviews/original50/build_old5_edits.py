import json,re,hashlib
from pathlib import Path
W=Path('work/original50');R=W/'reviews';b=json.loads((W/'baseline-tasks.json').read_text());by={t['id']:t for t in b};oldsrc=json.loads((W/'baseline-sources.json').read_text());S={};E=[]
D={1:'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast1_A-N.pdf',2:'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast2_O-Ja.pdf'}
pages={n:[re.sub(r'(?<=[А-ЯЁ]) (?=[А-ЯЁ])','',re.sub('[\ue000-\uf8ff\u0301]','',p)) for p in open(f'work/b80g/authors/lex-work/dict{n}.txt').read().split('\f')] for n in (1,2)}
def src(word):
 sid='O50-OLD5-D-'+word.casefold().replace('ё','е');found=[]
 for n,ps in pages.items():
  for pn,p in enumerate(ps,1):
   if re.search(r'(?<![А-ЯЁ-])'+re.escape(word.upper().replace('Ё','Е'))+r'\s+(?=[-–а-яё\[;])',p.replace('Ё','Е')):found.append((n,pn))
 if found:n,pn=found[0];loc=f'Ч.{n}, PDF с.{pn}, статья «{word}».';v='local_primary_entry_inspected'
 else:n=1 if word[0].casefold()<'о' else 2;loc=f'Ч.{n}, словарная статья «{word}»; точный локатор пока не установлен.';v='pending_exact_entry_locator'
 S[sid]={'id':sid,'title':'ИРЯ РАН. Толковый словарь государственного языка Российской Федерации','url':D[n],'locator':loc,'role':'normative_primary','verification':v}
 return sid
F='O50-OLD5-FORMAT';S[F]={'id':F,**oldsrc['G-L-FIPI27']}
rows=[
('rus-2027-b80b-05-0001','Дорожный знак предупреждал водителей об ОПАСЛИВОМ участке трассы, где часто случаются камнепады.','опасном','Опасный|Опасливый','Опасный — способный причинить вред, угрожающий бедствием. Опасливый — склонный опасаться, осторожный, характеризует человека/животное и проявления их поведения. Участок трассы несёт угрозу, а не испытывает опасение.','Прилагательное злой могло характеризовать личные качества нарушителя; обязательной паронимической ошибки контекст не задавал.'),
('rus-2027-b80c-05-0003','Офтальмолог проверил состояние ЗРИТЕЛЬСКОГО нерва, передающего сигналы от сетчатки к головному мозгу.','зрительного','Зрительный|Зрительский','Зрительный нерв относится к зрению как физиологической функции. Зрительский — относящийся к зрителю, публике. Название анатомической структуры требует зрительного.','Болотная местность допускает относительное прочтение относящаяся к болоту; исходный запрет был недостаточно обоснован.'),
('rus-2027-b80c-05-0005','Агроном внёс в почву ОРГАНИЧНЫЕ удобрения — навоз и перегной.','органические','Органический|Органичный','Органические удобрения имеют растительное или животное происхождение. Органичный — внутренне целостный, естественно связанный, соответствующий общему целому. В агротехническом контексте перечислены вещества, а не эстетическая согласованность.','Удачный предприниматель может оцениваться как успешный или подходящий для ситуации; исходное исправление не было обязательным.'),
('rus-2027-b80c-05-0007','Во время оттепели над входом выросла ЛЕДОВАЯ сосулька, состоящая из прозрачного льда.','ледяная','Ледяной|Ледовый','Ледяная сосулька состоит изо льда. Ледовый относится ко льдам как пространству, покрову, условиям движения и работы: ледовая обстановка, ледовый поход. Для материала предмета употребляется ледяной.','Царская походка допускает образную оценку; исходный контекст не исключал переносное значение царский.')]
for tid,new,key,ww,why,reason in rows:
 t=by[tid];opts=t['opts'].copy();opts[0]=new;refs=[F]+[src(w) for w in ww.split('|')]
 edit={'opts':opts,'key':[key],'exp':why+' Остальные четыре выделенных слова нормативны в своих исходных контекстах.','linguistic_fact':ww+': '+key,'family':'orig50-refresh-old5-'+hashlib.sha256(ww.encode()).hexdigest()[:14],'replaces_family':t['family'],'status':'draft','needs_source':True,'allowed_2027':None,'answer_type':'word','match':'exact','max_score':1,'norm_basis':{'claim':why,'rule_source':refs[1:],'type_source':F,'confirmed':False,'pending':'Авторская повторная проверка не является независимой методической приёмкой.'},'source_refs':list(dict.fromkeys(t['source_refs']+refs)),'evidence':{'error_option':1,'corrected_word':key,'corrected_sentence':re.sub(r'\b[А-ЯЁ]{2,}\b',key,new),'normative_options':[2,3,4,5],'alternative_check':'Контекст задаёт буквальный предмет/функцию; ошибочное слово не может быть спасено переносным обозначением человеческих качеств.'},'method_work_state':'draft_rewritten_pending_independent_review'}
 assert len(opts)==5 and all(len(re.findall(r'\b[А-ЯЁ]{2,}\b',x))==1 for x in opts)
 assert not any(new in x.get('opts',[]) for x in b)
 E.append({'id':tid,'reason':reason,'edit':edit})
(R/'old5-approved-edits.json').write_text(json.dumps(E,ensure_ascii=False,indent=2)+'\n');(R/'old5-approved-sources.json').write_text(json.dumps(list(S.values()),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'edits':len(E),'sources':len(S),'pending':[x['id'] for x in S.values() if x['verification'].startswith('pending')]},ensure_ascii=False))
