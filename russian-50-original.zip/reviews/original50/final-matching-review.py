from pathlib import Path
import json,copy,hashlib
R=Path('work/original50/reviews')
def load(n):return json.loads((R/(n+'.json')).read_text())
def dump(n,x):(R/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
F=load('lex-matching-findings')
for f in F:
 if f['id']=='rus-2027-orig-08-0007':
  e=f['proposed_edit']['evidence'];e['corrected_or_normative_by_right'][8]='Проверив крепления у причала, лодочник привязал лодку к новому столбу.';e['analysis_by_right'][8]='Крепления проверил лодочник; лодка в главной страдательной части является объектом привязывания и не выполняет добавочного действия «проверив».'
 if f['id']=='rus-2027-orig-08-0010':
  e=f['proposed_edit']['evidence'];e['corrected_or_normative_by_right'][2]='Когда работник заглянул в глубину колодца, цепь с громким звоном оборвалась.';e['analysis_by_right'][2]='В глубину колодца заглянул человек; цепь оборвалась и не выполняет действия зрительного восприятия.'
# The recovered first matching task had no diagnostic bold fragments.
base={t['id']:t for t in json.load(open('work/original50/baseline-tasks.json'))};t=base['rus-2027-22-0001']
if not any(x['id']==t['id'] for x in F):
 markup=['<b>Ветер</b> гнал листья, <b>ветер</b> срывал афиши, <b>ветер</b> не давал поднять глаз.','Снег лежал плотный, <b>как спрессованная вата</b>.','Мороз <b>рисовал</b> на стекле причудливые узоры.','Я <b>тысячу раз</b> повторял одно и то же.','Он молчал. <b>Долго. Упрямо.</b>']
 F.append({'id':t['id'],'severity':'minor','verdict':'restore_diagnostic_highlights','finding':'В восстановленном первом №22 поле left_markup совпадало с обычным текстом и не содержало ни одного выделения. Добавлены диагностические фрагменты без замены слов; они разграничивают анафору, сравнение, олицетворение, гиперболу и парцелляцию.','proposed_edit':{'left_markup':markup,'exp':'А–7: слово «ветер» повторяется в началах трёх частей — анафора. Б–2: сопоставление со сравнительным союзом «как». В–6: человеческое действие рисования приписано морозу. Г–3: число повторений «тысячу раз» намеренно преувеличено. Д–9: обстоятельственные компоненты «долго», «упрямо» отделены точками от опорного «он молчал», образуя парцелляцию.','evidence':{'term_by_left':['анафора','сравнение','олицетворение','гипербола','парцелляция'],'diagnostic_highlights_restored':True}},'source_refs':[],'human_acceptance':False})
dump('lex-matching-findings',F)
# Override the author's replacement, which repeats the same unsupported norm restriction.
old5=next(x for x in load('old5-approved-edits') if x['id']=='rus-2027-b80c-05-0007');ed=copy.deepcopy(old5['edit'])
ed['opts'][0]='Все отделения компании перешли на ЕДИНИЧНЫЙ стандарт отчётности: теперь правила одинаковы для каждого филиала.'
ed['key']=['единый'];ed['exp']='Единый в значении «общий, одинаковый» относится к общему стандарту всех филиалов. Единичный означает редкий, отдельный, обособленный. Указание на одинаковые для каждого отделения правила исключает значение отдельного случая. Остальные четыре выделенных слова употреблены нормативно: царская грамота, ржаной хлеб, бетонная площадка, аккуратная тетрадь.'
ed['family']='orig50-refresh-old5-unified-reporting';ed['linguistic_fact']='Единичный|Единый: единый стандарт всех филиалов'
ed['evidence']={'error_option':1,'corrected_word':'единый','corrected_sentence':'Все отделения компании перешли на единый стандарт отчётности: теперь правила одинаковы для каждого филиала.','normative_options':[2,3,4,5],'alternative_check':'Значение одинаковости для всех отделений прямо задано второй частью; единичный (редкий/отдельный) ему противоречит. Соседние слова и формы не меняются.'}
ed['norm_basis']={'claim':'Контекст требует общего одинакового стандарта для всех филиалов; значения единичный и единый разграничены нормативным толковым словарём. Прежнее ограничение слова ледовый опровергается тем же первичным словарём.','rule_source':['O50-FINAL5-ЕДИНЫЙ','O50-FINAL5-ЕДИНИЧНЫЙ'],'type_source':'O50-OLD5-FORMAT','confirmed':False,'pending':'Независимая агентная вычитка не является приёмкой методистом и не подтверждает допуск окончательной редакции2027.'}
ed['source_refs']=['INPUT-BANK-TASKS','INPUT-BANK-KEYS','O50-OLD5-FORMAT','O50-FINAL5-ЕДИНЫЙ','O50-FINAL5-ЕДИНИЧНЫЙ']
url='https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast1_A-N.pdf'
sources=[{'id':'O50-FINAL5-ЕДИНЫЙ','title':'Нормативный толковый словарь государственного языка Российской Федерации. Часть1. ИРЯ РАН. Статья «Единый»','url':url,'locator':'PDFс.176, статья ЕДИНЫЙ, значение2: общий, одинаковый. Локальный dict1.txt, строка16721 и следующие.','role':'normative_primary','verification':'read_local_primary_pdf_text','accessed_at':'2026-11-13'},{'id':'O50-FINAL5-ЕДИНИЧНЫЙ','title':'Нормативный толковый словарь государственного языка Российской Федерации. Часть1. ИРЯ РАН. Статья «Единичный»','url':url,'locator':'PDFс.175, статья ЕДИНИЧНЫЙ, значения1–2: редкий/отдельный.','role':'normative_primary','verification':'read_local_primary_pdf_text','accessed_at':'2026-11-13'}]
row={'id':old5['id'],'severity':'blocking','reason':'Предложенная замена «ледовая сосулька→ледяная» не имеет обязательной ошибки: нормативный ИРЯ РАН, часть1, PDFс.294, статья ЛЕДОВЫЙ, значение1 допускает значение «состоящий изо льда». Ошибочный авторский запрет снят. Введён другой новый языковой материал единичный/единый. ПРИМЕНИТЬ ПОСЛЕ old5-approved-edits.','proposed_edit':ed,'sources':sources,'human_acceptance':False}
dump('final-matching-overrides',[row])
ledger=load('lex-matching-ledger')
for x in ledger:
 x['additional_independent_agent_review']='rechecked_all_options_keys_and_proposed_edits_2026-11-13'
 x['additional_review_human_acceptance']=False
 if x.get('id') in [f['id'] for f in F]:x['post_edit_state']='ready_to_apply_agent_revision_pending_human_review'
dump('lex-matching-ledger',ledger)
newtasks=json.load(open('work/original50/authors/lex.json'))['tasks'];D={t['id']:t for t in list(base.values())+newtasks}
for f in F:
 t={**D[f['id']],**f['proposed_edit']}
 if t['line']==22:
  assert t['key']==[''.join(str(t['right'].index(term)+1) for term in t['evidence']['term_by_left'])]
  import re
  assert t['left']==[re.sub('</?b>','',x) for x in t['left_markup']]
 else:
  e=t['evidence'];assert t['key']==[''.join(str(e['error_types_by_right'].index(term)+1) for term in e['left_types'])]
  assert sum(x is None for x in e['error_types_by_right'])==4
# Independent check of replacement exercises 5+6: keys and uniqueness by whole context.
extra=[]
for x in load('old5-approved-edits'):
 t={**base[x['id']],**x['edit']}
 extra.append({'id':x['id'],'status':'replacement_required' if x['id']==old5['id'] else 'reviewed_draft','notes':'Ледовый допускает материал; замена в final-matching-overrides.' if x['id']==old5['id'] else 'Все5контекстов и паронимический ключ повторно сверены; остальные4нормативны. Не приёмка человеком.'})
for x in load('old6-approved-edits'):
 if 'key' in x['edit']:
  extra.append({'id':x['id'],'status':'reviewed_draft','notes':'Однословная замена проверена без изменения соседних форм; перечисленные синонимические ключи сохраняют смысл, прочие ответы уходят на manual_review. Не приёмка человеком.'})
dump('final-matching-replacement-ledger',extra)
dump('final-matching-audit',{'date':'2026-11-13','matching_tasks_rechecked':69,'new_line8':19,'new_line22':19,'baseline_line22':31,'old5_replacements_rechecked':4,'old6_replacements_rechecked':5,'additional_blockers':1,'additional_metadata_consistency_repairs':2,'diagnostic_bold_restored_tasks':1,'findings_total':len(F),'override_file':'final-matching-overrides.json','human_methodologist_accepted':False,'limits':'Это повторный агентный проход по материалу и предлагаемым редакциям, а не слепое решение новым человеком; уровень трудности на учениках не измерялся.'})
print({'matching_findings':len(F),'reviewed_matching':len(ledger),'extra_replacements':len(extra),'override':old5['id']})
