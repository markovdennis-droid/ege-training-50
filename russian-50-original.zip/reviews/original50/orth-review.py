import json,re,hashlib,collections
from pathlib import Path
P=Path('work/original50');R=P/'reviews'
orth=json.loads((P/'authors/orth.json').read_text())['tasks']
stress=json.loads((P/'stress/tasks.json').read_text())
# Reviewer answers after reading every context; no author evidence imported for these answers.
answers={13:['145','235','125','235','245','245','135','235','245','235','135','124','135','235','135','235','145','235','125'],14:['15','14','14','145','25','15','14','14','13','13','24','13','135','15','13','25','14','14','23'],15:['24','134','25','123','13','235','245','1245','345','14','134','1245','245','134','23','13','135','124','345']}
# Independently collect explicitly printed headwords/parallel forms, excluding lemma annotations.
src=(P/'stress/fipi-2026-phonetics.txt').read_text(); relevant=src.split('Имена существительные',1)[1].split('Обратите внимание!',1)[0]
heads={};duplicates=collections.defaultdict(set)
for line in relevant.splitlines():
 line=line.strip()
 if not re.match(r'[а-яёА-ЯЁ]+[;, (0-9]*',line):continue
 if line.startswith(('Навигатор','Имена','Причастия','Деепричастия','Наречия','Глаголы','У слов','В контрольных')):continue
 for segment in line.split(';'):
  # Only beginning of a list subentry, and its successive comma-separated forms before grammatical prose.
  for part in segment.split(','):
   part=part.strip();m=re.match(r'^([а-яёА-ЯЁ]+)(?:\s|$|[;(])',part)
   if not m:break
   word=m.group(1)
   if len(re.findall('[АЕЁИОУЫЭЮЯ]',word))!=1 or any(c.isupper() and c not in 'АЕЁИОУЫЭЮЯ' for c in word):break
   duplicates[word.lower()].add(word)
   heads[word]=line
ambiguous={w for w,v in duplicates.items() if len(v)>1}
assert ambiguous=={'отзыв'},ambiguous
errors=[];ledger=[];used=collections.Counter();stress_notes=[]
for t in orth:
 a=answers[t['line']][int(t['id'][-4:])-1]
 if t['key']!=[a]:errors.append([t['id'],a,t['key']])
 notes={13:'Все пять контекстов проверены на отрицание/утверждение, противопоставление, зависимые слова и разграничение недо-/не до-. Ключ и правило совпали; §145 прямо перечисляет нестерпимый, невредимый, неизбежный, поэтому эти основания не отвергались по догадке.',14:'Проверены обе выделенные границы во всех пяти строках; управляющие существительные, наречия, производные предлоги и служебные слова разграничены по контексту. Слитный компонент составного предлога не назван слитным написанием всего предлога.',15:'Каждый из пяти пропусков восстановлен в полном слове; разграничены полная/краткая форма, отыменная основа, зависимые слова и словарные исключения. Проверено также объяснение морфем, а не только число Н.'}[t['line']]
 ledger.append({'id':t['id'],'own_answer':a,'key_agrees':t['key']==[a],'verdict':'pass_agent_review','reason':notes,'alternatives':[],'review_blind':False,'human_acceptance':False})
for t in stress:
 answer=[];norms=[]
 assert len(t['opts'])==5
 for i,shown in enumerate(t['opts'],1):
  word=shown.lower();used[word]+=1
  matches=[h for h in heads if h.lower()==word]
  assert len(matches)==1,(t['id'],shown,matches)
  correct=matches[0]
  assert word not in ambiguous
  assert len(re.findall('[АЕЁИОУЫЭЮЯ]',shown))==1,(t['id'],shown)
  assert not re.search('[БВГДЖЗЙКЛМНПРСТФХЦЧШЩЪЬ]',shown)
  if 'ё' in word:assert shown==correct,(t['id'],shown,correct)
  if shown==correct:answer.append(str(i))
  norms.append(correct)
  ev=t['evidence']['stress_items'][i-1]
  assert ev['correct']==correct and ev['is_correct']==(shown==correct)
  assert correct in t['exp']
 a=''.join(answer)
 if t['key']!=[a]:errors.append([t['id'],a,t['key']])
 assert len(set(o.lower() for o in t['opts']))==5
 ledger.append({'id':t['id'],'own_answer':a,'normative_words':norms,'key_agrees':t['key']==[a],'verdict':'pass_agent_review','reason':'Все пять форм сопоставлены с буквальным написанием в официальном PDF2026; парсер ревьюера не использует инвентарь/генератор автора. Гомограф отзыв исключён. Неверная позиция меняет лишь место ударения в том же написании. Ё-позиции в этой партии только верные — это выбранное ограничение генератора, не запрет ФИПИ на запись Е вместо Ё.','alternatives':[],'review_blind':False,'human_acceptance':False})
assert len(ledger)==107 and not errors
assert max(used.values())<=2
R.joinpath('orth-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
R.joinpath('orth-findings.json').write_text('[]\n')
R.joinpath('orth-review-audit.json').write_text(json.dumps({'reviewed_tasks':107,'new_orthography':57,'refreshed_stress':50,'errors':errors,'stress_independent_headword_count':len(heads),'ambiguous_homographs_excluded':sorted(ambiguous),'different_stress_words_used':len(used),'max_word_uses':max(used.values()),'manual_read_all_contexts_and_explanations':True,'blind_review':False,'human_acceptance':False,'allowed_2027_confirmed':False,'source_refs':['https://doc.fipi.ru/navigator-podgotovki/navigator-ege/2026/ru-1-fonetika.pdf','https://orthographia.ru/orfografia.php?sid=77','https://orthographia.ru/orfografia.php?sid=78','https://orthographia.ru/orfografia.php?sid=79','https://orthographia.ru/orfografia.php?sid=73','https://orthographia.ru/orfografia.php?sid=50','https://orthographia.ru/orfografia.php?sid=51','https://orthographia.ru/orfografia.php?sid=52'],'input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'authors/orth.json',P/'stress/tasks.json',P/'stress/fipi-2026-phonetics.pdf']}},ensure_ascii=False,indent=2)+'\n')
print('Review written',len(ledger),'headwords',len(heads),'differentused',len(used))
