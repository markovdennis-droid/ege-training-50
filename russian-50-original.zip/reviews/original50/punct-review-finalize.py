import json, re, hashlib
from pathlib import Path
P=Path('work/original50')
read=lambda name:json.loads((P/name).read_text())
write=lambda name,data:(P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
D=read('authors/punct.json'); tasks=D['tasks']; own=read('reviews/punct-own-answers.json'); by={t['id']:t for t in tasks}
issues={'rus-2027-orig-20-0004','rus-2027-orig-20-0011'}
ledger=[]
for a in own:
 t=by[a['id']];issue=a['id'] in issues
 reason=a['reason']
 if issue:
  reason+=' Авторский exp делает позицию 2 обязательной лишь по отсутствию ТО; это не учитывает тесную связь А с придаточным, оговорённую у Розенталя (§36.3). Ответ 134 нормативно допустим; единственность 1234 не обеспечена. Нужна замена союза.'
 else:
  reason+=' Проверены все предложения/позиции и весь авторский exp; существенных возражений к ключу и разбору не найдено.'
 ledger.append({'id':a['id'],'own_answer':a['own_answer'],'key_agrees':a['own_answer'] in t['key'],'verdict':'revise_ambiguity' if issue else 'pass_agent_review','reason':reason,'alternatives':a.get('alternatives',[])})
write('reviews/punct-ledger.json',ledger)
sources=[{'id':'PR-ROZ36','title':'Д. Э. Розенталь. Справочник по русскому языку. Пунктуация. §36.3','url':'https://old-rozental.ru/punctuatio.php?sid=140','locator':'§36, пункт 3, пример с «а когда», пояснение после него','rule':'При тесной связи А с придаточным запятая после А обычно отсутствует и без ТО; одной проверки отсутствия ТО для требования запятой недостаточно.','retrieval_ref':'turn399view0'}, {'id':'PR-ACAD123','title':'Полный академический справочник под ред. В. В. Лопатина. §123','url':'https://www.orthographia.ru/punctum_uk.php?rid=380','locator':'§123.1–2','rule':'Основное правило стыка союзов учитывает одиночный либо двойной подчинительный союз.','retrieval_ref':'turn397view0'}]
findings=[]
for id in sorted(issues):
 t=by[id];e=json.loads(json.dumps(t['evidence'],ensure_ascii=False))
 if id.endswith('0004'):
  stem=t['stem'].replace('(1) а (2)','(1) и (2)')
  e['punctuated_text']=e['punctuated_text'].replace(', а, пока',', и, пока')
  e['reason_by_slot']['2']='стык и и пока: временное придаточное можно изъять; соотносительного ТО нет'
 else:
  stem=t['stem'].replace('Фонари на набережной', 'Уличные фонари').replace('(1) а (2)','(1) и (2)')
  e['punctuated_text']=e['punctuated_text'].replace('Фонари на набережной', 'Уличные фонари').replace(', а, когда',', и, когда')
  e['reason_by_slot']['2']='стык и и когда: временное придаточное можно изъять; соотносительного ТО нет'
 exp=' '.join(f'{slot}) Запятая: {r}.' for slot,r in e['reason_by_slot'].items())
 findings.append({'id':id,'severity':'major','verdict':'revise_ambiguity','field':'stem / key / exp / evidence','finding':'Авторский ответ 1234 не единственный: возможно тесное соединение А с временным придаточным без запятой в позиции 2 (ответ 134). Отсутствие ТО не устраняет эту особенность союза А. Для экзаменационного задания лучше заменить союз, сохранив требуемый ключ. Это вывод агентной проверки, не заключение человека-методиста.','own_answer':'134','author_key':t['key'],'alternatives':['1234'],'alternative_punctuated_text':t['evidence']['punctuated_text'].replace(', а,',', а'), 'proposed_edit':{'stem':stem,'key':['1234'],'exp':exp,'evidence':e},'source_refs':['PR-ROZ36','PR-ACAD123'],'sources':sources})
write('reviews/punct-findings.json',findings)

def norm(s):return re.sub(r'[^а-яa-z0-9]','',re.sub(r'\(\d+\)','',s.lower().replace('ё','е')))
def content(t):
 if t.get('opts'):return t['opts']
 if t['line']==21:return re.split(r'\(\d+\)',t['stem'])[1:]
 return [t['stem'].split('запятые.',1)[-1]]
baseline=read('input/punct-baseline.json'); old={norm(s) for t in baseline for s in content(t)}
flat=[(t['id'],i,norm(s)) for t in tasks for i,s in enumerate(content(t),1)]
repeats=[{'id':id,'option':i} for id,i,n in flat if n in old]
from collections import Counter
internal=[n for n,c in Counter(n for _,_,n in flat).items() if c>1]
write('reviews/punct-review-audit.json',{'review_type':'independent_agent_review_not_human_acceptance','author_file_sha256':hashlib.sha256((P/'authors/punct.json').read_bytes()).hexdigest(),'blind_answers_sha256':hashlib.sha256((P/'reviews/punct-own-answers.json').read_bytes()).hexdigest(),'blind_answers_saved_before_author_read':True,'reviewed':len(ledger),'counts_by_line':{str(l):sum(by[a['id']]['line']==l for a in own) for l in range(16,22)},'key_agrees':sum(a['key_agrees'] for a in ledger),'needs_revision':len(findings),'all_author_explanations_read':True,'all_options_and_slots_reviewed':True,'baseline_tasks':len(baseline),'exact_normalized_sentence_repeats_with_baseline':repeats,'exact_normalized_sentence_repeats_within_party':len(internal),'similarity_check':'No baseline sentence similarity above 0.80 using SequenceMatcher on punctuation/slot/case/ё-normalized text. Similarity is a supporting check, not proof of authorship.','method_limits':'Не проверена окончательная редакция ФИПИ2027; человеческая приёмка не утверждается. Исходные авторские данные не изменены.'})
print('ledger',len(ledger),'findings',len(findings),'key_agrees',sum(x['key_agrees'] for x in ledger),'repeat',len(repeats),len(internal))
