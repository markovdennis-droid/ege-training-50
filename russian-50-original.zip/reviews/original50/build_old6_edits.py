import json,re,copy,hashlib
from pathlib import Path
W=Path('work/original50');R=W/'reviews'
base=json.loads((W/'baseline-tasks.json').read_text());lex=json.loads((W/'authors/lex.json').read_text());oldsrc=json.loads((W/'baseline-sources.json').read_text());by={t['id']:t for t in base};sources={};edits=[];ledger=[]
D={1:'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast1_A-N.pdf',2:'https://ruslang.ru/sites/default/files/doc/normativnyje_slovari/tolkovyj_slovar_chast2_O-Ja.pdf'}
pages={n:[re.sub(r'(?<=[А-ЯЁ]) (?=[А-ЯЁ])','',re.sub('[\ue000-\uf8ff\u0301]','',p)) for p in open(f'work/b80g/authors/lex-work/dict{n}.txt').read().split('\f')] for n in (1,2)}
def src(word):
 sid='O50-OLD6-D-'+word.casefold().replace('ё','е');found=[]
 for n,ps in pages.items():
  for pn,p in enumerate(ps,1):
   if re.search(r'(?<![А-ЯЁ-])'+re.escape(word.upper().replace('Ё','Е'))+r'\s+(?=[-–а-яё\[;])',p.replace('Ё','Е')):found.append((n,pn))
 if found:n,pn=found[0];loc=f'Ч.{n}, PDF с.{pn}, статья «{word}».';verification='local_primary_entry_inspected'
 else:n=1 if word[0].casefold()<'о' else 2;loc=f'Ч.{n}, словарная статья «{word}»; точная страница/вхождение не установлены, требуется сверка.';verification='pending_exact_entry_locator'
 sources[sid]={'id':sid,'title':'ИРЯ РАН. Толковый словарь государственного языка Российской Федерации','url':D[n],'locator':loc,'role':'normative_primary','verification':verification}
 return sid
F='O50-OLD6-FORMAT';sources[F]={'id':F,**oldsrc['G-L-FIPI27']}
# Только новые сочетания, которых нет среди старых задач линии6 и новых15.
replacements={
'rus-2027-b80a-06-0004':('На заседании выпускники оказали активное участие в обсуждении программы стажировки и предложили несколько изменений.','оказали',['приняли'],'Участвовать в обсуждении — принимать участие в нём. Оказать можно помощь, услугу, поддержку; нормативная конструкция со словом участие в значении совместной деятельности — принять участие.','Участие','participation','Нет надёжного первичного основания для обязательного удаления лица из сочетания мимика лица; вместо спора об избыточности вводится новый языковой материал.'),
'rus-2027-b80b-06-0005':('Переписывая фамилию заявителя, сотрудник оказал орфографическую ошибку, которую затем исправил по паспорту.','оказал',['допустил','сделал','совершил'],'Ошибку допускают, делают, совершают. Оказать — предоставить помощь, услугу, поддержку либо проявить отношение; оказать ошибку не называет ошибочного написания.','Ошибка','orthographic-error','Не подтверждён обязательный запрет сочетания впервые познакомились. Словарные значения познакомиться не дают основания для абсолютного правила познакомиться можно только раз.'),
'rus-2027-b80c-06-0003':('После концерта дирижёр нанёс искреннюю благодарность музыкантам за то, что они согласились выступить без гонорара.','нанёс',['выразил','объявил','принёс','принес'],'Благодарность выражают, объявляют, приносят. Нанести можно вред, ущерб, оскорбление; нанести благодарность нарушает сочетаемость. Контекст содержит положительную оценку бескорыстной помощи.','Благодарность','gratitude','Нет первичного основания считать усиление огромная махина обязательной лексической ошибкой в данном художественном контексте.'),
'rus-2027-b80c-06-0004':('Закончив ремонт крыши к условленному сроку, плотник произвёл данное хозяйке обещание и передал ей ключ от чердака.','произвёл',['выполнил','исполнил','сдержал'],'Обещание выполняют, исполняют, сдерживают. Произвести — изготовить, осуществить работу/действие либо вызвать результат; произвести данное обещание не означает исполнить принятое обязательство.','Обещание','keep-promise','Не подтверждена обязательная ошибочность уточнения направления упали вниз; смысл глагола сам по себе не доказывает запрета зависимого обстоятельства.'),
'rus-2027-b80c-06-0005':('Спонсор оказал значительный денежный взнос в фонд реставрации памятника.','оказал',['внёс','внес','сделал'],'Денежный взнос делают или вносят. Оказать можно помощь, поддержку, услугу; оказать денежный взнос нарушает лексическую сочетаемость.','Взнос','money-contribution','Первичный ИРЯ РАН, ч.1, PDF с.181, статья Жестикулировать, прямо приводит жестикулировать руками как нормативный пример.')}
# Норма и точные словарные статьи проверяются отдельно от оценки источникового допуска.
words={
'rus-2027-06-0001':'Автобиография','rus-2027-b80a-06-0001':'Сотрудничество','rus-2027-b80a-06-0002':'Прейскурант','rus-2027-b80a-06-0003':'Интерьер',
'rus-2027-b80a-06-0005':'Значение','rus-2027-b80a-06-0006':'Поражение','rus-2027-b80a-06-0007':'Кругозор',
'rus-2027-b80b-06-0001':'Суть','rus-2027-b80b-06-0002':'Дебют','rus-2027-b80b-06-0003':'Сувенир','rus-2027-b80b-06-0004':'Хронометраж','rus-2027-b80b-06-0006':'Внимание','rus-2027-b80b-06-0007':'Стоимость',
'rus-2027-b80c-06-0001':'Абориген','rus-2027-b80c-06-0002':'Фольклор','rus-2027-b80c-06-0006':'Поступок','rus-2027-b80c-06-0007':'Впечатление',
'rus-2027-b80e-06-0001':'Первенство','rus-2027-b80e-06-0002':'Ущерб','rus-2027-b80e-06-0004':'Впечатление','rus-2027-b80e-06-0005':'Интерес','rus-2027-b80e-06-0006':'Уровень','rus-2027-b80e-06-0007':'Скорость',
'rus-2027-b80g-06-0001':'Помощь','rus-2027-b80g-06-0002':'Польза','rus-2027-b80g-06-0003':'Решение','rus-2027-b80g-06-0004':'Выговор','rus-2027-b80g-06-0005':'Рекорд','rus-2027-b80g-06-0006':'Вывод','rus-2027-b80g-06-0007':'Сопротивление'}
replacement_stem='Отредактируйте предложение: исправьте лексическую ошибку, заменив употреблённое неверно слово. Запишите подобранное слово, соблюдая нормы современного русского литературного языка и сохраняя смысл высказывания.'
remove_stem='Отредактируйте предложение: исправьте лексическую ошибку, исключив лишнее слово. Выпишите это слово.'
checks={
'rus-2027-06-0001':'Своя в сочетании с автобиографией повторяет принадлежность описания автору; отдельного первичного запрета сочетания не установлено, нормативное основание остаётся pending.',
'rus-2027-b80a-06-0001':'Сотрудничество обозначает совместную деятельность. Отдельный запрет определения совместное не установлен; draft и source pending сохранены.',
'rus-2027-b80a-06-0002':'Первичный материал Грамоты прямо относит прейскурант цен к плеоназму. Удаляется цен, остальные формы не меняются.',
'rus-2027-b80a-06-0003':'Интерьер — внутреннее пространство, поэтому внутренний повторяет его значение; отдельный запрет не установлен, source pending сохранён.',
'rus-2027-b80b-06-0001':'Суть — самое главное и существенное. Главную повторяет компонент определения; отдельный запрет не установлен, source pending сохранён.',
'rus-2027-b80b-06-0002':'Дебют — первое публичное выступление. В буквальном сценическом контексте первый избыточно; нет отсылки к шахматным дебютам или дебютам в разных ролях.',
'rus-2027-b80b-06-0003':'Сувенир — подарок на память; памятный повторяет компонент значения. Отдельный запрет не установлен, source pending сохранён.',
'rus-2027-b80b-06-0004':'Хронометраж — измерение затрат времени. Удаление времени сохраняет словоформы; удаление хронометраж создаёт неграмматическое провёл времени, поэтому второго однословного удаления нет.',
'rus-2027-b80c-06-0001':'Абориген — коренной житель местности; местный повторяет признак, но отдельное нормативное основание обязательного удаления не установлено; pending.',
'rus-2027-b80c-06-0002':'Фольклор — народное творчество. В исходном задании нет противопоставления фольклора разных социальных групп; отдельный обязательный запрет не установлен; pending.',
'rus-2027-b80e-06-0004':'Нормативная словарная иллюстрация произвести впечатление. Историческое сделать впечатление не объявляется универсально невозможным: требуется современная методическая оценка.'}
for t in base:
 if t['line']!=6:continue
 tid=t['id']
 if t['status']=='on_hold':
  ledger.append({'id':tid,'status':'on_hold_unchanged','reason':'Исходная неоднозначность сохраняется; в50не выбирается.','human_accepted':False});continue
 if tid in replacements:
  sent,wrong,keys,why,w,slug,reason=replacements[tid];refs=[F,src(w)]
  e={'stem':replacement_stem+'\n\n'+sent,'key':keys,'exp':why,'answer_type':'word','match':'exact','max_score':1,'status':'draft','needs_source':True,'allowed_2027':None,'linguistic_fact':slug+': '+wrong+' → '+keys[0],'family':'orig50-refresh-old6-'+slug,'replaces_family':t['family'],'key_policy':{'on_unmatched':'manual_review','preserve_meaning':True,'reason':'Перечень нормативных лексических замен открыт; ответ вне перечня требует проверки, а не автоматического нуля.'},'norm_basis':{'claim':why,'rule_source':refs[1:],'type_source':F,'confirmed':False,'pending':'Независимая методическая приёмка и окончательная редакция2027 не подтверждены.'},'source_refs':list(dict.fromkeys(t['source_refs']+refs)),'evidence':{'original_sentence':sent,'wrong_word':wrong,'operation':'replace_one_word','corrected_sentences':[re.sub(r'\b'+re.escape(wrong)+r'\b',k,sent,count=1) for k in keys],'semantic_constraint':why,'author_alternative_review':'Соседние слова и формы не меняются; перечислены однословные нормативные замены. Дополнительные ответы требуют manual_review.'},'method_work_state':'draft_rewritten_pending_independent_review'}
  edits.append({'id':tid,'reason':reason,'edit':e});ledger.append({'id':tid,'status':'replaced_risky_material','reason':reason,'replacement_fact':e['linguistic_fact'],'normative_source':refs[1:],'human_accepted':False});continue
 removal='исключив лишнее слово' in t['stem']
 s=t['stem']
 if '\n\n' in s:sent=s.split('\n\n',1)[-1]
 elif s.startswith('Отредактируйте'):sent=re.split(r'(?:Выпишите это слово\.|в нужной форме\.|сохраняя смысл высказывания\.)\s*',s,maxsplit=1)[-1]
 else:sent=s.split('\n')[-1]
 assert not sent.startswith('Отредактируйте'),(tid,sent)
 refs=[F,src(words[tid])]
 e={'stem':(remove_stem if removal else replacement_stem)+'\n\n'+sent,'status':'draft','needs_source':True,'allowed_2027':None,'norm_basis':{'claim':t.get('linguistic_fact') or t['exp'],'rule_source':refs[1:],'type_source':F,'confirmed':False,'pending':'Словарная статья подтверждает значение/нормативную конструкцию, но сама по себе не доказывает запрет любого иного сочетания. Методическая приёмка обязательна.'},'source_refs':list(dict.fromkeys(t['source_refs']+refs))}
 if not removal:e['key_policy']={'on_unmatched':'manual_review','preserve_meaning':True,'reason':'Открытый лексический ключ: нормативная замена вне перечня рассматривается вручную.'}
 edits.append({'id':tid,'reason':'Актуализировано условие2027, добавлена нормативная словарная опора и честное состояние подтверждения; для замены включена обработка открытого ключа.','edit':e})
 ledger.append({'id':tid,'status':'no_new_context_or_key_defect_found_source_pending' if tid not in checks else 'normative_risk_pending','reason':checks.get(tid,'Проверена сочетаемость по исходному контексту; перечисленные ключи сохраняют контекст. Открытый набор замен обрабатывается вручную. Полная нормативная приёмка не заявляется.'),'normative_source':refs[1:],'human_accepted':False})
assert len(edits)==35,(len(edits),len(ledger))
# Отдельная нормативная публикация о прейскуранте передана root после просмотра.
sid='O50-OLD6-GRAMOTA-PRICE';sources[sid]={'id':sid,'title':'Грамота.ру. Четвероклассник зрит в корень, или Усечение фортепьяно','url':'https://gramota.ru/journal/stati/pravila-i-normy/chetveroklassnik-zrit-v-koren-ili-usechenie-fortepyano','locator':'Разбор избыточных сочетаний: прейскурант цен. Передан root после просмотра первичного материала.','role':'normative_primary','verification':'primary_material_inspected_by_root'}
for e in edits:
 if e['id']=='rus-2027-b80a-06-0002':e['edit']['source_refs'].append(sid);e['edit']['norm_basis']['rule_source'].append(sid)
# Источник, из-за которого отменена заготовка, не служит источником новой нормы.
sid='O50-OLD6-JEST-NORM';sources[sid]={'id':sid,'title':'ИРЯ РАН. Толковый словарь государственного языка Российской Федерации, ч.1','url':D[1],'locator':'PDF с.181, статья Жестикулировать: нормативный пример с руками. Основание отмены прежней заготовки.','role':'superseded_material_rejection_basis','verification':'local_primary_entry_inspected'}
for e in edits:
 if e['id']=='rus-2027-b80c-06-0005':e['edit']['source_refs'].append(sid)
# Сопоставлены все35активных +1on_hold; последняя не меняется.
(R/'old6-approved-edits.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
(R/'old6-ledger.json').write_text(json.dumps({'active_checked':35,'on_hold_unchanged':1,'tasks':ledger,'normative_human_approval':False,'warning':'no_new_defect означает лишь отсутствие найденного контекстного дефекта; не равняется запрету всех альтернатив и не снимает needs_source.'},ensure_ascii=False,indent=2)+'\n')
(R/'old6-approved-sources.json').write_text(json.dumps(list(sources.values()),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'edits':len(edits),'rewritten':len(replacements),'ledger':len(ledger),'sources':len(sources)},ensure_ascii=False))
